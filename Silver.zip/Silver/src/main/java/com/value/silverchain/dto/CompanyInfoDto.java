package com.value.silverchain.dto;

import com.value.silverchain.model.CompanyInfo;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/6/12
 * DESC:商户信息查询类
 */
@Data
public class CompanyInfoDto {
    private String pkCompanyInfo;//商户主键
    private String companyName;//商户名称

    public CompanyInfoDto() {
    }

    public CompanyInfoDto(CompanyInfo companyInfo) {
        this.setPkCompanyInfo(companyInfo.getPkCompanyInfo());
        this.setCompanyName(companyInfo.getCompanyName());
    }

    /**
     * 把商户信息类列表转换成查询类列表
     * @param list
     * @return
     */
    public static List<CompanyInfoDto> change(List<CompanyInfo> list){
        List<CompanyInfoDto> result = new ArrayList<>();
        for (CompanyInfo c:list){
            result.add(new CompanyInfoDto(c));
        }
        return result;
    }
}
