package com.value.silverchain.controller;

import com.mongodb.DuplicateKeyException;
import com.value.silverchain.bo.PageBo;
import com.value.silverchain.common.Constants;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.AccountInfo;
import com.value.silverchain.model.DealInfo;
import com.value.silverchain.model.ManagerInfo;
import com.value.silverchain.service.IChainService;
import com.value.silverchain.service.IDealInfoService;
import com.value.silverchain.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.embedded.netty.NettyWebServer;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.rmi.activation.ActivationID;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: ${date}
 * DESC:交易统计管理
 */
@Controller
@RequestMapping("/txreport/v1")
public class OrgTxReportController {

    @Autowired
    private IDealInfoService dealInfoService;
    @Autowired
    private IChainService  chainService;

    /**
     * 按商户账号分页查询
     * @param dealInfo
     * @return
     */
    @RequestMapping("/findByPage")
    @ResponseBody
    public String findDealInfoByPage(@RequestBody DealInfo dealInfo, HttpSession session){
        Result result = new Result();
        try {
            ManagerInfo manager = (ManagerInfo)session.getAttribute("loginUser");
            PageBo<DealInfo> dealInfos = dealInfoService.findPage(dealInfo,manager);
            result.getData().put("list",dealInfos);
        } catch (Exception e) {
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        }

        return result.toJson();
    }

    /*
    * 显示日志
    * */
    @RequestMapping("/queryLog")
    @ResponseBody
    public String queryLog(@RequestBody DealInfo dealInfo, HttpSession session){
        Result result = new Result();
        String aid = dealInfo.getAid();
        String orderId = dealInfo.getDealNo().replace(dealInfo.getMerId()+"_","");
        try {
            List<String> logList = chainService.queryLog(aid, orderId);
            if (logList == null || logList.size() == 0) {
                throw new HorizonBizException(Constants.Return.LOG_NULL);
            }
            result.getData().put("logList", logList);
        } catch (HorizonBizException e) {
            result.setState(e);
        } catch (Exception e) {
            result.setState(Constants.Return.SYSTEM_ERR);
        }

        return result.toJson();
    }




}
