package com.value.silverchain.service;

import com.value.silverchain.bo.PageBo;
import com.value.silverchain.model.BaseRole;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:00
 * DESC:
 */
public interface IBaseRoleService {

    String save(BaseRole baseRole);
    BaseRole getByPkRole(String pkRole);

    BaseRole getByName(BaseRole baseRole);

    PageBo<BaseRole> findPage(BaseRole param);
    void delete(String userId);
    List<BaseRole> getUserListByPhone(String phone);

    int update(BaseRole baseRole);

    List<BaseRole> getByKeys(List<String> pkRole);

    void realDelete(String pkRole);
}
