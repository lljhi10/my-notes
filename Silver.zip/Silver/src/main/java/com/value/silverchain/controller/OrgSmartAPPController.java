package com.value.silverchain.controller;

import com.mongodb.DuplicateKeyException;
import com.value.silverchain.bo.PageBo;
import com.value.silverchain.common.Constants;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.*;
import com.value.silverchain.service.*;
import com.value.silverchain.util.SmartJsonUtil;
import com.value.silverchain.vo.LoginManager;
import com.value.silverchain.vo.Result;
import com.value.silverchain.vo.SmartAppInfoVo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: ${date}
 * DESC:智能APP
 */
@Controller
@RequestMapping("/smartapp/v1")
public class OrgSmartAPPController {

    private Logger logger = LoggerFactory.getLogger(OrgSmartAPPController.class);
    @Autowired
    private ISmartAppInfoService smartAppInfoService;
    @Autowired
    private IOrgInfoService orgInfoService;
    @Autowired
    private IPayApiService payApiService;
    @Autowired
    private IServiceApiService serviceApiService;
    @Autowired
    private IChainService chainService;

    /**
     * 创建智能合约  
     * @param smartAppInfoVo
     * @param session
     * @return
     */
    @RequestMapping("/create")
    @ResponseBody
    public String create(@RequestBody SmartAppInfoVo smartAppInfoVo, HttpSession session){

        Result result = checkNull(smartAppInfoVo);//参数非空验证
        if (!result.verify()) {
            return result.toJson();
        }

        if(smartAppInfoVo.getCooperateCompany().size() > 1) {
            logger.info("目前版本智能应用的协作用户只能添加一个,很抱歉!");
            result.setState(Constants.Return.COOPERATECOMPANY_SIZE_BIGGER);
            return result.toJson();
        }
        try {
            //判断选取的合作方是否存在
            List<CompanyInfo> companyInfoList=checkCooperateCompnay(smartAppInfoVo.getCooperateCompany());
            //获取当前登录用户
            LoginManager loginManager=(LoginManager)session.getAttribute("loginManager");
            if(null==loginManager){
                throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
            }

            ManagerInfo manger = loginManager.getLoginUser();
            CompanyInfo company = loginManager.getCompanyInfo();
            Date date = new Date();
            
            SmartAppInfo smartAppInfo=new SmartAppInfo();
            smartAppInfo.setPkSmartAppInfo(UUID.randomUUID().toString());
            smartAppInfo.setPkCompanyInfo(manger.getPkCompanyInfo());
            smartAppInfo.setStatus(smartAppInfoVo.getStatus());
            //创建时间
            smartAppInfo.setCreateDate(date);
            smartAppInfo.setCreateManager(manger.getPkManagerInfo());

            //正常
            //smartAppInfo.setStatus(SmartAppInfo.Status.NORMAL);
            
            //封装数据
            smartAppInfo=initModel(smartAppInfo,smartAppInfoVo,loginManager,date);
 

            if(smartAppInfoVo.getIsPublish()){
                //发布
                if(smartAppInfo.getEndDate().getTime() <= new Date().getTime()){
                    //有效期结束时间小于当前时间
                    throw new HorizonBizException(Constants.Return.END_DATE_LESS_THEM_CURRENT);
                }

                //检查合约有效期唯一
                smartAppInfoService.checkUniqueness(smartAppInfo);
                smartAppInfo.setPublishDate(date);
                if(smartAppInfo.getAprover()==null){
                    //未审核，
                    // 当智能应用使用的服务接口，目标类型为非公开类型时，需要发布接口的商户审核通过，智能应用才生效
                    smartAppInfo.setAprover(SmartAppInfo.Aprover.UNAPROVER);
                }
            }else{
                //保存
                smartAppInfo.setAprover(SmartAppInfo.Aprover.UNPUBLISH);
            }
            String id =smartAppInfoService.save(smartAppInfo);
            if(StringUtils.isBlank(id)){
                throw new HorizonBizException(Constants.Return.CREATE_PAY_API_INFO_FALSE);
            }
            result.getData().put("smartApp", smartAppInfo);
            //上链
            chainService.invokeSmartAppInfo();
        } catch (DuplicateKeyException e) {
            e.printStackTrace();
            result.setState(Constants.Return.ACCT_ID_REPEAT);
        } catch (HorizonBizException e) {
            result.setState(e.getError());
        }catch (Exception e) {
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }

    /**
     * 生成aid
     * @return
     */
    @RequestMapping("/getAID")
    @ResponseBody
    public String getAID(){
        Result result = new Result();
        String AID=UUID.randomUUID().toString();
        result.getData().put("AID",AID);
        return result.toJson();
    }
    /*参数非空验证
    * */
    private Result checkNull(SmartAppInfoVo smartAppInfoVo) {
            Result result = new Result();
            if (StringUtils.isBlank(smartAppInfoVo.getSmartAppName())){
                logger.info("--------------------参数错误:智能应用名称不能为空!-------------------------------------");
                result.setState(Constants.Return.SMARTAPPNAME_NULL);
            } else if (StringUtils.isBlank(smartAppInfoVo.getAid())) {
                logger.info("--------------------参数错误:AID不能为空!-------------------------------------");
                result.setState(Constants.Return.AID_IS_NULL);
            }else if (StringUtils.isBlank(smartAppInfoVo.getPkApiTypeInfo())) {
                logger.info("--------------------参数错误:服务接口类型不能为空!-------------------------------------");
                result.setState(Constants.Return.APITYPE_NULL);
            }else if (smartAppInfoVo.getCooperateCompany() == null ||smartAppInfoVo.getCooperateCompany().size()<=0) {
                logger.info("--------------------参数错误:合作方不能为空!-------------------------------------");
                result.setState(Constants.Return.COOPERATE_COMPANY_NULL);
            }else if (smartAppInfoVo.getStartDate() == null ) {
                logger.info("--------------------参数错误:有效期起始日期不能为空!-------------------------------------");
                result.setState(Constants.Return.STARTDATE_NULL);
            }else if (smartAppInfoVo.getEndDate() == null) {
                logger.info("--------------------参数错误:有效期结束日期不能为空!-------------------------------------");
                result.setState(Constants.Return.ENDDATE_NULL);
            }else if (smartAppInfoVo.getTaskNum() == null) {
                logger.info("--------------------参数错误:任务数量不能为空!-------------------------------------");
                result.setState(Constants.Return.TASKNUM_NULL);
            }else if (smartAppInfoVo.getTaskContent() == null) {
                logger.info("--------------------参数错误:任务内容不能为空!-------------------------------------");
                result.setState(Constants.Return.TASKCONTENT_NULL);
            }else if (smartAppInfoVo.getStatus() == null) {
                logger.info("--------------------参数错误:状态不能为空!-------------------------------------");
                result.setState(Constants.Return.STATUS_NULL);
            }
//            else if (StringUtils.isBlank(smartAppInfoVo.getApiDescription())) {
//                logger.info("--------------------参数错误:应用描述不能为空!-------------------------------------");
//                result.setState(Constants.Return.APIDESCRIPTION_NULL);
//            }

            return result;

    }

    /**
     * 封装数据
     * @param smartAppInfo
     * @param smartAppInfoVo
     * @param loginManager
     * @return
     */
    private SmartAppInfo initModel(SmartAppInfo smartAppInfo, SmartAppInfoVo smartAppInfoVo, LoginManager loginManager,Date date) throws HorizonBizException {
        smartAppInfo.setAid(smartAppInfoVo.getAid());
        //检查aid有没有被其他商户使用
        if(smartAppInfoService.checkAidUsed(smartAppInfoVo.getAid(),smartAppInfo.getPkCompanyInfo())){
            throw new HorizonBizException(Constants.Return.SMART_AID_USED);
        }

        
//        smartAppInfo.setApiType(smartAppInfoVo.getApiType());
        smartAppInfo.setPkApiTypeInfo(smartAppInfoVo.getPkApiTypeInfo());
        smartAppInfo.setCooperateCompany(smartAppInfoVo.getCooperateCompany());

        smartAppInfo.setStartDate(smartAppInfoVo.getStartDate());
        smartAppInfo.setEndDate(smartAppInfoVo.getEndDate());
        if(smartAppInfo.getStartDate().after(smartAppInfo.getEndDate())){
            //开始时间大于结束时间
            throw new HorizonBizException(Constants.Return.START_DATE_GREATER_THEM_END_DATE);
        }


        //改变智能应用的名称,获取当前用户属于的商户名称,格式="商户名称-智能应用名称"
        String smartAppName=loginManager.getCompanyInfo().getCompanyName() + "-" +smartAppInfoVo.getSmartAppName();
        //检查名称是否重复
        if(smartAppInfoService.checkSmartAppNameRepeat(smartAppName,smartAppInfo.getPkSmartAppInfo())){
            throw new HorizonBizException(Constants.Return.SMART_APP_NAME_REPEAT);
        }
        smartAppInfo.setSmartAppName(smartAppName);
        
//        //检查回调api内容是否合法
//        SmartJsonUtil.checkApi(smartAppInfoVo.getApiDescription());
        smartAppInfo.setApiDescription(smartAppInfoVo.getApiDescription());
        
        if(StringUtils.isNotBlank(smartAppInfoVo.getFailueApi())){
            //当失败回调api不为空时，需要检查api内容是否符合脚本格式
            SmartJsonUtil.checkApi(smartAppInfoVo.getFailueApi());
            smartAppInfo.setFailueApi(smartAppInfoVo.getFailueApi());
        }
        
        //检查任务数量和任务内容是否合法
        if(smartAppInfoVo.getTaskNum()<=0){//任务数量不能小于等于0
            throw new HorizonBizException(Constants.Return.SMART_TASK_NUM_ERROR);
        }
        if(smartAppInfoVo.getTaskContent()==null){//任务内容不能为空
            throw new HorizonBizException(Constants.Return.SMART_TASK_CONTENT_IS_NULL);
        }
        if(smartAppInfoVo.getTaskNum()!=smartAppInfoVo.getTaskContent().size()){//任务数量和任务内容数量必须相等
            throw new HorizonBizException(Constants.Return.SMART_TASK_NUM_CONTENT_COMPARE_ERROR);
        }
        //任务内容要符合脚本格式
        for (String content :smartAppInfoVo.getTaskContent()){
            SmartJsonUtil.checkApi(content);
        }
        smartAppInfo.setTaskNum(smartAppInfoVo.getTaskNum());
        smartAppInfo.setTaskContent(smartAppInfoVo.getTaskContent());

        //检查智能应用调用的服务是否可用且唯一
        smartAppInfo=checkApiUsable(smartAppInfo);
        return smartAppInfo;
    }

    /**
     * 检查服务是否可用且唯一
     * @param smartAppInfo
     * @throws HorizonBizException
     */
    private SmartAppInfo checkApiUsable(SmartAppInfo smartAppInfo) throws HorizonBizException {
        //检查是否有唯一有效的支付服务接口
        PayApiInfo payApiInfo = new PayApiInfo();
//        payApiInfo.setApiType(smartAppInfo.getApiType());//接口类型
        payApiInfo.setPkApiTypeInfo(smartAppInfo.getPkApiTypeInfo());//接口类型
        List<String> targetCompany = new ArrayList<>();
        targetCompany.add(smartAppInfo.getPkCompanyInfo());//目标商户
        payApiInfo.setTargetCompany(targetCompany);
        payApiInfo =payApiService.getPayApiInfo(payApiInfo);

        //检查是否有唯一有效的服务接口
        ServiceApiInfo serviceApiInfo = new ServiceApiInfo();
//        serviceApiInfo.setApiType(smartAppInfo.getApiType());//接口类型
        serviceApiInfo.setPkApiTypeInfo(smartAppInfo.getPkApiTypeInfo());//接口类型
        serviceApiInfo.setPkCompanyInfo(smartAppInfo.getCooperateCompany().get(0));//服务发布方
        targetCompany=new ArrayList<>();
        targetCompany.add(smartAppInfo.getPkCompanyInfo());//目标商户
        serviceApiInfo.setTargetCompany(targetCompany);
        serviceApiInfo=serviceApiService.getByCondition(serviceApiInfo);
        if(serviceApiInfo.getTargetType()==ServiceApiInfo.TargetType.OPEN){
            //如果服务接口目标类型是公开，不需要经过服务接口发布商户的审核，直接通过生效
            smartAppInfo.setAprover(SmartAppInfo.Aprover.APROVERED);
        }
        return smartAppInfo;
    }

    /**
     * 查询协作商户列表，如果有一个没有找到，抛异常，全找到，返回列表
     * @param cooperateCompany
     * @return
     */
    private List<CompanyInfo> checkCooperateCompnay(List<String> cooperateCompany) throws HorizonBizException {
        List<CompanyInfo> companyInfoList=new ArrayList<>();
        for(String item : cooperateCompany) {
            CompanyInfo ci = new CompanyInfo();
            ci.setPkCompanyInfo(item);
            ci = orgInfoService.getCompanyInfoByID(ci);
            if(ci == null) {
                throw new HorizonBizException(Constants.Return.COMPNAY_UNFOUND_ERROR);
            }
            companyInfoList.add(ci);
        }
        return companyInfoList;
    }

    /**
     * 更新智能合约
     * @param smartAppInfoVo
     * @param session
     * @return
     */
    @RequestMapping("/edit")
    @ResponseBody
    public String edit(@RequestBody SmartAppInfoVo smartAppInfoVo, HttpSession session){
        Result result = checkNull(smartAppInfoVo);
        if (!result.verify()){
            return result.toJson();
        }

        if (StringUtils.isBlank(smartAppInfoVo.getPkSmartAppInfo())) {
            result.setState(Constants.Return.PKSMARTAPPINFO_NULL);
            return result.toJson();
        }
        try {
            if(smartAppInfoVo.getCooperateCompany().size() > 1) {
                result.setState(Constants.Return.COOPERATECOMPANY_SIZE_BIGGER);
                return result.toJson();
            }

            //判断选取的合作方主键是否存在
            List<CompanyInfo> companyInfoList=checkCooperateCompnay(smartAppInfoVo.getCooperateCompany());
            //获取当前登录用户
            LoginManager loginManager=(LoginManager)session.getAttribute("loginManager");
            if(null==loginManager){
                throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
            }

            ManagerInfo manger = loginManager.getLoginUser();
            CompanyInfo company = loginManager.getCompanyInfo();
            Date date = new Date();

            //通过主键查到合约
            SmartAppInfo smartAppInfo = new SmartAppInfo();
            smartAppInfo.setPkSmartAppInfo(smartAppInfoVo.getPkSmartAppInfo());
            
            smartAppInfo = checkAuth(smartAppInfo, session);
/*            
            smartAppInfo=smartAppInfoService.getSmartAppInfoByID(smartAppInfo);
            if (smartAppInfo == null) {
                throw new HorizonBizException(Constants.Return.FIND_SMART_APP_INFO_FALSE);
            }
            if(!smartAppInfo.getPkCompanyInfo().equals(company.getPkCompanyInfo())){
                //登录者所在商户与合约发布商户不一致
                throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
            }*/
            //更新人和更新时间
            smartAppInfo.setUpdateDate(date);
            smartAppInfo.setUpdateManager(manger.getPkManagerInfo());
            smartAppInfo.setStatus(smartAppInfoVo.getStatus());

            /*if(smartAppInfo.getStatus().equals(SmartAppInfo.Status.TERMINATION)){
                throw new HorizonBizException(Constants.Return.SMART_APP_TERMINATION);
            }*/
            smartAppInfo.setStatus(smartAppInfoVo.getStatus());
            //封装数据
            smartAppInfo=initModel(smartAppInfo,smartAppInfoVo,loginManager,date);

            if(smartAppInfoVo.getIsPublish()){
                if(smartAppInfo.getAprover().equals(SmartAppInfo.Aprover.UNAPROVER)||smartAppInfo.getAprover().equals(SmartAppInfo.Aprover.APROVERED)){
                    //已经发布或已经审核的合约不能再发布
                    throw new HorizonBizException(Constants.Return.SMART_APP_PUBLISHED);
                }
                //发布
                //检查合约有效期唯一
                smartAppInfoService.checkUniqueness(smartAppInfo);
                smartAppInfo.setPublishDate(date);
                if(smartAppInfo.getAprover()!=SmartAppInfo.Aprover.APROVERED){
                    //未审核，
                    // 当智能应用使用的服务接口，目标类型为非公开类型时，需要发布接口的商户审核通过，智能应用才生效
                    smartAppInfo.setAprover(SmartAppInfo.Aprover.UNAPROVER);
                }
            }else{
                //保存
                smartAppInfo.setAprover(SmartAppInfo.Aprover.UNPUBLISH);
            }
            
            String id =smartAppInfoService.save(smartAppInfo);
            if(StringUtils.isBlank(id)){
                throw new HorizonBizException(Constants.Return.EDIT_SMART_APP_INFO_FALSE);
            }
            result.getData().put("smartApp", smartAppInfo);
            //上链
            chainService.invokeSmartAppInfo();
//            smartAppInfoService.update(smartAppInfo);
//            result.getData().put("smartAppInfo", smartAppInfo);
        } catch (DuplicateKeyException e) {
            e.printStackTrace();
            result.setState(Constants.Return.ACCT_ID_REPEAT);
        } catch (HorizonBizException e) {
            result.setState(e.getError());
        }catch (Exception e) {
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }

    @RequestMapping("/edit2")
    @ResponseBody
    public String edit2(@RequestBody SmartAppInfoVo smartAppInfoVo, HttpSession session){
        Result result = new Result();
        if (smartAppInfoVo.getEndDate() == null) {
            logger.info("--------------------参数错误:有效期结束日期不能为空!-------------------------------------");
            result.setState(Constants.Return.ENDDATE_NULL);
        } else if (smartAppInfoVo.getStatus() == null) {
            logger.info("--------------------参数错误:状态不能为空!-------------------------------------");
            result.setState(Constants.Return.STATUS_NULL);
        }
        SmartAppInfo smartAppInfo=new SmartAppInfo();
        smartAppInfo.setPkSmartAppInfo(smartAppInfoVo.getPkSmartAppInfo());
//        smartAppInfo=smartAppInfoService.getSmartAppInfoByID(smartAppInfo);
        try {
            smartAppInfo=checkAuth(smartAppInfo,session);
            if (smartAppInfoVo.getEndDate().before(smartAppInfoService.getSmartAppInfoByID(smartAppInfo).getEndDate())) {
                logger.info("--------------------参数错误:修改结束日期必须大于原来的结束日期!-------------------------------------");
                throw new HorizonBizException(Constants.Return.ENDDATE_SMALL);
            }
            smartAppInfo.setEndDate(smartAppInfoVo.getEndDate());
            smartAppInfo.setStatus(smartAppInfoVo.getStatus());
            if (smartAppInfoVo.getStatus()== SmartAppInfo.Status.NORMAL) {
                smartAppInfoService.checkUniqueness(smartAppInfo);
            }
            String id =smartAppInfoService.save(smartAppInfo);
            if(StringUtils.isBlank(id)){
                throw new HorizonBizException(Constants.Return.EDIT_SMART_APP_INFO_FALSE);
            }
            result.getData().put("smartApp", smartAppInfo);
            //上链
            chainService.invokeSmartAppInfo();
        }catch (HorizonBizException e) {
            result.setState(e.getError());
        }catch (DuplicateKeyException e) {
            e.printStackTrace();
            result.setState(Constants.Return.ACCT_ID_REPEAT);
        }catch (Exception e) {
            result.setState(Constants.Return.SYSTEM_ERR);
        }

        return result.toJson();
    }

    /**
     * 更新智能合约
     * @param smartAppInfoVo
     * @param session
     * @return
     */
    @RequestMapping("/publish")
    @ResponseBody
    public String publish(@RequestBody SmartAppInfoVo smartAppInfoVo, HttpSession session){
        Result result = new Result();
        //参数验证
        if (StringUtils.isBlank(smartAppInfoVo.getPkSmartAppInfo())) {
            result.setState(Constants.Return.PKSMARTAPPINFO_NULL);
            return result.toJson();
        }
        if(smartAppInfoVo.getCooperateCompany().size() > 1) {
            result.setState(Constants.Return.COOPERATECOMPANY_SIZE_BIGGER);
            return result.toJson();
        }
        try {

            //判断选取的合作方主键是否存在
            List<CompanyInfo> companyInfoList=checkCooperateCompnay(smartAppInfoVo.getCooperateCompany());
            //获取当前登录用户
            LoginManager loginManager=(LoginManager)session.getAttribute("loginManager");
            if(null==loginManager){
                throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
            }

            ManagerInfo manger = loginManager.getLoginUser();
            CompanyInfo company = loginManager.getCompanyInfo();
            Date date = new Date();

            //通过主键查到合约
            SmartAppInfo smartAppInfo = new SmartAppInfo();
            smartAppInfo.setPkSmartAppInfo(smartAppInfoVo.getPkSmartAppInfo());
            smartAppInfo=smartAppInfoService.getSmartAppInfoByID(smartAppInfo);
            if (smartAppInfo == null) {
                throw new HorizonBizException(Constants.Return.FIND_SMART_APP_INFO_FALSE);
            }
            if(!smartAppInfo.getPkCompanyInfo().equals(company.getPkCompanyInfo())){
                //登录者所在商户与合约发布商户不一致
                throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
            }
            //更新人和更新时间
            smartAppInfo.setUpdateDate(date);
            smartAppInfo.setUpdateManager(manger.getPkManagerInfo());

            //发布
            //检查合约有效期唯一
            smartAppInfoService.checkUniqueness(smartAppInfo);
            smartAppInfo.setPublishDate(date);
            //检查服务是否可用且唯一
            smartAppInfo=checkApiUsable(smartAppInfo);
            if(smartAppInfo.getAprover()!=SmartAppInfo.Aprover.APROVERED){
                //未审核
                // 当智能应用使用的服务接口，目标类型为非公开类型时，需要发布接口的商户审核通过，智能应用才生效
                smartAppInfo.setAprover(SmartAppInfo.Aprover.UNAPROVER);
            }

            if(smartAppInfo.getStatus().equals(SmartAppInfo.Status.TERMINATION)){
                throw new HorizonBizException(Constants.Return.SMART_APP_TERMINATION);
            }
            String id =smartAppInfoService.save(smartAppInfo);
            if(StringUtils.isBlank(id)){
                throw new HorizonBizException(Constants.Return.EDIT_SMART_APP_INFO_FALSE);
            }
            result.getData().put("smartApp", smartAppInfo);
            //上链
            chainService.invokeSmartAppInfo();
        } catch (DuplicateKeyException e) {
            e.printStackTrace();
            result.setState(Constants.Return.ACCT_ID_REPEAT);
        } catch (HorizonBizException e) {
            result.setState(e.getError());
        }catch (Exception e) {
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }

    /**
     * 删除
     * @param smartAppInfo
     * @param session
     * @return
     */
    @RequestMapping("/delete")
    @ResponseBody
    public String delete(@RequestBody SmartAppInfo smartAppInfo, HttpSession session){
        Result result = new Result();
        try {
            smartAppInfo = checkAuth(smartAppInfo, session);

            smartAppInfo.setStatus(SmartAppInfo.Status.TERMINATION);
            int resStr = smartAppInfoService.delete(smartAppInfo);
            if(resStr<=0){
                throw new HorizonBizException(Constants.Return.EDIT_SMART_APP_INFO_FALSE);
            }
            result.getData().put("updateCount",resStr);
            //上链
            chainService.invokeSmartAppInfo();
        } catch (DuplicateKeyException e) {
            e.printStackTrace();
            result.setState(Constants.Return.ACCT_ID_REPEAT);
        } catch (HorizonBizException e) {
            result.setState(e.getError());
        }catch (Exception e) {
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }

    /**
     * 查询明细
     * @param param
     * @param session
     * @return
     */
    @RequestMapping("/findById")
    @ResponseBody
    public String findbyId(@RequestBody SmartAppInfoVo param, HttpSession session){
        Result result = new Result();
        if(param.getPkSmartAppInfo() == null) {
            result.setState(Constants.Return.PKSMARTAPPINFO_NULL);
            return result.toJson();
        }else if (param.getFindType()==null){
            result.setState(Constants.Return.FINDTYPE_NULL);
            return result.toJson();
        }
        try {
            //获取当前登录用户
            ManagerInfo loginUser=(ManagerInfo)session.getAttribute("loginUser");
            if(null==loginUser){
                throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
            }
            
            SmartAppInfo smartAppInfo = new SmartAppInfo();
            smartAppInfo.setPkSmartAppInfo(param.getPkSmartAppInfo());
            smartAppInfo=checkAuth( smartAppInfo,  session);

            SmartAppInfoVo smartAppInfoVo =SmartJsonUtil.joToVo(smartAppInfo);

            PayApiInfo payApiInfo = new PayApiInfo();
//            payApiInfo.setApiType(smartAppInfo.getApiType());//接口类型
            payApiInfo.setPkApiTypeInfo(smartAppInfo.getPkApiTypeInfo());//接口类型
            if(param.getFindType()==1){
                payApiInfo.setPayType(PayApiInfo.PayType.SMART);//付费类型:智能发布方
            }else{
                payApiInfo.setPayType(PayApiInfo.PayType.SERVICE);//付费类型:服务接口发布方
            }
            List<String> targetCompany = new ArrayList<>();
            targetCompany.add(smartAppInfo.getPkCompanyInfo());//目标商户
            payApiInfo.setTargetCompany(targetCompany);
            Float costRate =payApiService.getRate(payApiInfo);
            smartAppInfoVo.setCostRate(costRate);
            
            ServiceApiInfo serviceApiInfo = new ServiceApiInfo();
//            serviceApiInfo.setApiType(smartAppInfo.getApiType());//接口类型
            serviceApiInfo.setPkApiTypeInfo(smartAppInfo.getPkApiTypeInfo());//接口类型
            serviceApiInfo.setPkCompanyInfo(smartAppInfo.getCooperateCompany().get(0));//服务发布方
            targetCompany=new ArrayList<>();
            targetCompany.add(smartAppInfo.getPkCompanyInfo());//目标商户
            serviceApiInfo.setTargetCompany(targetCompany);
            serviceApiInfo=serviceApiService.getByCondition(serviceApiInfo);
            smartAppInfoVo.setApiName(serviceApiInfo.getApiName());
            
            smartAppInfoVo.setApiDescription(smartAppInfo.getApiDescription());
            result.getData().put("smartAppInfoVo",smartAppInfoVo);
        } catch (DuplicateKeyException e) {
            e.printStackTrace();
            result.setState(Constants.Return.ACCT_ID_REPEAT);
        } catch (HorizonBizException e) {
            result.setState(e.getError());
        }catch (Exception e) {
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }


    /**
     * 分页查找
     * @param smartAppInfo
     * @param requst
     * @return
     */
    @RequestMapping("/findByPage")
    @ResponseBody
    public String findByPage(@RequestBody SmartAppInfo smartAppInfo,HttpServletRequest requst){
        Result result = new Result();
        
        try {
            LoginManager loginUser = (LoginManager)requst.getSession().getAttribute("loginManager");
            if(null==loginUser){
                throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
            }
            smartAppInfo.setPkCompanyInfo(loginUser.getLoginUser().getPkCompanyInfo());
            PageBo<SmartAppInfo> smartAppInfos = smartAppInfoService.findPage(smartAppInfo);
            result.getData().put("list",smartAppInfos);
        } catch (DuplicateKeyException e) {
            e.printStackTrace();
            result.setState(Constants.Return.ACCT_ID_REPEAT);
        } catch (HorizonBizException e) {
//            e.printStackTrace();
            result.setState(e.getError());
        }catch (Exception e) {
            e.printStackTrace();
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }

    /**
     * 审核
     * @param smartAppInfo
     * @param session
     * @return
     */
    @RequestMapping("/verify")
    @ResponseBody
    public String verify(@RequestBody SmartAppInfo smartAppInfo, HttpSession session){
        Result result = new Result();
        try {
            SmartAppInfo target=checkAuth( smartAppInfo,  session);
            if(target.getEndDate().before(new Date())){
                throw new HorizonBizException(Constants.Return.SMART_APP_INFO_OVERDUE);
            }
            smartAppInfo.setAprover(SmartAppInfo.Aprover.APROVERED);
            int resStr = smartAppInfoService.verify(smartAppInfo);
            if(resStr<=0){
                throw new HorizonBizException(Constants.Return.EDIT_SMART_APP_INFO_FALSE);
            }
            //上链
            chainService.invokeSmartAppInfo();
            result.getData().put("updateCount",resStr);
        } catch (DuplicateKeyException e) {
            e.printStackTrace();
            result.setState(Constants.Return.ACCT_ID_REPEAT);
        } catch (HorizonBizException e) {
            result.setState(e.getError());
        }catch (Exception e) {
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }

    /**
     * 检查权限和数据合法性
     * @param smartAppInfo
     * @param session
     * @throws HorizonBizException
     */
    private SmartAppInfo checkAuth(SmartAppInfo smartAppInfo, HttpSession session) throws HorizonBizException {
        if(smartAppInfo.getPkSmartAppInfo() == null) {
            throw new HorizonBizException(Constants.Return.PKSMARTAPPINFO_NULL);
        }
        //获取当前登录用户
        ManagerInfo loginUser=(ManagerInfo)session.getAttribute("loginUser");
        if(null==loginUser){
            throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
        }
        SmartAppInfo target = smartAppInfoService.getSmartAppInfoByID(smartAppInfo);
        if (target == null) {
            throw new HorizonBizException(Constants.Return.FIND_SMART_APP_INFO_FALSE);
        }
        if(!target.getPkCompanyInfo().equals(loginUser.getPkCompanyInfo())&&!target.getCooperateCompany().contains(loginUser.getPkCompanyInfo())){
            //不是智能发布商户，也不是协作商户
            throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
        }
        
        return target;
    }
}
