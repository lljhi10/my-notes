package com.value.silverchain.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Id;
import org.mongodb.morphia.annotations.Indexed;
import org.mongodb.morphia.utils.IndexDirection;

/**
 * 上链时间
 */
@Entity("chain_update_time")
@Data
public class ChainUpdateTime {
    @Id
    @JsonIgnore
    private ObjectId id;
    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_chain_update_time",dropDups = true)
    private String key;

    private String updateTime;
}
