package com.value.silverchain.controller;

import com.value.silverchain.common.Constants;
import com.value.silverchain.model.CompanyInfo;
import com.value.silverchain.model.ManagerInfo;
import com.value.silverchain.service.IBaseRoleService;
import com.value.silverchain.service.IOrgInfoService;
import com.value.silverchain.service.IUserAccountService;
import com.value.silverchain.util.MD5;
import com.value.silverchain.vo.LoginManager;
import com.value.silverchain.vo.LoginManagerPage;
import com.value.silverchain.vo.Password;
import com.value.silverchain.vo.Result;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/6/4
 * DESC:登录管理
 */
@Controller
@RequestMapping("/login/v1")
public class LoginControler {
    @Value("${tocken}")
    private String passTocken;
	
	final static Logger logger = LoggerFactory.getLogger(LoginControler.class);

    @Autowired
    private IOrgInfoService orgInfoService;

    @Autowired
    private IUserAccountService userAccountService;

    @Autowired
    private IBaseRoleService baseRoleService;

    @RequestMapping("version")
    @ResponseBody
    public String getVersion(){
        Result result = new Result();
        result.getData().put("version","0.0.1");
        return result.toJson();
    }

    @RequestMapping("login")
    @ResponseBody
    public String login(@RequestBody ManagerInfo managerInfo, HttpSession session){
        Result result = new Result();
        logger.info("--------------------用户登陆:start!-------------------------------------");
        try {
        	//参数校验
            if (StringUtils.isNotBlank(managerInfo.getManagerNumber()) && StringUtils.isNotBlank(managerInfo.getPassword()) &&
                        StringUtils.isNotBlank(managerInfo.getCompanyName())) {

                CompanyInfo company = new CompanyInfo();
                company.setCompanyName(managerInfo.getCompanyName());
//                company = orgInfoService.getCompanyInfoByName(company);
                company=orgInfoService.getCompanyInfo(company);

                if (company == null) {
                	logger.info("--------------------用户登陆失败：商户不存在！-------------------------------------");
                    result.setState(Constants.Return.USER_LOGIN_FAIL);
                    return result.toJson();
                } 
                if(company.getStatus().equals(CompanyInfo.Status.TERMINATION)) {
                	logger.info("--------------------用户登陆失败：该商户被终止！-------------------------------------");
                    result.setState(Constants.Return.USER_LOGIN_FAIL);
                    return result.toJson();
                }
                managerInfo.setPkCompanyInfo(company.getPkCompanyInfo());
                //查询此账号
                ManagerInfo mi = userAccountService.getByUserNumber(managerInfo);

                if(mi == null) {
                	logger.info("--------------------用户登陆失败：账号不存在！-------------------------------------");
                    result.setState(Constants.Return.USER_LOGIN_FAIL);
                    return result.toJson();
                }
                mi.setCompanyName(company.getCompanyName());
                if(!MD5.strMD5(managerInfo.getCompanyName()+managerInfo.getPassword()).equals(mi.getPassword())
                           || mi.getStatus().equals(ManagerInfo.Status.INVALID)) {
                	logger.info("--------------------用户登陆失败：密码错误！-------------------------------------");
                    result.setState(Constants.Return.USER_LOGIN_FAIL);
                    return result.toJson();
                }
                LoginManager loginManager = new LoginManager();

                loginManager.setLoginUser(mi);
                loginManager.setRoles(baseRoleService.getByKeys(mi.getPkRoles()));
                loginManager.setCompanyInfo(company);

                //登录成功,保存用户信息
                session.setAttribute("loginUser",mi);
                session.setAttribute("loginManager",loginManager);
                result.getData().put("loginManager",new LoginManagerPage(loginManager));
                result.getData().put("token",passTocken);
                logger.info("--------------------用户登陆成功！-------------------------------------");
            } else {
            	logger.info("--------------------用户登陆失败:关键参数为空!-------------------------------------");
                result.setState(Constants.Return.USER_LOGIN_FAIL);
                return result.toJson();
            }


        } catch (Exception e) {
        	logger.info("--------------------用户登陆失败:系统异常!-------------------------------------");
            result.setState(Constants.Return.USER_LOGIN_FAIL);
        }
        return result.toJson();
    }

    @RequestMapping("logout")
    @ResponseBody
    public String logout(HttpSession session){
        Result result = new Result();
        try {
            //注销登录,删除用户信息
            session.removeAttribute("loginUser");
            session.removeAttribute("loginManager");
            logger.info("--------------------用户注销!-------------------------------------");
        } catch (Exception e) {
            result.setState(Constants.Return.UNSUCCESS);
        }
        return result.toJson();
    }

    @RequestMapping("right")
    @ResponseBody
    public String right(HttpSession session){
        Result result = new Result();
        try {
            LoginManager lm = (LoginManager)session.getAttribute("loginManager");
            result.getData().put("paths",lm.getPaths());
            result.getData().put("companyType",lm.getCompanyInfo().getCompanyType());
            logger.info("--------------------获取用户权限!-------------------------------------");
        } catch (Exception e) {
            result.setState(Constants.Return.UNSUCCESS);
        }
        return result.toJson();
    }

    @RequestMapping("resetPassword")
    @ResponseBody
    public String resetPassword(@RequestBody ManagerInfo managerInfo,HttpSession session){
        Result result = new Result();
        try {
            LoginManager lm = (LoginManager)session.getAttribute("loginManager");

            ManagerInfo mi = userAccountService.getByUserID(managerInfo);
            if(mi != null && lm != null) {
                if(!lm.getLoginUser().getPkCompanyInfo().equals(mi.getPkCompanyInfo())){
                	logger.info("--------------------重置密码错误：管理员只能修改自己商户下的信息!-------------------------------------");
                    result.setState(Constants.Return.TIGTH_LESS_THAN);
                    return result.toJson();
                }
            }

            managerInfo.setDefaultKey(ManagerInfo.DefaultKey.YES);
            managerInfo.setPassword(MD5.strMD5(lm.getCompanyInfo().getCompanyName()+123456));

            int count = userAccountService.updatePassword(managerInfo);
            if (count <= 0){
                result.setState(Constants.Return.UNSUCCESS);
                logger.info("--------------------重置密码成功!-------------------------------------");
            }

        } catch (Exception e) {
            result.setState(Constants.Return.UNSUCCESS);
            logger.info("--------------------重置密码错误：系统异常!-------------------------------------");
        }
        return result.toJson();
    }

    @RequestMapping("editPassword")
    @ResponseBody
    public String editPassword(@RequestBody Password password, HttpSession session){
        Result result = new Result();
        String oldPwd = password.getOldPwd();
        String newPwdLast = password.getNewPwdLast();
        try {
        	//参数校验
            if(StringUtils.isBlank(oldPwd) || StringUtils.isBlank(newPwdLast) ||
                    oldPwd.length() < 6 || newPwdLast.length() < 6 ||
                    oldPwd.length() > 18 || newPwdLast.length() > 18) {
            	logger.info("--------------------修改密码错误：关键参数为空!-------------------------------------");
                result.setState(Constants.Return.PASSWORD_ERR);
                return result.toJson();
            }
            LoginManager lm = (LoginManager)session.getAttribute("loginManager");
            if (lm != null){
                ManagerInfo managerInfo = new ManagerInfo();
                //验证原密码
                if(MD5.strMD5(lm.getCompanyInfo().getCompanyName()+oldPwd).equals(lm.getLoginUser().getPassword())){
                    managerInfo.setDefaultKey(ManagerInfo.DefaultKey.NO);
                    managerInfo.setPassword(MD5.strMD5(lm.getCompanyInfo().getCompanyName()+newPwdLast));
                    managerInfo.setPkManagerInfo(lm.getLoginUser().getPkManagerInfo());
                }else{
                	logger.info("--------------------重置密码错误：原密码错误!-------------------------------------");
                    result.setState(Constants.Return.PASSWORD_NOTTRUE);
                    return result.toJson();
                }
                int count = userAccountService.updatePassword(managerInfo);
                if (count <= 0){
                    result.setState(Constants.Return.UNSUCCESS);
                    logger.info("--------------------重置密码失败!-------------------------------------");
                }else {
                    //注销登录,删除用户信息
                    session.removeAttribute("loginUser");
                    session.removeAttribute("loginManager");
                    logger.info("--------------------重置密码成功，注销当前登陆!-------------------------------------");
                    
                }
            }
        } catch (Exception e) {
        	logger.info("--------------------重置密码失败：系统异常!-------------------------------------");
            result.setState(Constants.Return.UNSUCCESS);
        }
        return result.toJson();
    }
}
