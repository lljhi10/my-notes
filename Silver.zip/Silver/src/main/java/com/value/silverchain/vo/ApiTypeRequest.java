package com.value.silverchain.vo;

import lombok.Data;

/**
 *  服务接口类型信息入参类
 */

@Data
public class ApiTypeRequest {

    private String pkApiTypeInfo;//服务接口类型主键
    
}