package com.value.silverchain.service;


import com.value.silverchain.bo.PageBo;
import com.value.silverchain.dto.ChainCompanyInfo;
import com.value.silverchain.dto.CompanyInfoDto;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.CompanyInfo;

import java.util.List;

/**
 * 商户管理
 */
public interface IOrgInfoService {

    /**
     * 保存商户
     * @param businessAccount
     * @return
     */
    String save(CompanyInfo businessAccount);

    /**
     * 按id查询商户
     * @param company
     * @return
     */
    CompanyInfo getCompanyInfoByID(CompanyInfo company);

    /**
     * 分页查询,可按商户名称模糊查询
     * @param param
     * @return
     */
    PageBo<CompanyInfo> findPage(CompanyInfo param);

    /**
     * 分页查询,按条件查所有
     * @param param
     * @return
     */
    PageBo<CompanyInfo> findAllPage(CompanyInfo param);

    /**
     * 查询所有发布了服务的商家
     * @param param
     * @return
     */
    PageBo<CompanyInfo> findAllServicePage(CompanyInfo param);

    /**
     * 逻辑删除商户
     * @param company
     * @return
     */
    String delete(CompanyInfo company);

    /**
     * 查询商户
     * @param company
     * @return
     */
    CompanyInfo getCompanyInfo(CompanyInfo company) throws HorizonBizException;

    /**
     * 更新商户
     * @param company
     * @return
     */
    int update(CompanyInfo company);

    /**
     * 按名称批量查询
     * @param keys
     * @return
     */
    String getComapnyName(List<String> keys);

    /**
     * 按住键查询只获取名称
     * @param key
     * @return
     */
    String getComapnyNameByKey(String key);

    /**
     * 真正删除
     * @param pkCompanyInfo
     */
    void realDelete(String pkCompanyInfo);

    /**
     * 根据主键查询所有
     * @param targetCompany
     * @return
     */
    List<CompanyInfoDto> findAllByKeys(List<String> targetCompany);

    /**
     * 商户字段唯一性验证
     * @param company
     * @return
     */
    CompanyInfo uniqueCheck(CompanyInfo company);

    /**
     * 根据商户号查商户信息
     * @param companyNo
     * @return
     */
    CompanyInfo getCompanyInfoByNo(String companyNo);

    /**
     * 链上信息更新到本地*/
    int updateFromChain(ChainCompanyInfo item);

    /**
     * 查询所有商户列表
     * @return
     * @param pkCompanyInfo
     */
    List<CompanyInfo> findAll(String pkCompanyInfo);
}
