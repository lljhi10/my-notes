package com.value.silverchain.exception;


import com.value.silverchain.common.Constants;
import com.value.silverchain.util.MD5;
import org.apache.commons.lang3.StringUtils;

public class HorizonBizException extends Exception {
    private Constants.Return error;
    private String errorMsg;

    public HorizonBizException(Constants.Return error) {
        this.error = error;
    }

    public HorizonBizException(Constants.Return error, String errorMsg) {
        this.error=error;
        this.errorMsg=errorMsg;
    }

    public Constants.Return getError() {
        return error;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public static void main(String[] args) {
        System.out.println(MD5.strMD5("测试商家A123456"));
    }
    
    public String getCodeAndMsg(){
        return "异常编码："+error.getCode()+"，异常信息："+error.getMsg()+(StringUtils.isNotBlank(errorMsg)?"，详细信息："+errorMsg+"。":"。");
    }

}
