package com.value.silverchain.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Id;
import org.mongodb.morphia.annotations.Indexed;
import org.mongodb.morphia.annotations.Transient;
import org.mongodb.morphia.utils.IndexDirection;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 *  节点配置信息
 */
@Entity("peer_setting")
@Data
public class PeerSettingInfo extends BasePage{
    public enum Status {
        NORMAL("正常"), PAUSE("暂停"), TERMINATION("终止");
        private String name;
        Status(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum Auth {
        NORMAL("开"), PAUSE("关");
        private String name;
        Auth(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum PeerType {
        LOCAL("本地节点"), SYNCH("同步节点");
        private String name;
        PeerType(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    @Id
    @JsonIgnore
    private ObjectId id;
    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_pkPeerSettingInfo",dropDups = true)
    private String pkPeerSettingInfo;//节点主键

    private String pkCompanyInfo;//商户主键
    private String peerSettingName;//节点名称

    private String ip;//节点IP地址

    private String chainAddr;//节点区域链地址


    private Status status;//节点状态：正常，暂停，终止

    private Auth publishedInterfaceAuth;//服务接口发布权限
    
    private Auth smartAppAuth;//智能应用管理权限

    private String agreementNo;//协议编码

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createDate;//创建时间

    private String createManager;//创建人

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateDate;//最后更新时间

    private String updateManager;//最后更新人
    private PeerType peerType;//节点类型：本地节点/同步节点
                    
    @Transient
    private String companyName;//商户名称

    public void setSid(String sid) {
        this.pkPeerSettingInfo = sid;
    }

    public Map getStatusObject() {
        Map map = new HashMap();
        map.put("name",this.status.getName());
        map.put("value",this.status);
        return map;
    }

    public Map getPublishedInterfaceAuthObject() {
        Map map = new HashMap();
        map.put("name",this.publishedInterfaceAuth.getName());
        map.put("value",this.publishedInterfaceAuth);
        return map;
    }

    public Map getSmartAppAuthObject() {
        Map map = new HashMap();
        if(this.smartAppAuth != null) {
            map.put("name",this.smartAppAuth.getName());
            map.put("value",this.smartAppAuth);
        }

        return map;
    }

    public Map getPeerTypeObject() {
        Map map = new HashMap();
        if(this.peerType != null){
            map.put("name",this.peerType.getName());
            map.put("value",this.peerType);
        }

        return map;
    }

    /**
     * 获取节点名称和IP端口，返回格式
     * 名称：xxx，IP端口：xxx.xxx.xxx.xxx:xxx
     * @return
     */
    public String getPeerNameAndIp(){
        return "名称:"+this.getPeerSettingName()+",IP端口："+this.getIp();
    }

    /**
     * 获取节点名称和IP端口，返回格式
     * [名称：xxx，IP端口：xxx.xxx.xxx.xxx:xxx]
     * @return
     */
    public String getPeerNameAndIpWithBorder(){
        return "["+this.getPeerNameAndIp()+"]";
    }
}