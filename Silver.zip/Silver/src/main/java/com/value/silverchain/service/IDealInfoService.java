package com.value.silverchain.service;

import com.value.silverchain.bo.PageBo;
import com.value.silverchain.model.DealInfo;
import com.value.silverchain.model.ManagerInfo;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:00
 * DESC:交易统计
 */
public interface IDealInfoService {

    /**
     * 分页查看
     * @param param
     * @return
     */
    PageBo<DealInfo> findPage(DealInfo param,ManagerInfo managerInfo);

    /**
     * 保存交易信息
     * @param dealInfo
     * @return
     */
    String save(DealInfo dealInfo);

    /**
     * 使用token查交易信息
     * @param dealToken
     * @return
     */
    DealInfo getDealByToken(String dealToken);

    /**
     * 使用dealNo查交易信息
     * @param dealNo
     * @return
     */
    DealInfo getDealByDealNo(String dealNo);
}
