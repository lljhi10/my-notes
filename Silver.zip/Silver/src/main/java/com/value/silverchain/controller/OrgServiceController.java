package com.value.silverchain.controller;

import com.mongodb.DuplicateKeyException;
import com.value.silverchain.common.Constants;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.ManagerInfo;
import com.value.silverchain.model.PayApiInfo;
import com.value.silverchain.model.ServiceApiInfo;
import com.value.silverchain.service.IChainService;
import com.value.silverchain.service.IPayApiService;
import com.value.silverchain.service.IServiceApiService;
import com.value.silverchain.util.DateHelper;
import com.value.silverchain.util.SmartJsonUtil;
import com.value.silverchain.vo.LoginManager;
import com.value.silverchain.vo.Result;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: ${date}
 * DESC:服务接口管理
 */
@RestController
@RequestMapping("/service/v1")
public class OrgServiceController {
    private Logger logger = LoggerFactory.getLogger(OrgServiceController.class);
    @Autowired
    private IPayApiService payApiService;
    @Autowired
    private IServiceApiService serviceApiService;
    @Autowired
    private IChainService chainService;

    /************************************************支付服务接口 start************************************************************/
    /**
     * 创建支付服务接口
     * @return payApiInfo
     */
    @RequestMapping("/pay/create")
    public String payCreate(@RequestBody PayApiInfo payApiInfo,HttpServletRequest requst){
        Result result = new Result();
        logger.info("--------------------新建支付接口:start-------------------------------------");
        result=checkNull(payApiInfo);
        if (!result.verify()){
            return result.toJson();
        }else{
            try {
                //检查API
                SmartJsonUtil.checkApi(payApiInfo.getApiDescription());
                //检查权限
                LoginManager loginManager = (LoginManager)requst.getSession().getAttribute("loginManager");
                if(null==loginManager){
                    throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
                }
                if(!loginManager.isUp()){//不是UP商户的管理员，没有创建权限
                    throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
                }
                Date date = new Date();
                ManagerInfo loginUser = loginManager.getLoginUser();
                payApiInfo.setPkPayApiInfo(UUID.randomUUID().toString());
                payApiInfo.setPkCompanyInfo(loginUser.getPkCompanyInfo());
                payApiInfo.setCreateManager(loginUser.getPkManagerInfo());
                payApiInfo.setCreateDate(date);
                payApiInfo.setStatus(PayApiInfo.Status.NORMAL);
                if(payApiInfo.getStartDate().after(payApiInfo.getEndDate())){
                    //开始时间大于结束时间
                    throw new HorizonBizException(Constants.Return.START_DATE_GREATER_THEM_END_DATE);
                }
                //如果选择发布状态则添加
                if(payApiInfo.getPublish().equals(PayApiInfo.Publish.EFFICIENT)){
//                    if(DateUtils.parseDate(DateFormatUtils.format(payApiInfo.getStartDate(),"yyyy-mm-dd")).before(DateUtils.parseDate(DateFormatUtils.format(new Date(),"yyyy-mm-dd")))){
//                        //开始时间小于当前时间
//                        throw new HorizonBizException(Constants.Return.START_DATE_LESS_THEM_CURRENT);
//                    }
                    if(DateHelper.compareDateWithFormat(payApiInfo.getEndDate(),date,DateHelper.DAY_FORMAT2)==-1){
                        //有效期结束时间小于当前时间
                        throw new HorizonBizException(Constants.Return.END_DATE_LESS_THEM_CURRENT);
                    }
                    //做唯一性检查，保证同一接口类型，同一目标商户(公开看成是一种商户)，同一时间段内正常的生效的支付接口记录只有一条
                    payApiService.checkUniqueness(payApiInfo);
                    payApiInfo.setPublishDate(date);
                }
                String id =payApiService.save(payApiInfo);
                if(StringUtils.isBlank(id)){
                    throw new HorizonBizException(Constants.Return.CREATE_PAY_API_INFO_FALSE);
                }
                //上链
                chainService.invokePayApiInfo();
            } catch (DuplicateKeyException e) {
                result.setState(Constants.Return.ACCT_ID_REPEAT);
            } catch (HorizonBizException e) {
                result.setState(e.getError());
            }catch (Exception e) {
                result.setState(Constants.Return.CREATE_PAY_API_INFO_FALSE);
            }
        }
        result.getData().put("payApiInfo", payApiInfo);
        return result.toJson();
    }

    private Result  checkNull(PayApiInfo payApiInfo){
        Result result = new Result();
        if (StringUtils.isBlank(payApiInfo.getPkApiTypeInfo())){
            logger.info("--------------------新建支付错误:服务接口类型不能为空！-------------------------------------");
            result.setState(Constants.Return.APITYPE_NULL);
        }else if (StringUtils.isBlank(payApiInfo.getApiName())){
            logger.info("--------------------新建支付错误:服务接口名称不能为空！-------------------------------------");
            result.setState(Constants.Return.APINAME_NULL);
        }else if (payApiInfo.getCostRate()==null){
            logger.info("--------------------新建支付错误:费率不能为空！-------------------------------------");
            result.setState(Constants.Return.COSTRATE_NULL);
        } else if ( payApiInfo.getServicePay()==null) {
            logger.info("--------------------新建支付错误:服务接口发布方不能为空！-------------------------------------");
            result.setState(Constants.Return.SERVICEPAY_NULL);
        } else if (payApiInfo.getSmartPay()==null) {
            logger.info("--------------------新建支付错误:智能应用发布方不能为空！-------------------------------------");
            result.setState(Constants.Return.SMARTPAY_NULL);
        } else if (payApiInfo.getStartDate()==null) {
            logger.info("--------------------新建支付错误:有效期起始日期不能为空！-------------------------------------");
            result.setState(Constants.Return.STARTDATE_NULL);
        } else if (payApiInfo.getEndDate()==null) {
            logger.info("--------------------新建支付错误:有效期结束日期不能为空！-------------------------------------");
            result.setState(Constants.Return.ENDDATE_NULL);
        } else if (StringUtils.isBlank(payApiInfo.getApiDescription())) {
            logger.info("--------------------新建支付错误:API接口不能为空！-------------------------------------");
            result.setState(Constants.Return.API_NULL);
        } else if (payApiInfo.getTargetType() == null
                ||(payApiInfo.getTargetType().equals(PayApiInfo.TargetType.TARGET)&&(payApiInfo.getTargetCompany()==null||payApiInfo.getTargetCompany().size()<=0))//指定商户时，没有商户数据
                ||(payApiInfo.getTargetType().equals(PayApiInfo.TargetType.OPEN)&&payApiInfo.getTargetCompany()!=null&&payApiInfo.getTargetCompany().size()>0)//公开时，商户有数据
                ) {
            logger.info("--------------------新建支付错误: 目标商户类型为空 或 指定商户时没有商户数据 或 公开时商户有数据！-------------------------------------");
            result.setState(Constants.Return.TARGETTYPE_NULL);
//        } else if (payApiInfo.getStatus()==null) {
//            logger.info("--------------------新建支付错误:接口状态不能为空！-------------------------------------");
//            result.setState(Constants.Return.STATUS_NULL);
        } else if (payApiInfo.getPublish()==null) {
            logger.info("--------------------新建支付错误:发布状态不能为空！-------------------------------------");
            result.setState(Constants.Return.PUBLISH_NULL);
        }
        return result;
    }



    /**
     * 更新未发布的支付服务接口
     * @param payApiInfo
     * @return
     */
    @RequestMapping("/pay/edit")
    @ResponseBody
    public String payEdit(@RequestBody PayApiInfo payApiInfo,HttpServletRequest requst){
        Result result =checkNull(payApiInfo);

        if (StringUtils.isBlank(payApiInfo.getPkPayApiInfo())){
            result.setState(Constants.Return.PKPAYAPIINFO_ERROR);
            logger.info("--------------------参数错误:主键不能为空！-------------------------------------");
            return result.toJson();
        }else if (!result.verify()){
            return result.toJson();
        }

        else {
            try {
                //检查API
                SmartJsonUtil.checkApi(payApiInfo.getApiDescription());
                //检查权限
                LoginManager loginManager = (LoginManager)requst.getSession().getAttribute("loginManager");
                if(null==loginManager){
                    throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
                }
                if(!loginManager.isUp()){//不是UP商户的管理员，没有更新权限
                    throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
                }
                if(payApiInfo.getStartDate().getTime() >= payApiInfo.getEndDate().getTime()){
                    //开始时间大于结束时间
                    throw new HorizonBizException(Constants.Return.START_DATE_GREATER_THEM_END_DATE);
                }

                ManagerInfo loginUser = loginManager.getLoginUser();
                payApiInfo.setUpdateManager(loginUser.getPkManagerInfo());
                String id  = payApiService.update(payApiInfo,loginUser);
                if(StringUtils.isBlank(id)){
                    throw new HorizonBizException(Constants.Return.EDIT_PAY_API_INFO_FALSE);
                }
                result.getData().put("payApiInfo", payApiInfo);
                //上链
                chainService.invokePayApiInfo();

            } catch (DuplicateKeyException e) {
                result.setState(Constants.Return.UPDATE_EXCEPTION);
            } catch (HorizonBizException e) {
//            e.printStackTrace();
                result.setState(e.getError());
            }catch (Exception e) {
                e.printStackTrace();
                result.setState(Constants.Return.EDIT_PAY_API_INFO_FALSE);
            }
        }

        return result.toJson();
    }

    /**
     * 更新已发布的支付服务接口
     * @param payApiInfo
     * @return
     */
    @RequestMapping("/pay/edit2")
    @ResponseBody
    public String payEdit2(@RequestBody PayApiInfo payApiInfo,HttpServletRequest requst){
        Result result =new Result();

        if (StringUtils.isBlank(payApiInfo.getPkPayApiInfo())){
            result.setState(Constants.Return.PKPAYAPIINFO_ERROR);
            logger.info("--------------------参数错误:主键不能为空！-------------------------------------");
            return result.toJson();
        }else if (payApiInfo.getEndDate()==null) {
            logger.info("--------------------新建支付错误:有效期结束日期不能为空！-------------------------------------");
            result.setState(Constants.Return.ENDDATE_NULL);
            return result.toJson();
        }else if (payApiInfo.getPublish()==null) {
            logger.info("--------------------新建支付错误:发布状态不能为空！-------------------------------------");
            result.setState(Constants.Return.PUBLISH_NULL);
            return result.toJson();
        }

        else {
            try {
                //检查API
                SmartJsonUtil.checkApi(payApiInfo.getApiDescription());
                //检查权限
                LoginManager loginManager = (LoginManager)requst.getSession().getAttribute("loginManager");
                if(null==loginManager){
                    throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
                }
                if(!loginManager.isUp()){//不是UP商户的管理员，没有更新权限
                    throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
                }
                if(payApiInfo.getStartDate().getTime() >= payApiInfo.getEndDate().getTime()){
                    //开始时间大于结束时间
                    throw new HorizonBizException(Constants.Return.START_DATE_GREATER_THEM_END_DATE);
                }

                if (payApiInfo.getEndDate().before(payApiService.getByKey(payApiInfo.getPkPayApiInfo()).getEndDate())) {
                    logger.info("--------------------参数错误:修改结束日期必须大于原来的结束日期!-------------------------------------");
                    throw new HorizonBizException(Constants.Return.ENDDATE_SMALL);
                }

                if (payApiInfo.getStatus() == PayApiInfo.Status.NORMAL) {
                    payApiService.checkUniqueness(payApiInfo);
                }

                ManagerInfo loginUser = loginManager.getLoginUser();
                payApiInfo.setUpdateManager(loginUser.getPkManagerInfo());
                String id  = payApiService.update(payApiInfo,loginUser);
                if(StringUtils.isBlank(id)){
                    throw new HorizonBizException(Constants.Return.EDIT_PAY_API_INFO_FALSE);
                }
                result.getData().put("payApiInfo", payApiInfo);
                //上链
                chainService.invokePayApiInfo();

            } catch (DuplicateKeyException e) {
                result.setState(Constants.Return.UPDATE_EXCEPTION);
            } catch (HorizonBizException e) {
//            e.printStackTrace();
                result.setState(e.getError());
            }catch (Exception e) {
                e.printStackTrace();
                result.setState(Constants.Return.API_ERROR);
            }
        }

        return result.toJson();
    }

    /**
     * 删除支付服务接口：注意，这里的删除是软删除，只把状态更改为终止
     * @param pkPayApiInfo
     * @return
     */
//    @RequestMapping("/pay/delete")
//    @ResponseBody
    public String payDelete(@RequestBody String pkPayApiInfo,HttpServletRequest requst){
        Result result = new Result();
        try {
            if (StringUtils.isBlank(pkPayApiInfo)){
                throw new HorizonBizException(Constants.Return.PKPAYAPIINFO_ERROR);
            }
            LoginManager loginManager = (LoginManager)requst.getSession().getAttribute("loginManager");
            if(null==loginManager){
                throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
            }
            if(!loginManager.isUp()){//不是UP商户的管理员，没有更新权限
                throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
            }
            ManagerInfo loginUser = loginManager.getLoginUser();

            PayApiInfo targetInfo = payApiService.getByKey(pkPayApiInfo);
            if (targetInfo == null) {
                throw new HorizonBizException(Constants.Return.FIND_PAY_API_INFO_FALSE);
            }
            if (targetInfo.getStatus().equals(PayApiInfo.Status.TERMINATION)){
                //已经终止的服务接口不能删除
                throw new HorizonBizException(Constants.Return.PAY_API_INFO_TERMINATION);
            }
            if (!targetInfo.getPkCompanyInfo().equals(loginUser.getPkCompanyInfo())){
                //不是登录者所在商户的服务接口不能删除
                throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
            }
            targetInfo.setStatus(PayApiInfo.Status.TERMINATION);
            targetInfo.setUpdateDate(new Date());
            targetInfo.setUpdateManager(loginUser.getPkManagerInfo());
            
            String id =payApiService.save(targetInfo);
            if(StringUtils.isBlank(id)){
                throw new HorizonBizException(Constants.Return.DELETE_PAY_API_INFO_FALSE);
            }
            //上链
            chainService.invokePayApiInfo();
//            result.getData().put("payApiInfo", payApiInfo);
        } catch (DuplicateKeyException e) {
            //throw new HorizonBizException(USEID_REPEAT);
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        } catch (HorizonBizException e) {
//            e.printStackTrace();
            result.setState(e.getError());
        }catch (Exception e) {
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }

    /**
     * 根据主键查询支付服务接口
     * @param pkPayApiInfo
     * @return
     */
    @RequestMapping("/pay/find")
    @ResponseBody
    public String payFindByKey(@RequestBody String pkPayApiInfo){
        Result result = new Result();
        try {
            if (StringUtils.isBlank(pkPayApiInfo)){
                throw new HorizonBizException(Constants.Return.PKPAYAPIINFO_ERROR);
            }
            PayApiInfo payApiInfo = payApiService.getByKey(pkPayApiInfo);
            if (payApiInfo == null) {
                throw new HorizonBizException(Constants.Return.FIND_PAY_API_INFO_FALSE);
            }
            result.getData().put("payApiInfo", payApiInfo);
        } catch (DuplicateKeyException e) {
            //throw new HorizonBizException(USEID_REPEAT);
            result.setState(Constants.Return.QUEYR_EXCEPTION);
        } catch (HorizonBizException e) {
//            e.printStackTrace();
            result.setState(e.getError());
        }catch (Exception e) {
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }

    /**
     * 查询支付服务接口列表
     * @param param
     * @return
     */
    @RequestMapping("/pay/page")
    @ResponseBody
    public String payPage(@RequestBody PayApiInfo param,HttpServletRequest requst){
        Result result = new Result();
        try {
            LoginManager loginUser = (LoginManager)requst.getSession().getAttribute("loginManager");
            if(null==loginUser){
                throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
            }
            if (!loginUser.isUp()){
                //不是UP管理员，只显示公开和目标商户包含登录人所在商户的支付接口
                param.setPkCompanyInfo(loginUser.getLoginUser().getPkCompanyInfo());
            }else {
                param.setPkCompanyInfo(null);
            }
            result.getData().put("list", payApiService.findPage(param));
        } catch (DuplicateKeyException e) {
            //throw new HorizonBizException(USEID_REPEAT);
            result.setState(Constants.Return.QUEYR_EXCEPTION);
        } catch (HorizonBizException e) {
            e.printStackTrace();
            result.setState(e.getError());
        }catch (Exception e) {
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }

    
    
    /**
     * 查询平台手续费
     * @param param
     * @return
     */
    @RequestMapping("/pay/rate")
    @ResponseBody
    public String findByKey(@RequestBody PayApiInfo param){
        Result result=checkRateNull(param);
        if (result.verify()){
            try {
                Float costRate = payApiService.getRate(param);
                result.getData().put("costRate", costRate);
            } catch (DuplicateKeyException e) {
                //throw new HorizonBizException(USEID_REPEAT);
                result.setState(Constants.Return.QUEYR_EXCEPTION);
            } catch (HorizonBizException e) {
                result.setState(e.getError());
            } catch (Exception e) {
                result.setState(Constants.Return.SYSTEM_ERR);
            }
        }

        return result.toJson();
    }

    private Result checkRateNull(PayApiInfo param) {
        Result result = new Result();
        if (param.getTargetCompany() == null||param.getTargetCompany().size() <= 0) {
            logger.info("--------------------参数错误:目标商户为空！-------------------------------------");
            result.setState(Constants.Return.TARGETCOMPANY_NULL);
        } else if (StringUtils.isBlank(param.getPkApiTypeInfo())) {
            logger.info("--------------------参数错误:服务接口类型不能为空！-------------------------------------");
            result.setState(Constants.Return.APITYPE_NULL);
        } else if (param.getPayType()==null) {
            logger.info("--------------------参数错误:支付类型不能为空！-------------------------------------");
            result.setState(Constants.Return.PAYTYPE_NULL);
        }
        return result;
    }

    /************************************************支付服务接口 end ************************************************************/

    /************************************************发布服务接口 start************************************************************/


    /**
     * 创建服务接口
     * @return payApiInfo
     */
    @RequestMapping("/service/create")
    public String serviceCreate(@RequestBody ServiceApiInfo serviceApiInfo,HttpServletRequest requst){
        Result result = checkServiceApiNull(serviceApiInfo);
        if (result.verify())
        {
            try {
                //检查API
//                SmartJsonUtil.checkApi(serviceApiInfo.getApiDescription());
                //检查权限
                LoginManager loginManager = (LoginManager)requst.getSession().getAttribute("loginManager");
                if(null==loginManager){
                    throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
                }
                Date date = new Date();
                ManagerInfo loginUser = loginManager.getLoginUser();
                serviceApiInfo.setPkServiceApiInfo(UUID.randomUUID().toString());
                serviceApiInfo.setPkCompanyInfo(loginUser.getPkCompanyInfo());
                serviceApiInfo.setCreateManager(loginUser.getPkManagerInfo());
                serviceApiInfo.setCreateDate(date);
                serviceApiInfo.setStatus(ServiceApiInfo.Status.NORMAL);

                if(serviceApiInfo.getStartDate().after(serviceApiInfo.getEndDate())){
                    //开始时间大于结束时间
                    throw new HorizonBizException(Constants.Return.START_DATE_GREATER_THEM_END_DATE);
                }

                //如果选择发布状态折添加
                if(ServiceApiInfo.Publish.EFFICIENT.equals(serviceApiInfo.getPublish())){
//                    if(DateUtils.parseDate(DateFormatUtils.format(serviceApiInfo.getStartDate(),"yyyy-mm-dd")).before(DateUtils.parseDate(DateFormatUtils.format(new Date(),"yyyy-mm-dd")))){
//                        //开始时间小于当前时间
//                        throw new HorizonBizException(Constants.Return.START_DATE_LESS_THEM_CURRENT);
//                    }
                    if(serviceApiInfo.getStartDate().after(serviceApiInfo.getEndDate())){
                        //开始时间大于结束时间
                        throw new HorizonBizException(Constants.Return.START_DATE_GREATER_THEM_END_DATE);
                    }
                    if(serviceApiInfo.getEndDate().getTime() <= new Date().getTime()){
                        //有效期结束时间小于当前时间
                        throw new HorizonBizException(Constants.Return.END_DATE_LESS_THEM_CURRENT);
                    }
                    //检查唯一性,保证在同一商户下，同一接口类型，同一目标商户(公开看成是一种商户)，同一时间段内正常的生效的支付接口记录只有一条
                    serviceApiService.checkUniqueness(serviceApiInfo);
                    serviceApiInfo.setPublishDate(date);
                }
                String id =serviceApiService.save(serviceApiInfo);
                if(StringUtils.isBlank(id)){
                    throw new HorizonBizException(Constants.Return.CREATE_SERVICE_API_INFO_FALSE);
                }
                //上链
                chainService.invokeServiceApiInfo();
            } catch (DuplicateKeyException e) {
                result.setState(Constants.Return.ACCT_ID_REPEAT);
            } catch (HorizonBizException e) {
//            e.printStackTrace();
                result.setState(e.getError());
            }catch (Exception e) {
                e.printStackTrace();
                result.setState(Constants.Return.UNSUCCESS);
            }
            result.getData().put("serviceApiInfo", serviceApiInfo);
        }
        return result.toJson();
    }

    private Result checkServiceApiNull(ServiceApiInfo serviceApiInfo) {
        Result result = new Result();
        if (StringUtils.isBlank(serviceApiInfo.getPkApiTypeInfo())) {
            logger.info("--------------------参数错误:服务接口类型不能为空！-------------------------------------");
            result.setState(Constants.Return.APITYPE_NULL);
        } else
        if (StringUtils.isBlank(serviceApiInfo.getApiName())) {
            logger.info("--------------------参数错误:服务接口名称不能为空！-------------------------------------");
            result.setState(Constants.Return.APINAME_NULL);
        }else
        if (StringUtils.isBlank(serviceApiInfo.getDescription())) {
            logger.info("--------------------参数错误:服务接口描述不能为空！-------------------------------------");
            result.setState(Constants.Return.DESCRIPTION_NULL);
        }else
        if (serviceApiInfo.getPrice()==null){
            logger.info("--------------------参数错误:销售价格不能为空！-------------------------------------");
            result.setState(Constants.Return.PRICE_NULL);
        }else
        if (serviceApiInfo.getTargetType() == null
                    ||(serviceApiInfo.getTargetType().equals(PayApiInfo.TargetType.TARGET)&&(serviceApiInfo.getTargetCompany()==null||serviceApiInfo.getTargetCompany().size()<=0))//指定商户时，没有商户数据
                    ||(serviceApiInfo.getTargetType().equals(PayApiInfo.TargetType.OPEN)&&serviceApiInfo.getTargetCompany()!=null&&serviceApiInfo.getTargetCompany().size()>0)//公开时，商户有数据) 
                ) {
            logger.info("--------------------参数错误:指定商户时，无商户数据！-------------------------------------");
            result.setState(Constants.Return.TARGETTYPE_NULL);
        }else
//        if (serviceApiInfo.getAmount() == null) {
//            logger.info("--------------------参数错误:销售额度不能为空！-------------------------------------");
//            result.setState(Constants.Return.AMOUNT_NULL);
//        } else
        if (serviceApiInfo.getStartDate()==null) {
            logger.info("--------------------参数错误:开始时间不能为空！-------------------------------------");
            result.setState(Constants.Return.STARTDATE_NULL);
        } else
        if (serviceApiInfo.getEndDate() == null) {
            logger.info("--------------------参数错误:结束时间不能为空！-------------------------------------");
            result.setState(Constants.Return.ENDDATE_NULL);
        } else
//        if (serviceApiInfo.getPublish()==null) {
//            logger.info("--------------------参数错误:发布状态不能为空！-------------------------------------");
//            result.setState(Constants.Return.PUBLISH_NULL);
//        } else
        if (StringUtils.isBlank(serviceApiInfo.getPath())) {
            logger.info("--------------------参数错误:调用地址不能为空！-------------------------------------");
            result.setState(Constants.Return.PATH_NULL);
        } else
        if (serviceApiInfo.getMethod()==null) {
            logger.info("--------------------参数错误:请求方式不能为空！-------------------------------------");
            result.setState(Constants.Return.METHOD_NULL);
        } else
        if (serviceApiInfo.getContentType()==null) {
            logger.info("--------------------参数错误:返回类型不能为空！-------------------------------------");
            result.setState(Constants.Return.CONTENT_TYPE_NULL);
        } else
        if (StringUtils.isBlank(serviceApiInfo.getParamExplain())) {
            logger.info("--------------------参数错误:参数说明不能为空！-------------------------------------");
            result.setState(Constants.Return.PARAM_EXPLAIN_NULL);
        } else
        if (StringUtils.isBlank(serviceApiInfo.getRequestMessageFormat())) {
            logger.info("--------------------参数错误:请求报文格式不能为空！-------------------------------------");
            result.setState(Constants.Return.REQUEST_MESSAGE_FORMAT_NULL);
        } else
        if (StringUtils.isBlank(serviceApiInfo.getResponseMessageFormat())) {
            logger.info("--------------------参数错误:返回报文格式不能为空！-------------------------------------");
            result.setState(Constants.Return.RESPONSE_MESSAGE_FORMAT_NULL);
        } else
        if (StringUtils.isBlank(serviceApiInfo.getErrorCodeDefinition())) {
            logger.info("--------------------参数错误:错误码定义不能为空！-------------------------------------");
            result.setState(Constants.Return.ERROR_CODE_DEFINITION_NULL);
        } else
        if (StringUtils.isBlank(serviceApiInfo.getReportDefinition())) {
            logger.info("--------------------参数错误:订单报表定义不能为空！-------------------------------------");
            result.setState(Constants.Return.REPORT_DEFINITION_NULL);
        } 
//        else
//        if (StringUtils.isBlank(serviceApiInfo.getApiDescription())) {
//            logger.info("--------------------参数错误:api接口不能为空！-------------------------------------");
//            result.setState(Constants.Return.API_NULL);
//        } 

        return result;
    }

    /**
     * 更新未发布服务接口
     * @param serviceApiInfo
     * @return
     */
    @RequestMapping("/service/edit")
    @ResponseBody
    public String serviceEdit(@RequestBody ServiceApiInfo serviceApiInfo,HttpServletRequest requst){
        Result result = checkServiceApiNull(serviceApiInfo);
        if(StringUtils.isBlank(serviceApiInfo.getPkServiceApiInfo())){
            result.setState(Constants.Return.PKSERVICEAPIINFO_ERROR);
        } else if (result.verify()) {
            try {
                //检查API
//                SmartJsonUtil.checkApi(serviceApiInfo.getApiDescription());
                //检查权限
                LoginManager loginManager = (LoginManager) requst.getSession().getAttribute("loginManager");
                if (null == loginManager) {
                    throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
                }
//                if(loginManager.isUp()){//UP商户的管理员，没有更新服务接口权限
//                    throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
//                }
                if (!loginManager.getLoginUser().getPkCompanyInfo().equals(serviceApiInfo.getPkCompanyInfo())) {//不是接口发布商户的管理员，没权限修改接口
                    throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
                }
                ManagerInfo loginUser = loginManager.getLoginUser();
                serviceApiInfo.setUpdateManager(loginUser.getPkManagerInfo());

                if (serviceApiInfo.getStartDate().after(serviceApiInfo.getEndDate())) {
                    //开始时间大于结束时间
                    throw new HorizonBizException(Constants.Return.START_DATE_GREATER_THEM_END_DATE);
                }

                String id = serviceApiService.update(serviceApiInfo, loginUser);
                if (StringUtils.isBlank(id)) {
                    throw new HorizonBizException(Constants.Return.EDIT_SERVICE_API_INFO_FALSE);
                }
                result.getData().put("serviceApiInfo", serviceApiInfo);
                //上链
                chainService.invokeServiceApiInfo();


            } catch (DuplicateKeyException e) {
                result.setState(Constants.Return.UPDATE_EXCEPTION);
            } catch (HorizonBizException e) {
//            e.printStackTrace();
                result.setState(e.getError());
            } catch (Exception e) {
                result.setState(Constants.Return.SYSTEM_ERR);
            }
        }

        return result.toJson();
    }
    /**
     * 更新已发布服务接口
     * @param serviceApiInfo
     * @return
     */
    @RequestMapping("/service/edit2")
    @ResponseBody
    public String serviceEdit2(@RequestBody ServiceApiInfo serviceApiInfo,HttpServletRequest requst){
        Result result = new Result();
        if(StringUtils.isBlank(serviceApiInfo.getPkServiceApiInfo())){
            result.setState(Constants.Return.PKSERVICEAPIINFO_ERROR);
        }  else if (serviceApiInfo.getStatus() == null) {
            logger.info("--------------------参数错误:状态不能为空！-------------------------------------");
            result.setState(Constants.Return.STATUS_NULL);
        } else if (serviceApiInfo.getEndDate() == null) {
            logger.info("--------------------参数错误:结束时间不能为空！-------------------------------------");
            result.setState(Constants.Return.ENDDATE_NULL);
        } else if (result.verify()) {
            try {
                //检查API
//                SmartJsonUtil.checkApi(serviceApiInfo.getApiDescription());
                //检查权限
                LoginManager loginManager = (LoginManager) requst.getSession().getAttribute("loginManager");
                if (null == loginManager) {
                    throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
                }
//                if(loginManager.isUp()){//UP商户的管理员，没有更新服务接口权限
//                    throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
//                }
                if (!loginManager.getLoginUser().getPkCompanyInfo().equals(serviceApiInfo.getPkCompanyInfo())) {//不是接口发布商户的管理员，没权限修改接口
                    throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
                }
                ManagerInfo loginUser = loginManager.getLoginUser();
                serviceApiInfo.setUpdateManager(loginUser.getPkManagerInfo());

                if (serviceApiInfo.getStartDate().after(serviceApiInfo.getEndDate())) {
                    //开始时间大于结束时间
                    throw new HorizonBizException(Constants.Return.START_DATE_GREATER_THEM_END_DATE);
                }

                if (serviceApiInfo.getEndDate().before(serviceApiService.getByKey(serviceApiInfo.getPkServiceApiInfo()).getEndDate())) {
                    logger.info("--------------------参数错误:修改结束日期必须大于原来的结束日期!-------------------------------------");
                    throw new HorizonBizException(Constants.Return.ENDDATE_SMALL);
                }

                if (serviceApiInfo.getStatus() == ServiceApiInfo.Status.NORMAL) {
                    serviceApiService.checkUniqueness(serviceApiInfo);
                }

                String id = serviceApiService.update(serviceApiInfo, loginUser);
                if (StringUtils.isBlank(id)) {
                    throw new HorizonBizException(Constants.Return.EDIT_SERVICE_API_INFO_FALSE);
                }
                result.getData().put("serviceApiInfo", serviceApiInfo);
                //上链
                chainService.invokeServiceApiInfo();


            } catch (DuplicateKeyException e) {
                result.setState(Constants.Return.UPDATE_EXCEPTION);
            } catch (HorizonBizException e) {
//            e.printStackTrace();
                result.setState(e.getError());
            } catch (Exception e) {
                result.setState(Constants.Return.SYSTEM_ERR);
            }
        }

        return result.toJson();
    }

    /**
     * 发布服务接口
     * @param serviceApiInfo
     * @return
     */
    @RequestMapping("/service/publish")
    @ResponseBody
    public String servicePublish(@RequestBody ServiceApiInfo serviceApiInfo,HttpServletRequest requst){
        Result result = new Result();
        try {
            if (StringUtils.isBlank(serviceApiInfo.getPkServiceApiInfo())){
                throw new HorizonBizException(Constants.Return.PKSERVICEAPIINFO_ERROR);
            }
            ManagerInfo loginUser = (ManagerInfo)requst.getSession().getAttribute("loginUser");
            if(null==loginUser){
                throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
            }

            ServiceApiInfo targetInfo = serviceApiService.getByKey(serviceApiInfo.getPkServiceApiInfo());
            if (targetInfo == null) {
                throw new HorizonBizException(Constants.Return.FIND_SERVICE_API_INFO_FALSE);
            }
            if (targetInfo.getStatus().equals(ServiceApiInfo.Status.TERMINATION)){
                //已经终止的服务接口不能删除
                throw new HorizonBizException(Constants.Return.SERVICE_API_INFO_TERMINATION);
            }
            if (!targetInfo.getPkCompanyInfo().equals(loginUser.getPkCompanyInfo())){
                //不是登录者所在商户的服务接口不能发布
                throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
            }
            if (targetInfo.getPublish().equals(ServiceApiInfo.Publish.EFFICIENT)){
                //服务接口已经发布
                throw new HorizonBizException(Constants.Return.SERVICE_API_INFO_PUBLISHED);
            }
            Date date = new Date();
            targetInfo.setUpdateManager(loginUser.getPkManagerInfo());
            targetInfo.setUpdateDate(date);
            targetInfo.setPublish(ServiceApiInfo.Publish.EFFICIENT);
            targetInfo.setPublishDate(date);
/*            if(serviceApiInfo.getStartDate().getTime() <= date.getTime()){
                //开始时间小于当前时间
                throw new HorizonBizException(Constants.Return.START_DATE_LESS_THEM_CURRENT);
            }*/
            //检查唯一性,保证在同一商户下，同一接口类型，同一目标商户(公开看成是一种商户)，同一时间段内正常的生效的支付接口记录只有一条
            serviceApiService.checkUniqueness(targetInfo);

            String id =serviceApiService.save(targetInfo);
            if(StringUtils.isBlank(id)){
                throw new HorizonBizException(Constants.Return.EDIT_SERVICE_API_INFO_FALSE);
            }
            result.getData().put("serviceApiInfo", serviceApiInfo);
            //上链
            chainService.invokeServiceApiInfo();

        } catch (DuplicateKeyException e) {
            e.printStackTrace();
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        } catch (HorizonBizException e) {
            result.setState(e.getError());
        }catch (Exception e) {
            e.printStackTrace();
            result.setState(Constants.Return.SYSTEM_ERR);
        }

        return result.toJson();
    }

    /**
     * 删除服务接口：注意，这里的删除是软删除，只把状态更改为终止
     * @param pkServiceApiInfo
     * @return
     */
//    @RequestMapping("/service/delete")
//    @ResponseBody
    public String serviceDelete(@RequestBody String pkServiceApiInfo,HttpServletRequest requst){
        Result result = new Result();
        try {
            if (StringUtils.isBlank(pkServiceApiInfo)){
                throw new HorizonBizException(Constants.Return.PKSERVICEAPIINFO_ERROR);
            }
            ManagerInfo loginUser = (ManagerInfo)requst.getSession().getAttribute("loginUser");
            if(null==loginUser){
                throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
            }

            ServiceApiInfo targetInfo = serviceApiService.getByKey(pkServiceApiInfo);
            if (targetInfo == null) {
                throw new HorizonBizException(Constants.Return.FIND_SERVICE_API_INFO_FALSE);
            }
            if (targetInfo.getStatus().equals(PayApiInfo.Status.TERMINATION)){
                //已经终止的服务接口不能删除
                throw new HorizonBizException(Constants.Return.SERVICE_API_INFO_TERMINATION);
            }
            if (!targetInfo.getPkCompanyInfo().equals(loginUser.getPkCompanyInfo())){
                //不是登录者所在商户的服务接口不能删除
                throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
            }
            targetInfo.setStatus(ServiceApiInfo.Status.TERMINATION);
            targetInfo.setUpdateDate(new Date());
            targetInfo.setUpdateManager(loginUser.getPkManagerInfo());
            
            String id =serviceApiService.save(targetInfo);
            if(StringUtils.isBlank(id)){
                throw new HorizonBizException(Constants.Return.DELETE_SERVICE_API_INFO_FALSE);
            }
            result.getData().put("serviceApiInfo", targetInfo);
            //上链
            chainService.invokeServiceApiInfo();
        } catch (DuplicateKeyException e) {
            //throw new HorizonBizException(USEID_REPEAT);
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        } catch (HorizonBizException e) {
//            e.printStackTrace();
            result.setState(e.getError());
        }catch (Exception e) {
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }

    /**
     * 根据主键查询服务接口
     * @param pkServiceApiInfo
     * @return
     */
    @RequestMapping("/service/find")
    @ResponseBody
    public String serviceFindByKey(@RequestBody String pkServiceApiInfo,HttpServletRequest requst){
        Result result = new Result();
        try {
            if (StringUtils.isBlank(pkServiceApiInfo)){
                throw new HorizonBizException(Constants.Return.PKSERVICEAPIINFO_ERROR);
            }
            LoginManager loginUser = (LoginManager)requst.getSession().getAttribute("loginManager");
            if(null==loginUser){
                throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
            }
            ServiceApiInfo serviceApiInfo = serviceApiService.getByKey(pkServiceApiInfo);
            if (serviceApiInfo == null) {
                throw new HorizonBizException(Constants.Return.FIND_SERVICE_API_INFO_FALSE);
            }
            
            PayApiInfo param = new PayApiInfo();
//            param.setApiType(serviceApiInfo.getApiType());
            param.setPkApiTypeInfo(serviceApiInfo.getPkApiTypeInfo());
            List<String> targetCompany =new ArrayList<String>();
//            targetCompany.add(serviceApiInfo.getPkCompanyInfo());
            targetCompany.add(loginUser.getLoginUser().getPkCompanyInfo());
            param.setTargetCompany(targetCompany);
            if(serviceApiInfo.getPkCompanyInfo().equals(loginUser.getLoginUser().getPkCompanyInfo())){
                //登录者所属商户，是服务的发布商户，取服务发布方费率
                param.setPayType(PayApiInfo.PayType.SERVICE);
            }else{
                //登录者所属商户，不是服务的发布商户，即为服务的目标商户，取智能应用发布方费率
                param.setPayType(PayApiInfo.PayType.SMART);
            }
            
//            Float costRate = payApiService.getRate(param);
//            
//            serviceApiInfo.setHandlingCharge(costRate);//平台手续费率
            result.getData().put("serviceApiInfo", serviceApiInfo);
        } catch (DuplicateKeyException e) {
            //throw new HorizonBizException(USEID_REPEAT);
            result.setState(Constants.Return.QUEYR_EXCEPTION);

        } catch (HorizonBizException e) {
//            e.printStackTrace();
            result.setState(e.getError());
        }catch (Exception e) {
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        
        return result.toJson();
    }

    /**
     * 查询服务接口列表
     * @param param
     * @return
     */
    @RequestMapping("/service/page")
    @ResponseBody
    public String servicePage(@RequestBody ServiceApiInfo param,HttpServletRequest requst){
        Result result = new Result();
        try {
//            param.setFindType(1);
            if (param.getFindType()==null){
                throw new HorizonBizException(Constants.Return.FINDTYPE_NULL);
            }
            LoginManager loginUser = (LoginManager)requst.getSession().getAttribute("loginManager");
            if(null==loginUser){
                throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
            }
/*            if (!loginUser.isUp()){
                //不是UP管理员
                param.setPkCompanyInfo(loginUser.getLoginUser().getPkCompanyInfo());
            }*/
            param.setPkCompanyInfo(loginUser.getLoginUser().getPkCompanyInfo());
            result.getData().put("list", serviceApiService.findPage(param));
        } catch (DuplicateKeyException e) {
            //throw new HorizonBizException(USEID_REPEAT);
            result.setState(Constants.Return.QUEYR_EXCEPTION);

        } catch (HorizonBizException e) {
//            e.printStackTrace();
            result.setState(e.getError());
        }catch (Exception e) {
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }

    /************************************************发布服务接口 end************************************************************/
    
}
