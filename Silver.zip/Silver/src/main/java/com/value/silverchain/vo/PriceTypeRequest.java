package com.value.silverchain.vo;

import lombok.Data;

/**
 *  价格类型信息入参类
 */

@Data
public class PriceTypeRequest {

    private String pkPriceTypeInfo;//价格类型主键
    
}