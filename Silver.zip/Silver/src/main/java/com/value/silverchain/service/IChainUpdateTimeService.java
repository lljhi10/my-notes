package com.value.silverchain.service;

public interface IChainUpdateTimeService {
    /**
     * 更新本地上链更新时间
     * @param key
     * @param updateTime
     * @return
     */
    public String save(String key,String updateTime);

    /**
     * 对比本地上链更新时间和链上的上链更新时间,相等返回false,不等返回true
     * @param key
     * @param updateTime
     * @return
     */
    public boolean compare(String key,String updateTime);
}
