package com.value.silverchain.service.impl;

import com.value.silverchain.model.ChainUpdateTime;
import com.value.silverchain.model.CompanyInfo;
import com.value.silverchain.service.IChainUpdateTimeService;
import org.bson.types.ObjectId;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class ChainUpdateTimeServiceImpl implements IChainUpdateTimeService {
    @Autowired
    private Datastore datastore;
    @Override
    public String save(String key, String updateTime) {
        Query<ChainUpdateTime> query =datastore.find(ChainUpdateTime.class).field("key").equal(key);
        if(query.count()==0){
            ChainUpdateTime chainUpdateTime = new ChainUpdateTime();
            chainUpdateTime.setKey(key);
            chainUpdateTime.setUpdateTime(updateTime);
            Key<ChainUpdateTime> k =datastore.save(chainUpdateTime);
            return ((ObjectId) k.getId()).toHexString();
        }else {
            ChainUpdateTime chainUpdateTime=query.get();
            chainUpdateTime.setUpdateTime(updateTime);
            Key<ChainUpdateTime> k =datastore.save(chainUpdateTime);
            return ((ObjectId) k.getId()).toHexString();
        }
    }

    @Override
    public boolean compare(String key, String updateTime) {
        Query<ChainUpdateTime> query =datastore.find(ChainUpdateTime.class).field("key").equal(key);
        if(query.count()==0){
            return true;
        }else {
            if(updateTime.equals(query.get().getUpdateTime())){
                return false;
            }

            return true;
        }
    }
}
