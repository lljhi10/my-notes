package com.value.silverchain.service.impl;


import com.value.silverchain.bo.PageBo;
import com.value.silverchain.model.BaseRole;
import com.value.silverchain.model.CompanyInfo;
import com.value.silverchain.service.IBaseRoleService;
import com.value.silverchain.service.IOrgInfoService;
import org.apache.commons.lang3.StringUtils;
import org.bson.types.ObjectId;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.UpdateOperations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:01
 * DESC:
 */
@Service
public class BaseRoleServiceImpl implements IBaseRoleService {

    @Autowired
    private Datastore datastore;
    @Autowired
    private IOrgInfoService orgInfoService;


    @Override
    public String save(BaseRole baseRole) {
        Key<BaseRole> key = datastore.save(baseRole);
        return ((ObjectId) key.getId()).toHexString();
    }

    @Override
    public BaseRole getByPkRole(String pkRole) {
        Query<BaseRole> query = datastore.find(BaseRole.class).field("pkRole").equal(pkRole).filter("status !=",BaseRole.Status.INVALID);
        BaseRole baseRole=query.get();

        return baseRole;
    }

    @Override
    public PageBo<BaseRole> findPage(BaseRole param) {
        Query<BaseRole> query = datastore.find(BaseRole.class).filter("status !=",BaseRole.Status.INVALID);

        if(param.getPkCompany() != null) {
            query.filter("pkCompany", param.getPkCompany());
            /*query.field("roleName").notEqual("超级管理员");*/
        }


        if(StringUtils.isNotBlank(param.getRoleName())) {
            query.field("roleName").contains(param.getRoleName());
        }

        for (BaseRole item : query.asList()) {
            CompanyInfo company = new CompanyInfo();
            company.setPkCompanyInfo(item.getPkCompany());
            company = orgInfoService.getCompanyInfoByID(company);
            item.setCompanyName(company.getCompanyName());
        }

        query.offset(param.getPageNo() * param.getPageSize() - param.getPageSize());
        query.limit(param.getPageSize());
        return new PageBo(query.asList(),query.count());
    }

    @Override
    public void delete(String userId) {
        datastore.delete(datastore.find(BaseRole.class).field("userId").equal(userId));
    }

    @Override
    public List<BaseRole> getUserListByPhone(String phone) {
        List<BaseRole> accountList=datastore.createQuery(BaseRole.class).field("phone").contains(phone).filter("status !=",BaseRole.Status.INVALID).asList();
        return accountList;
    }

    @Override
    public int update(BaseRole baseRole) {
        UpdateOperations<BaseRole> ops = datastore.createUpdateOperations(BaseRole.class);

        if(StringUtils.isNotBlank(baseRole.getRoleName())){
            ops.set("roleName", baseRole.getRoleName());
        }
        if(StringUtils.isNotBlank(baseRole.getDescription())){
            ops.set("description", baseRole.getDescription());
        }
        if(baseRole.getMenuList()!=null&&baseRole.getMenuList().size()>0){
            ops.set("menuList", baseRole.getMenuList());
        }

        ops.set("updateDate", baseRole.getUpdateDate());
        ops.set("updateManager", baseRole.getUpdateManager());

        int count = datastore.update(datastore.find(BaseRole.class).field("pkRole").equal(baseRole.getPkRole()),ops) .getUpdatedCount();
        return count;
    }

    @Override
    public List<BaseRole> getByKeys(List<String> pkRole) {
        List<BaseRole> accountList=datastore.createQuery(BaseRole.class).field("pkRole").in(pkRole).filter("status !=",BaseRole.Status.INVALID).asList();
        return accountList;
    }

    public void realDelete(String pkRole){
        datastore.delete(datastore.createQuery(BaseRole.class).filter("pkRole",pkRole));
    }

    @Override
    public BaseRole getByName(BaseRole baseRole) {
        Query<BaseRole> query = datastore.find(BaseRole.class).filter("status !=",BaseRole.Status.INVALID);

        if(baseRole.getPkCompany() != null) {
            query.filter("pkCompany", baseRole.getPkCompany());
        }

        if(StringUtils.isNotBlank(baseRole.getRoleName())) {
            query.field("roleName").equal(baseRole.getRoleName());
        }

        //角色添加商家名称
        CompanyInfo company = new CompanyInfo();
        company.setPkCompanyInfo(baseRole.getPkCompany());
        company = orgInfoService.getCompanyInfoByID(company);
        if(company != null){
            baseRole.setCompanyName(company.getCompanyName());
        }


        return query.get();
    }
}
