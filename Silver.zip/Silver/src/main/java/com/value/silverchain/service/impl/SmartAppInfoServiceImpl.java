package com.value.silverchain.service.impl;

import com.value.silverchain.bo.PageBo;
import com.value.silverchain.common.Constants;
import com.value.silverchain.dto.ChainSmartAppInfo;
import com.value.silverchain.dto.CompanyInfoDto;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.CompanyInfo;
import com.value.silverchain.model.SmartAppInfo;
import com.value.silverchain.service.IOrgInfoService;
import com.value.silverchain.service.ISmartAppInfoService;
import org.apache.commons.lang3.StringUtils;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.UpdateOperations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class SmartAppInfoServiceImpl implements ISmartAppInfoService {

    @Autowired
    public Datastore datastore;

    @Autowired
    private IOrgInfoService orgInfoService;

    @Override
    public String save(SmartAppInfo smartAppInfo) {
       Key<SmartAppInfo> key = datastore.save(smartAppInfo);
        return key.getId().toString();
    }

    @Override
    public SmartAppInfo getSmartAppInfoByID(SmartAppInfo smartAppInfo) {
        Query<SmartAppInfo> query = datastore.find(SmartAppInfo.class).field("pkSmartAppInfo").equal(smartAppInfo.getPkSmartAppInfo());
        SmartAppInfo a = query.get();
        if (a != null) {
            List<CompanyInfoDto> companyInfoList=orgInfoService.findAllByKeys(a.getCooperateCompany());
            a.setCooperateCompanyInfoList(companyInfoList);
            a.setCooperateCompanyName(orgInfoService.getComapnyName(a.getCooperateCompany()));
            if(a.getPkCompanyInfo()!=null){
                a.setCompanyName(orgInfoService.getComapnyNameByKey(a.getPkCompanyInfo()));
            }
        }
        return a;
    }

    @Override
    public PageBo<SmartAppInfo> findPage(SmartAppInfo smartAppInfo) {
        Query<SmartAppInfo> query = datastore.find(SmartAppInfo.class);
        if (StringUtils.isNotBlank(smartAppInfo.getSmartAppName())) {
            query.field("smartAppName").contains(smartAppInfo.getSmartAppName());
        }
        if (smartAppInfo.getFindType() != null && smartAppInfo.getFindType().equals(SmartAppInfo.FindType.CREATE)){
            //查询登录用户所属商户创建的智能应用
            if(smartAppInfo.getPkCompanyInfo() != null) {
                query.field("pkCompanyInfo").equal(smartAppInfo.getPkCompanyInfo());
            }
        }else{
            //查询其他商户的智能应用
            if(smartAppInfo.getPkCompanyInfo() != null) {
                query.field("pkCompanyInfo").notEqual(smartAppInfo.getPkCompanyInfo());
            }
            //查询登录用户所属商户在智能应用的协作列表中，且已经发布的智能应用
            if(smartAppInfo.getPkCompanyInfo() != null) {
                query.field("cooperateCompany").contains(smartAppInfo.getPkCompanyInfo());
            }
            query.field("status").equal(SmartAppInfo.Status.NORMAL);
            query.or(query.criteria("aprover").equal(SmartAppInfo.Aprover.UNAPROVER),
                    query.criteria("aprover").equal(SmartAppInfo.Aprover.APROVERED));
        }

        query.offset(smartAppInfo.getPageNo() * smartAppInfo.getPageSize() - smartAppInfo.getPageSize());
        query.limit(smartAppInfo.getPageSize());
        query.order("-createDate");

        List<SmartAppInfo> list = query.asList();

        CompanyInfo company = new CompanyInfo();
        for(SmartAppInfo item : list){
            if(company != null) {
                company.setPkCompanyInfo(item.getPkCompanyInfo());
                company = orgInfoService.getCompanyInfoByID(company);
                item.setCompanyName(company.getCompanyName());
            }
        }

        return new PageBo<SmartAppInfo>(list,query.count());
    }

    @Override
    public int delete(SmartAppInfo smartAppInfo) {
        UpdateOperations<SmartAppInfo> ops = datastore.createUpdateOperations(SmartAppInfo.class);
        if (smartAppInfo.getStatus() != null) {
            ops.set("status",smartAppInfo.getStatus());
        }
        return datastore.update(datastore.find(SmartAppInfo.class).field("pkSmartAppInfo").equal(smartAppInfo.getPkSmartAppInfo()),ops).getUpdatedCount();
    }

    @Override
    public int verify(SmartAppInfo smartAppInfo) {
        UpdateOperations<SmartAppInfo> ops = datastore.createUpdateOperations(SmartAppInfo.class);
        if (smartAppInfo.getAprover() != null) {
            ops.set("aprover",smartAppInfo.getAprover());
        }
        return datastore.update(datastore.find(SmartAppInfo.class).field("pkSmartAppInfo").equal(smartAppInfo.getPkSmartAppInfo()),ops).getUpdatedCount();
    }

    @Override
    public SmartAppInfo getSmartAppInfoByName(SmartAppInfo smartAppInfo) {
        Query<SmartAppInfo> query = datastore.find(SmartAppInfo.class).field("smartAppName").equal(smartAppInfo.getSmartAppName());
        if (query.get().getPkCompanyInfo()!=null){
            query.get().setCompanyName(orgInfoService.getComapnyNameByKey(query.get().getPkCompanyInfo()));
        }
        return query.get();
    }

    @Override
    public int update(SmartAppInfo smartAppInfo) {
        UpdateOperations<SmartAppInfo> ops = datastore.createUpdateOperations(SmartAppInfo.class);
//
//        if (smartAppInfo.getStatus() != null) {
//            ops.set("status",smartAppInfo.getStatus());
//        }
//        if (smartAppInfo.getAprover() != null && smartAppInfo.getTargetCompany().size() > 0) {
//            ops.set("aprover",smartAppInfo.getAprover());
//        }
//        if (smartAppInfo.getTargetCompany() != null ) {
//            ops.set("targetCompany",smartAppInfo.getTargetCompany());
//        }
//        if (smartAppInfo.getStartDate() != null ) {
//            ops.set("startDate",smartAppInfo.getStartDate());
//        }
//        if (smartAppInfo.getEndDate() != null ) {
//            ops.set("endDate",smartAppInfo.getEndDate());
//        }
//        if (smartAppInfo.getTaskNum() != null ) {
//            ops.set("taskNum",smartAppInfo.getTaskNum());
//        }
//        if (smartAppInfo.getTaskContant() != null && smartAppInfo.getTaskContant().size() > 0) {
//            ops.set("taskContant",smartAppInfo.getTaskContant());
//        }

        return datastore.update(datastore.find(SmartAppInfo.class).field("pkSmartAppInfo").equal(smartAppInfo.getPkSmartAppInfo()),ops).getUpdatedCount();
    }

    @Override
    public boolean checkSmartAppNameRepeat(String smartAppName, String pkSmartAppInfo) {
        Query<SmartAppInfo> query = datastore.find(SmartAppInfo.class).field("smartAppName").equal(smartAppName);
        if(StringUtils.isNotBlank(pkSmartAppInfo)){
            query.field("pkSmartAppInfo").notEqual(pkSmartAppInfo);
        }
        if (query.count()>0){
            return true;
        }
        return false;
    }

    @Override
    public SmartAppInfo getSmartAppInfoByAid(String aid,  String apiType) throws HorizonBizException {
        Date date = new Date();
        Query<SmartAppInfo> query = 
                datastore.find(SmartAppInfo.class).field("aid").equal(aid)
                .field("apiType").equal(apiType)
                .field("startDate").lessThanOrEq(date)
                .field("endDate").greaterThan(date)
                .field("status").equal(SmartAppInfo.Status.NORMAL)
                .field("aprover").equal(SmartAppInfo.Aprover.APROVERED);
        //时间过滤：开始时间<=当前时间<结束时间

        if(query.count()<=0){
            throw new HorizonBizException(Constants.Return.FIND_SMART_APP_INFO_FALSE);
        }
        if(query.count()>1){
            throw new HorizonBizException(Constants.Return.FIND_MULTI_SMART_APP_INFO);
        }

        return query.get();
    }

    @Override
    public boolean checkAidUsed(String aid, String pkCompanyInfo) {
        Query<SmartAppInfo> query = datastore.find(SmartAppInfo.class).field("aid").equal(aid).field("pkCompanyInfo").notEqual(pkCompanyInfo);
        if(query.count()>0){
            return true;
        }
        return false;
    }

    @Override
    public int updateFromChain(ChainSmartAppInfo item) {

        //查找本地这条数据,没有返回null
        SmartAppInfo smartAppInfo =  datastore.find(SmartAppInfo.class).filter("pkSmartAppInfo",item.getPkSmartAppInfo()).get();
        if (smartAppInfo==null){
            smartAppInfo=new SmartAppInfo();
            smartAppInfo.setPkSmartAppInfo(item.getPkSmartAppInfo());
        }

        smartAppInfo.setPkCompanyInfo( item.getPkCompanyInfo());
        smartAppInfo.setSmartAppName( item.getSmartAppName());
        smartAppInfo.setAid( item.getAid());
//        smartAppInfo.setApiType( item.getApiType());
        smartAppInfo.setPkApiTypeInfo(item.getPkApiTypeInfo());
        smartAppInfo.setCooperateCompany( item.getCooperateCompany());
        smartAppInfo.setStartDate( item.getStartDate());
        smartAppInfo.setEndDate( item.getEndDate());
        smartAppInfo.setTaskContent( item.getTaskContent());
        smartAppInfo.setTaskNum( item.getTaskNum());
        smartAppInfo.setApiDescription( item.getApiDescription());
        smartAppInfo.setAprover( item.getAprover());
        smartAppInfo.setStatus( item.getStatus());
        smartAppInfo.setPublishDate(item.getPublishDate());

        int i=0;
        String id =save(smartAppInfo);
        if(StringUtils.isNotBlank(id)){
            i=1;
        }

        return i;
    }

    @Override
    public void checkUniqueness(SmartAppInfo param) throws HorizonBizException {
        Query<SmartAppInfo> query = datastore.find(SmartAppInfo.class);
//        query.field("pkCompanyInfo").equal(param.getPkCompanyInfo());//登录用户所在商户
        query.field("aid").equal(param.getAid());
        query.field("pkApiTypeInfo").equal(param.getPkApiTypeInfo());
        query.field("status").equal(SmartAppInfo.Status.NORMAL);
        query.or(query.criteria("aprover").equal(SmartAppInfo.Aprover.APROVERED),query.criteria("aprover").equal(SmartAppInfo.Aprover.UNAPROVER));
        query.or(
//                query.and(query.criteria("startDate").lessThanOrEq(param.getStartDate()),query.criteria("endDate").greaterThanOrEq(param.getEndDate())),//startDate<=start and endDate>=end 新建有效期被已有包含
//                query.and(query.criteria("startDate").greaterThanOrEq(param.getStartDate()),query.criteria("endDate").lessThanOrEq(param.getEndDate())),//startDate>=start and endDate<=end 新建有效期包含已有
                query.and(query.criteria("startDate").lessThan(param.getEndDate()),query.criteria("endDate").greaterThanOrEq(param.getEndDate())),//startDate<end<=endDate新建的有效期结束时间在已有的期间
                query.and(query.criteria("startDate").lessThanOrEq(param.getStartDate()),query.criteria("endDate").greaterThan(param.getStartDate()))//startDate<=start<endDate 新建的有效期开始时间在已有的期间
        );
        query.field("cooperateCompany").hasAnyOf(param.getCooperateCompany());
        if (query.count()>0) {
            throw new HorizonBizException(Constants.Return.SMART_INFO_HAS_APROVERED);
        }

    }
}
