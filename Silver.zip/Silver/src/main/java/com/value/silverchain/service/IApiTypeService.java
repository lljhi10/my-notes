package com.value.silverchain.service;

import com.value.silverchain.bo.PageBo;
import com.value.silverchain.dto.ChainApiTypeInfo;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.ApiTypeInfo;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:00
 * DESC:
 */
public interface IApiTypeService {

    /**
     * 保存
     * @param apiTypeInfo
     * @return
     */
    String save(ApiTypeInfo apiTypeInfo) throws HorizonBizException;

    /**
     * 根据主键查询
     * @param pkApiTypeInfo
     * @return
     */
    ApiTypeInfo getByKey(String pkApiTypeInfo);

    /**
     * 分页查询
     * @param param
     * @return
     */
    PageBo<ApiTypeInfo> findPage(ApiTypeInfo param);

    /**
     * 查询列表
     * @param pkCompanyInfo
     * @return
     */
    List<ApiTypeInfo> findAll(String pkCompanyInfo);

    int updateFromChain(ChainApiTypeInfo item);
}
