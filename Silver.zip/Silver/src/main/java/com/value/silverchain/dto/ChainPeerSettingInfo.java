package com.value.silverchain.dto;

import com.value.silverchain.model.BasePage;
import com.value.silverchain.model.PeerSettingInfo;
import lombok.Data;

/**
 *  节点配置信息上链下链用数据类
 */
@Data
public class ChainPeerSettingInfo extends BasePage{

    private String pkPeerSettingInfo;//节点主键

    private String pkCompanyInfo;//商户主键
    private String peerSettingName;//节点名称

    private String ip;//节点IP地址

    private String chainAddr;//节点区域链地址

    private PeerSettingInfo.Status status;//节点状态：正常，暂停，终止

    private PeerSettingInfo.Auth publishedInterfaceAuth;//服务接口发布权限
    
    private PeerSettingInfo.Auth smartAppAuth;//智能应用管理权限

    private String agreementNo;//协议编码

    public ChainPeerSettingInfo(){}

    public ChainPeerSettingInfo(PeerSettingInfo peerSettingInfo){
        this.setPkPeerSettingInfo(peerSettingInfo.getPkPeerSettingInfo());
        this.setPkCompanyInfo(peerSettingInfo.getPkCompanyInfo());
        this.setPeerSettingName(peerSettingInfo.getPeerSettingName());
        this.setIp(peerSettingInfo.getIp());
        this.setChainAddr(peerSettingInfo.getChainAddr());
        this.setStatus(peerSettingInfo.getStatus());
        this.setPublishedInterfaceAuth(peerSettingInfo.getPublishedInterfaceAuth());
        this.setSmartAppAuth(peerSettingInfo.getSmartAppAuth());
        this.setAgreementNo(peerSettingInfo.getAgreementNo());
    }
}