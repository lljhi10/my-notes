package com.value.silverchain.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.value.silverchain.dto.CompanyInfoDto;
import lombok.Data;
import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Id;
import org.mongodb.morphia.annotations.Indexed;
import org.mongodb.morphia.annotations.Transient;
import org.mongodb.morphia.utils.IndexDirection;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *  智能应用信息
 */
@Entity("smart_app_info")
@Data
public class SmartAppInfo extends BasePage{
    public enum ApiType {
        POINT("积分兑换");
        private String name;

        ApiType(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum Status {
        NORMAL("正常"), PAUSE("暂停"), TERMINATION("终止");
        private String name;

        Status(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum Aprover {
        UNPUBLISH("未发布"),UNAPROVER("待审核"), APROVERED("已审核");
        private String name;

        Aprover(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum FindType {
        CREATE("商户创建"), APROVER("商户审核");
        private String name;

        FindType(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    @Id
    @JsonIgnore
    private ObjectId id;
    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_pkSmartAppInfo",dropDups = true)
    private String pkSmartAppInfo;//智能应用主键

    private String pkCompanyInfo;//发布智能应用的商户主键
    
//    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_smartAppName",dropDups = true)
    private String smartAppName;//智能应用名称
    
//    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_smartAppAid",dropDups = true)
    private String aid;//唯一标识ID，后台生成

    //    private Constants.ApiType apiType;//服务接口类型
    private String pkApiTypeInfo;//服务接口类型主键

    private String pkPriceTypeInfo;//价格类型主键
    
    private List<String> cooperateCompany;//合作方列表
    
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date startDate;//有效期-开始时间
    
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date endDate;//有效期-结束时间

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date publishDate;//发布日期
    
//    private String smartJsonContant;//智能合约内容(JSON格式)
    private List<String> taskContent;//任务列表

    private Integer taskNum;//任务数量

    private String apiDescription;//交易成功回调API接口
    
    private String failueApi;//失败回调API接口
    
    private Status status;//应用状态：正常， 暂停， 终止
    
    private Aprover aprover;//审核状态：未发布，待审核，已审核

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createDate;//创建时间

    private String createManager;//创建人
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateDate;//最后更新时间

    private String updateManager;//最后更新人

    public void setSid(String sid) {
        this.pkSmartAppInfo = sid;
    }

    @Transient
    private String companyName;//发布智能应用的商户名称
    @Transient
    private String cooperateCompanyName;//合作方商户名称，当有多个时，用逗号分隔
    @Transient
    private List<CompanyInfoDto> cooperateCompanyInfoList;//合作方商户列表
    @Transient
    private FindType findType;//查找类型：商户创建/商户审核

    @Transient
    private ApiTypeInfo apiTypeInfo;//服务接口类型
    @Transient
    private PriceTypeInfo priceTypeInfo;//价格类型

    public Map getFindTypeObject() {
        Map map = new HashMap();
        if(findType != null) {
            map.put("name", this.findType.getName());
            map.put("value", this.findType);
        }
        return map;
    }

    public Map getAproverObject() {
        Map map = new HashMap();
        if(aprover != null) {
            map.put("name", this.aprover.getName());
            map.put("value", this.aprover);
        }
        return map;
    }

    public Map getStatusObject() {
        Map map = new HashMap();
        if(status != null) {
            map.put("name", this.status.getName());
            map.put("value", this.status);
        }
        return map;
    }


    public String getSmartAppName(){
        if (smartAppName == null) {
            return smartAppName;
        }else {
            int index = smartAppName.indexOf("-");
            if (index>=0){
                return smartAppName.substring(index+1);
            }else{
                return smartAppName;
            }
        }
    }
}