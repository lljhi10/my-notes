package com.value.silverchain.util;

import java.io.File;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/8/1
 * DESC:
 */
public class FilePathUtil {

//        public static final String FILE_SEPARATOR = System.getProperty("file.separator");
        public static final String FILE_SEPARATOR = File.separator;

    /**
     * 转换路径分隔符，自动适应服务器系统
     * @param path
     * @return
     */
    public static String getRealFilePath(String path) {
            return path.replace("/", FILE_SEPARATOR).replace("\\", FILE_SEPARATOR);
        }

    /**
     * 转换成http路径
     * @param path
     * @return
     */
        public static String getHttpURLPath(String path) {
            return path.replace("\\", "/");
        }

}
