package com.value.silverchain.controller;

import com.value.silverchain.bo.PageBo;
import com.value.silverchain.common.Constants;
import com.value.silverchain.model.ManagerInfo;
import com.value.silverchain.model.PeerSettingInfo;
import com.value.silverchain.service.IChainService;
import com.value.silverchain.service.IPeerSettingInfoService;
import com.value.silverchain.vo.LoginManager;
import com.value.silverchain.vo.Result;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: ${date}
 * DESC:节点配置管理
 */
@Controller
@RequestMapping("/peersetting/v1")
public class OrgPeerSettingController {
	
	final static Logger logger = LoggerFactory.getLogger(OrgPeerSettingController.class);
	
    @Autowired
    private IPeerSettingInfoService peerSettingInfoService;

    @Autowired
    private IChainService chainService;



    /**
     * 添加节点
     * @param peerSettingInfo
     * @return
     */
    @RequestMapping("/create")
    @ResponseBody
    public String addPeerSettingInfo(@RequestBody PeerSettingInfo peerSettingInfo, HttpSession session){
        Result result = new Result();
        //获取当前登录用户
        LoginManager loginManager =(LoginManager) session.getAttribute("loginManager");
        try {
        	logger.info("--------------------新建节点信息:start-------------------------------------");
            //参数校验
            result=checkNull(peerSettingInfo);
            if (result.verify())  {
                //参数合理性验证
//                if(StringUtils.isNotBlank(peerSettingInfo.getIp()) && !peerSettingInfo.getIp().matches(Constants.REGULAR_IP)){
//                    logger.info("--------------------修改节点信息错误:IP地址不合法！-------------------------------------");
//                    result.setState(200002,"IP地址不合法!");
//                    return result.toJson();
//                }
                //数据唯一性验证
                PeerSettingInfo checkResult = peerSettingInfoService.uniqueCheck(peerSettingInfo);
                if (checkResult.getPeerSettingName() != null) {
                    logger.info("--------------------新建节点信息错误:该节点名已经存在！-------------------------------------");
                    result.setState(Constants.Return.PEERSETTINGNAME_EXISTS);
                    return result.toJson();
                }
                if (checkResult.getIp() != null) {
                    logger.info("--------------------新建节点信息错误:该ip已经被使用！-------------------------------------");
                    result.setState(Constants.Return.IP_EXISTS);
                    return result.toJson();
                }
//                if (checkResult.getChainAddr() != null) {
//                    logger.info("--------------------新建节点信息错误:该区块链地址已经被使用！-------------------------------------");
//                    result.setState(Constants.Return.CHAINADDR_EXISTS);
//                    return result.toJson();
//                }
                //业务验证
                //添加之前需要判断是否存在本地节点,不存在才能添加
                List<PeerSettingInfo> lis = peerSettingInfoService.findByPeerType(PeerSettingInfo.PeerType.LOCAL);
                if (lis != null && lis.size() > 0) {
                    logger.info("--------------------新建商户错误:本地节点已经存在!-------------------------------------");
                    result.setState(Constants.Return.LOCALPEER_EXISTS);
                    return result.toJson();
                }

                if (!loginManager.isUp()) {
                    logger.info("--------------------新建节点错误:当前管理员不属于UP!-------------------------------------");
                    result.setState(Constants.Return.UNSUCCESS);
                    return result.toJson();
                }


                //自动匹配数据
                ManagerInfo manger = (ManagerInfo) session.getAttribute("loginUser");
                peerSettingInfo.setPkPeerSettingInfo(UUID.randomUUID().toString());
                peerSettingInfo.setPeerType(PeerSettingInfo.PeerType.LOCAL);
                peerSettingInfo.setCreateDate(new Date());
                peerSettingInfo.setCreateManager(manger.getPkManagerInfo());

                String id = peerSettingInfoService.save(peerSettingInfo);

                if (StringUtils.isBlank(id)) {
                    logger.info("--------------------新建节点错误:系统异常!-------------------------------------");
                    result.setState(Constants.Return.UNSUCCESS);
                    return result.toJson();
                }
                result.getData().put("account", peerSettingInfo);
                //上链
                chainService.invokePeer();
            }

        } catch (Exception e) {
            e.printStackTrace();
            result.setState(Constants.Return.UNSUCCESS);
            logger.info("--------------------新建节点错误:系统异常!-------------------------------------");
        }

        return result.toJson();
    }

    private Result checkNull(PeerSettingInfo peerSettingInfo) {
        Result result = new Result();
//        if(StringUtils.isBlank(peerSettingInfo.getPeerSettingName()) || StringUtils.isBlank(peerSettingInfo.getIp()) ||
//                StringUtils.isBlank(peerSettingInfo.getPkCompanyInfo()) || peerSettingInfo.getStatus() == null ||
//                peerSettingInfo.getPublishedInterfaceAuth() == null || peerSettingInfo.getSmartAppAuth() == null ||
//                StringUtils.isBlank(peerSettingInfo.getAgreementNo()) || peerSettingInfo.getPeerType() == null ||
//                StringUtils.isBlank(peerSettingInfo.getChainAddr())) {
        if (StringUtils.isBlank(peerSettingInfo.getPeerSettingName())){
            logger.info("--------------------参数错误:节点名称不能为空!-------------------------------------");
            result.setState(Constants.Return.PEERSETTINGNAME_NULL);
        } else if (StringUtils.isBlank(peerSettingInfo.getIp())) {
            logger.info("--------------------参数错误:节点ip地址不能为空!-------------------------------------");
            result.setState(Constants.Return.IP_NULL);
        } else if (StringUtils.isBlank(peerSettingInfo.getPkCompanyInfo())) {
            logger.info("--------------------参数错误:商户主键不能为空!-------------------------------------");
            result.setState(Constants.Return.PKCOMPANYINFO_NULL);
        }else if ( peerSettingInfo.getStatus() == null) {
            logger.info("--------------------参数错误:状态不能为空!-------------------------------------");
            result.setState(Constants.Return.STATUS_NULL);
        }else if ( peerSettingInfo.getPublishedInterfaceAuth() == null) {
            logger.info("--------------------参数错误:服务接口发布权限不能为空!-------------------------------------");
            result.setState(Constants.Return.PUBLISHED_INTERFACE_AUTH_NULL);
        }else if ( peerSettingInfo.getSmartAppAuth() == null) {
            logger.info("--------------------参数错误:智能应用管理权限不能为空!-------------------------------------");
            result.setState(Constants.Return.SMARTAPPAUTH_NULL);
        }else if ( StringUtils.isBlank(peerSettingInfo.getAgreementNo())) {
            logger.info("--------------------参数错误:协议编码不能为空!-------------------------------------");
            result.setState(Constants.Return.AGREEMENTNO_NULL);
        }else if (peerSettingInfo.getPeerType() == null) {
            logger.info("--------------------参数错误:节点类型不能为空!-------------------------------------");
            result.setState(Constants.Return.PEERTYPE_NULL);
        }else if ( StringUtils.isBlank(peerSettingInfo.getChainAddr())) {
            logger.info("--------------------参数错误:区块链地址不能为空!-------------------------------------");
            result.setState(Constants.Return.CHAINADDR_NULL);
        }
        return result;
    }

    /**
     * 更新节点
     * @param peerSettingInfo
     * @return
     */
    @RequestMapping("/edit")
    @ResponseBody
    public String editPeerSettingInfo(@RequestBody PeerSettingInfo peerSettingInfo,HttpSession session){
        Result result = new Result();
        //获取当前登录用户
        LoginManager loginManager =(LoginManager) session.getAttribute("loginManager");
        try {
            //参数合理性验证
//            if(StringUtils.isNotBlank(peerSettingInfo.getIp()) && !peerSettingInfo.getIp().matches(Constants.REGULAR_IP)){
//                logger.info("--------------------修改节点信息错误:IP地址不合法！-------------------------------------");
//                result.setState(200002,"IP地址不合法!");
//                return result.toJson();
//            }
        	//数据唯一性验证
        	PeerSettingInfo checkResult = peerSettingInfoService.uniqueCheck(peerSettingInfo);
            if(checkResult.getPeerSettingName() != null) {
            	logger.info("--------------------修改节点信息错误:该节点名已经存在！-------------------------------------");
                result.setState(Constants.Return.PEERSETTINGNAME_EXISTS);
                return result.toJson();
            }
            if(checkResult.getIp() != null) {
            	logger.info("--------------------修改节点信息错误:该ip已经被使用！-------------------------------------");
                result.setState(Constants.Return.IP_EXISTS);
                return result.toJson();
            }
            checkResult=peerSettingInfoService.getPeerSettingInfoByID(peerSettingInfo);
            if (checkResult == null) {
                logger.info("--------------------修改节点信息错误:查找节点失败！-------------------------------------");
                result.setState(Constants.Return.PEER_UNFOUND_ERROR);
                return result.toJson();
            }

//            if(checkResult.getChainAddr() != null) {
//            	logger.info("--------------------修改节点信息错误:该区块链地址已经被使用！-------------------------------------");
//                result.setState(Constants.Return.CHAINADDR_EXISTS);
//                return result.toJson();
//            }
            //业务验证
            if(!loginManager.isUp()){
                if(!checkResult.getPkCompanyInfo().equals(loginManager.getCompanyInfo().getPkCompanyInfo())){
                    logger.info("--------------------修改节点错误:当前管理员不属于UP或当前节点所属商户-------------------------------------");
                    result.setState(Constants.Return.TIGTH_LESS_THAN);
                    return result.toJson();
                }
            }
            peerSettingInfo.setUpdateDate(new Date());
            peerSettingInfo.setUpdateManager(loginManager.getLoginUser().getPkManagerInfo());
            int updCount = peerSettingInfoService.update(peerSettingInfo);

            if(updCount > 0) {
                result.getData().put("peerSettingInfo", peerSettingInfo);
                //上链
                chainService.invokePeer();
            }else{
            	logger.info("--------------------修改节点错误:系统异常!-------------------------------------");
                result.setState(Constants.Return.UPDATE_EXCEPTION);
            }


        } catch (Exception e) {        	
            result.setState(Constants.Return.UPDATE_EXCEPTION);
            logger.info("--------------------修改节点错误:系统异常!-------------------------------------");
        }

        return result.toJson();
    }

    /**
     * 按ID查找节点
     * @param peerSettingInfo
     * @return
     */
    @RequestMapping("/findById")
    @ResponseBody
    public String findPeerSettingInfoById(@RequestBody  PeerSettingInfo peerSettingInfo){
        Result result = new Result();
        try {
            if (StringUtils.isBlank(peerSettingInfo.getPkPeerSettingInfo())) {
                result.setState(Constants.Return.PKPEERSETTINGINFO_NULL);
            } else {
                PeerSettingInfo account = peerSettingInfoService.getPeerSettingInfoByID(peerSettingInfo);
                result.getData().put("PeerSettingInfo",account);
            }

        } catch (Exception e) {
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        }

        return result.toJson();
    }

    /**
     * 按节点名称查找节点
     * @param PeerSettingInfo
     * @return
     */
    @RequestMapping("/findByName")
    @ResponseBody
    public String findPeerSettingInfoByName(@RequestBody  PeerSettingInfo PeerSettingInfo,HttpSession session){
        Result result = new Result();
        try {
            //获取当前登录用户
            LoginManager manger = (LoginManager) session.getAttribute("loginManager");

            PeerSettingInfo.setPkCompanyInfo(manger.getLoginUser().getPkCompanyInfo());

            if (StringUtils.isBlank(PeerSettingInfo.getPeerSettingName())) {
                result.setState(Constants.Return.PEERSETTINGNAME_NULL);
            } else {
                PeerSettingInfo account = peerSettingInfoService.getPeerSettingInfoByName(PeerSettingInfo);
                result.getData().put("PeerSettingInfo",account);
            }

        } catch (Exception e) {
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        }

        return result.toJson();
    }

    /**
     * 按商户账号分页查询
     * @param PeerSettingInfo
     * @return
     */
    @RequestMapping("/findByPage")
    @ResponseBody
    public String findPeerSettingInfoByPage(@RequestBody PeerSettingInfo PeerSettingInfo,HttpSession session){
        Result result = new Result();
        try {
            //获取当前登录用户
            LoginManager manger = (LoginManager) session.getAttribute("loginManager");
            //up查看所有,其它查看当前商户下
            /*if(manger.isUp()){
                PeerSettingInfo.setPkCompanyInfo(null);
            }else{
                PeerSettingInfo.setPkCompanyInfo(manger.getLoginUser().getPkCompanyInfo());
            }*/

            PageBo<PeerSettingInfo> PeerSettingInfos = peerSettingInfoService.findPage(PeerSettingInfo);
            result.getData().put("list",PeerSettingInfos);

        } catch (Exception e) {
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        }

        return result.toJson();
    }
}
