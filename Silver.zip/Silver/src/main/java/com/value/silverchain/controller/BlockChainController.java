package com.value.silverchain.controller;

import cn.hyperchain.sdk.crypto.ECPriv;
import cn.hyperchain.sdk.rpc.HyperchainAPI;
import cn.hyperchain.sdk.rpc.utils.ByteUtil;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.vo.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.GeneralSecurityException;


@RestController
@RequestMapping("/blockChain/v1")
public class BlockChainController {

    private Logger logger = LoggerFactory.getLogger(BlockChainController.class);


    @RequestMapping(value = "/account/create")
    public String createAccount() {

        Result result = new Result();
        try {
            HyperchainAPI hyperchain = new HyperchainAPI();
            ECPriv ecp = HyperchainAPI.newAccount();
            String pubkey = ByteUtil.toHexString(ecp.getPublicKeyByte()).substring(2);
            result.getData().put("privateKey", ecp.getPrivateKey());
            result.getData().put("publicKey", pubkey);
            result.getData().put("address",ecp.address());
        }catch (HorizonBizException e){
            result.setState(e.getError());
        } catch (GeneralSecurityException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result.toJson();
    }

}