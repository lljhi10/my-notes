package com.value.silverchain.model;

import lombok.Data;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/6/5
 * DESC:菜单资源
 */
@Data
public class MenuSource {
    private String menuName;
    private List<BaseRight> rightList;
    
    public String getFirstMenu(){
        switch (menuName){
            case "商户信息管理":
                return "商户管理";
            case "业务账号管理":
                return "商户管理";
            case "节点管理":
                return "节点管理";
            case "支付服务接口":
                return "服务接口";
            case "发布服务接口":
                return "服务接口";
            case "查看服务接口":
                return "服务接口";
            case "发布智能应用":
                return "智能应用";
            case "查看智能应用":
                return "智能应用";
            case "交易统计":
                return "统计分析";
            case "角色管理":
                return "系统管理";
            case "账号管理":
                return "系统管理";
            default: 
                return null;
        }
        
    }
}
