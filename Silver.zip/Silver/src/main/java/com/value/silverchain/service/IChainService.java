package com.value.silverchain.service;

import com.value.silverchain.dto.ChainCompanyInfo;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.vo.Result;

import java.util.List;


/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:00
 * DESC:
 */
public interface IChainService {

//     String invoke(String channelName, String codeName,String codeVersion,String fcn,String args[]) throws HorizonBizException;

//     String getCodeinfo();

     /**
      * 商户上链
      */
     void invokeCompanyInfo() throws HorizonBizException;
     /**
      * 账户上链
      */
     void invokeAccountInfo() throws HorizonBizException;

     /**
      * 节点信息上链
      * @throws HorizonBizException
      */
     void invokePeer() throws HorizonBizException;

     /**
      * 服务接口类型上链
      * @throws HorizonBizException
      */
     void invokeApiTypeInfo() throws HorizonBizException;
     /**
      * 价格类型上链
      * @throws HorizonBizException
      */
     void invokePriceTypeInfo()throws HorizonBizException;
     /**
      * 支付服务接口上链
      * @throws HorizonBizException
      */
     void invokePayApiInfo() throws HorizonBizException;

     /**
      * 服务接口上链
      * @throws HorizonBizException
      */
     void invokeServiceApiInfo() throws HorizonBizException;

     /**
      * 智能应用上链
      * @throws HorizonBizException
      */
     void invokeSmartAppInfo() throws HorizonBizException;

     /**
      * 日志上链
      * @param key
      * @param logStr
      */
     void invokeLog(String key, String logStr);

     /*业务账户下链*/
     void queryAccountInfo() throws HorizonBizException ;
     /*商户下链*/
     void queryCompanyInfo() throws HorizonBizException ;
     /*节点下链*/
     void queryPeerSettingInfo() throws HorizonBizException ;
     /*服务接口类型下链*/
     void queryApiTypeInfo()  throws HorizonBizException;
     /*价格类型下链*/
     void queryPriceTypeInfo() throws HorizonBizException;
     /*支付服务下链*/
     void queryPayApiInfo()  throws HorizonBizException;
     /*发布下链*/
     void queryServiceApiInfo() throws HorizonBizException ;
     /*智能应用下链*/
     void querySmartAppInfo() throws HorizonBizException ;

     /**
      * 从链上获取UP商户信息
      * @return
      */
    Result queryUPInfo();

     /**
      * UP商户信息上链
      * @param chainCompanyInfo
      */
    void invokeUpInfo(ChainCompanyInfo chainCompanyInfo) throws HorizonBizException;


    List<String> queryLog(String aid, String orderId) throws  Exception;
    List<String> querySmartLog(String keyHead);



}
