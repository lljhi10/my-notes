package com.value.silverchain.service;

import com.value.silverchain.bo.PageBo;
import com.value.silverchain.dto.ChainPeerSettingInfo;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.PeerSettingInfo;

import java.awt.*;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:00
 * DESC:业务账号管理
 */
public interface IPeerSettingInfoService {

    /**
     * 保存
     * @param peerSettingInfo
     * @return
     */
    String save(PeerSettingInfo peerSettingInfo);

    /**
     * 按id查询
     * @param peerSettingInfo
     * @return
     */
    PeerSettingInfo getPeerSettingInfoByID(PeerSettingInfo peerSettingInfo);

    /**
     * 按名称查询
     * @param peerSettingInfo
     * @return
     */
    PeerSettingInfo getPeerSettingInfoByName(PeerSettingInfo peerSettingInfo);

    /**
     * 分页查询 ,可按名称模糊查询
     * @param peerSettingInfo
     * @return
     */
    PageBo<PeerSettingInfo> findPage(PeerSettingInfo peerSettingInfo);

    /**
     * 更新业务账号
     * @param peerSettingInfo
     * @return
     */
    int update(PeerSettingInfo peerSettingInfo);

    /**
     * 查看是否存在本地节点
     * @param companyName
     * @return
     */
    public List<PeerSettingInfo> findByPeerType(PeerSettingInfo.PeerType peerType);
    
    /**
     * 唯一性验证
     * @param peerSettingInfo
     * @return
     */
    PeerSettingInfo uniqueCheck(PeerSettingInfo peerSettingInfo);

    /**
     *
     * @param item
     */
    int updateFromChain(ChainPeerSettingInfo item);

    /**
     * 更新节点所属商户
     * @param peerSettingInfo
     * @param pkCompanyInfo
     */
    void updateCompany(PeerSettingInfo peerSettingInfo, String pkCompanyInfo);
}
