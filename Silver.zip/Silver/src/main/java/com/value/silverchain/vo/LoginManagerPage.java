package com.value.silverchain.vo;

import lombok.Data;

import java.util.Set;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/7/27
 * DESC:
 */
@Data
public class LoginManagerPage {
    private CompanyInfoPage companyInfo;//用户所属商户
    private Set<String> paths;//用户权限路径

    public LoginManagerPage(LoginManager loginManager) {
        this.companyInfo=new CompanyInfoPage(loginManager.getCompanyInfo());
        this.paths=loginManager.getPaths();
    }
}
