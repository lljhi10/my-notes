package com.value.silverchain.service.impl;


import com.value.silverchain.bo.PageBo;
import com.value.silverchain.dto.ChainPeerSettingInfo;
import com.value.silverchain.model.CompanyInfo;
import com.value.silverchain.model.PeerSettingInfo;
import com.value.silverchain.service.IOrgInfoService;
import com.value.silverchain.service.IPeerSettingInfoService;
import org.apache.commons.lang3.StringUtils;
import org.bson.types.ObjectId;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.UpdateOperations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:01
 * DESC:
 */
@Service
public class PeerSettingInfoServiceImpl implements IPeerSettingInfoService {

    @Autowired
    private Datastore datastore;

    @Autowired
    private IOrgInfoService orgInfoService;

    @Override
    public String save(PeerSettingInfo peerSettingInfo) {
        Key<PeerSettingInfo> key = datastore.save(peerSettingInfo);
        return ((ObjectId) key.getId()).toHexString();
    }

    @Override
    public PeerSettingInfo getPeerSettingInfoByID(PeerSettingInfo peerSettingInfo) {
        Query<PeerSettingInfo> query = datastore.find(PeerSettingInfo.class).field("pkPeerSettingInfo").equal(peerSettingInfo.getPkPeerSettingInfo());
        if (query.get().getPkCompanyInfo()!=null){
            query.get().setCompanyName(orgInfoService.getComapnyNameByKey(query.get().getPkCompanyInfo()));
        }
        return query.get();
    }

    @Override
    public PeerSettingInfo getPeerSettingInfoByName(PeerSettingInfo peerSettingInfo) {
        Query<PeerSettingInfo> query = datastore.find(PeerSettingInfo.class).field("peerSettingName").equal(peerSettingInfo.getPeerSettingName());
        return query.get();
    }

    @Override
    public PageBo<PeerSettingInfo> findPage(PeerSettingInfo peerSettingInfo) {
        Query<PeerSettingInfo> query = datastore.find(PeerSettingInfo.class);

        if(StringUtils.isNotBlank(peerSettingInfo.getPeerSettingName())) {
            query.field("peerSettingName").contains(peerSettingInfo.getPeerSettingName());
        }
        /*if(peerSettingInfo.getPkCompanyInfo() != null) {
            query.field("pkCompanyInfo").equal(peerSettingInfo.getPkCompanyInfo());
        }*/
        query.offset(peerSettingInfo.getPageNo() * peerSettingInfo.getPageSize() - peerSettingInfo.getPageSize());
        query.limit(peerSettingInfo.getPageSize());

        List<PeerSettingInfo> list = query.asList();

        if(list!=null&&list.size()>0){
            list.forEach(item -> {
                if (item.getPkCompanyInfo()!=null){
                    item.setCompanyName(orgInfoService.getComapnyNameByKey(item.getPkCompanyInfo()));
                }
            });
        }
        return new PageBo(list,query.count());
    }

    @Override
    public int update(PeerSettingInfo peerSettingInfo) {

        UpdateOperations<PeerSettingInfo> ops = datastore.createUpdateOperations(PeerSettingInfo.class);

        if(StringUtils.isNotBlank(peerSettingInfo.getPeerSettingName())){
            ops.set("peerSettingName", peerSettingInfo.getPeerSettingName());
        }
        if(StringUtils.isNotBlank(peerSettingInfo.getIp())){
            ops.set("ip", peerSettingInfo.getIp());
        }
        if(StringUtils.isNotBlank(peerSettingInfo.getPkCompanyInfo())){
            ops.set("pkCompanyInfo", peerSettingInfo.getPkCompanyInfo());
        }
        if(peerSettingInfo.getStatus() != null){
            ops.set("status", peerSettingInfo.getStatus());
        }
        if(peerSettingInfo.getPublishedInterfaceAuth() != null){
            ops.set("publishedInterfaceAuth", peerSettingInfo.getPublishedInterfaceAuth());
        }
        if(peerSettingInfo.getSmartAppAuth() != null){
            ops.set("smartAppAuth", peerSettingInfo.getSmartAppAuth());
        }
        if(StringUtils.isNotBlank(peerSettingInfo.getAgreementNo())){
            ops.set("agreementNo", peerSettingInfo.getAgreementNo());
        }
        /*if(peerSettingInfo.getPeerType() != null){
            ops.set("peerType", peerSettingInfo.getPeerType());
        }*/
        if(peerSettingInfo.getUpdateDate()!=null){
            ops.set("updateDate", peerSettingInfo.getUpdateDate());
        }
        if(StringUtils.isNotBlank(peerSettingInfo.getUpdateManager())){
            ops.set("updateManager", peerSettingInfo.getUpdateManager());
        }

        int count = datastore.update(datastore.find(PeerSettingInfo.class).field("pkPeerSettingInfo").equal(peerSettingInfo.getPkPeerSettingInfo()),ops) .getUpdatedCount();

        return count;
    }

    @Override
    public List<PeerSettingInfo> findByPeerType(PeerSettingInfo.PeerType peerType) {
        Query<PeerSettingInfo> query = datastore.find(PeerSettingInfo.class);
        query.field("peerType").equal(peerType);
        return query.asList();
    }
    
    @Override
    public PeerSettingInfo uniqueCheck(PeerSettingInfo peerSettingInfo){
    	PeerSettingInfo peerSetting = new PeerSettingInfo();

        Query<PeerSettingInfo> query;

        if (StringUtils.isNotBlank(peerSetting.getCompanyName())) {
            query = datastore.find(PeerSettingInfo.class);
            query.field("accountName").equal(peerSettingInfo.getCompanyName());
            if(StringUtils.isNotBlank(peerSettingInfo.getPkPeerSettingInfo())) {
                query.field("pkPeerSettingInfo").notEqual(peerSettingInfo.getPkPeerSettingInfo());
            }
            if (query.get() != null) {
            	peerSetting.setPkPeerSettingInfo(query.get().getPkPeerSettingInfo());
                return peerSetting;
            }
        }

        if (StringUtils.isNotBlank(peerSetting.getIp())) {
            query = datastore.find(PeerSettingInfo.class);
            query.field("ip").equal(peerSettingInfo.getIp());
            if(StringUtils.isNotBlank(peerSettingInfo.getPkPeerSettingInfo())) {
                query.field("pkPeerSettingInfo").notEqual(peerSettingInfo.getPkPeerSettingInfo());
            }
            if (query.get() != null) {
            	peerSetting.setIp(query.get().getIp());
                return peerSetting;
            }
        }
        
//        if (StringUtils.isNotBlank(peerSetting.getChainAddr())) {
//            query = datastore.find(PeerSettingInfo.class);
//            query.field("chainAddr").equal(peerSettingInfo.getChainAddr());
//            if(StringUtils.isNotBlank(peerSettingInfo.getPkPeerSettingInfo())) {
//                query.field("pkPeerSettingInfo").notEqual(peerSettingInfo.getPkPeerSettingInfo());
//            }
//            if (query.get() != null) {
//            	peerSetting.setChainAddr(query.get().getChainAddr());
//                return peerSetting;
//            }
//        }
        
        return peerSetting;
    }

    @Override
    public int updateFromChain(ChainPeerSettingInfo item) {

        //查找本地这条数据,没有返回null
        PeerSettingInfo peerSettingInfo =  datastore.find(PeerSettingInfo.class).filter("pkPeerSettingInfo",item.getPkPeerSettingInfo()).get();
        if (peerSettingInfo==null){
            peerSettingInfo=new PeerSettingInfo();
            peerSettingInfo.setPkPeerSettingInfo(item.getPkPeerSettingInfo());
            peerSettingInfo.setPeerType(PeerSettingInfo.PeerType.SYNCH);
        }

        peerSettingInfo.setPkCompanyInfo( item.getPkCompanyInfo());
        peerSettingInfo.setPeerSettingName(item.getPeerSettingName());
        peerSettingInfo.setIp(item.getIp());
        peerSettingInfo.setChainAddr(item.getChainAddr());
        peerSettingInfo.setStatus( item.getStatus());
        peerSettingInfo.setPublishedInterfaceAuth(item.getPublishedInterfaceAuth());
        peerSettingInfo.setSmartAppAuth(item.getSmartAppAuth());
        peerSettingInfo.setAgreementNo(item.getAgreementNo());


        int i=0;
        String id =save(peerSettingInfo);
        if(StringUtils.isNotBlank(id)){
            i=1;
        }

        return i;
    }

    @Override
    public void updateCompany(PeerSettingInfo peerSettingInfo, String pkCompanyInfo) {
        if(StringUtils.isBlank(peerSettingInfo.getPkCompanyInfo())){
            //所属商户为空
            peerSettingInfo.setPkCompanyInfo(pkCompanyInfo);
            save(peerSettingInfo);
        }else{
            //所属商户不为空
            CompanyInfo companyInfo = new CompanyInfo();
            companyInfo.setPkCompanyInfo(peerSettingInfo.getPkCompanyInfo());
            companyInfo = orgInfoService.getCompanyInfoByID(companyInfo);
            if (companyInfo == null) {
                //查找商户失败
                peerSettingInfo.setPkCompanyInfo(pkCompanyInfo);
                save(peerSettingInfo);
            }
        }
    }
}
