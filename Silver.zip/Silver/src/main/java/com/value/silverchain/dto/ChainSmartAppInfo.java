package com.value.silverchain.dto;

import com.value.silverchain.model.BasePage;
import com.value.silverchain.model.SmartAppInfo;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 *  智能应用信息上链下链配置类
 */
@Data
public class ChainSmartAppInfo extends BasePage{

    private String pkSmartAppInfo;//智能应用主键

    private String pkCompanyInfo;//发布智能应用的商户主键
    
    private String smartAppName;//智能应用名称
    
    private String aid;//唯一标识ID，后台生成

    //    private Constants.ApiType apiType;//服务接口类型
    private String pkApiTypeInfo;//服务接口类型主键
    
    private List<String> cooperateCompany;//合作方列表
    
    private Date startDate;//有效期-开始时间
    
    private Date endDate;//有效期-结束时间

    private Date publishDate;//发布日期
    
    private List<String> taskContent;//任务列表

    private Integer taskNum;//任务数量

    private String apiDescription;//回调API接口描述
    
    private SmartAppInfo.Status status;//应用状态：正常， 暂停， 终止
    
    private SmartAppInfo.Aprover aprover;//审核状态：未发布，待审核，已审核

    private String failueApi;//失败回调API接口

    public ChainSmartAppInfo(SmartAppInfo smartAppInfo){
        this.setPkSmartAppInfo(smartAppInfo.getPkSmartAppInfo());
        this.setPkCompanyInfo(smartAppInfo.getPkCompanyInfo());
        this.setSmartAppName(smartAppInfo.getSmartAppName());
        this.setAid(smartAppInfo.getAid());
//        this.setApiType(smartAppInfo.getApiType());
        this.setPkApiTypeInfo(smartAppInfo.getPkApiTypeInfo());
        this.setCooperateCompany(smartAppInfo.getCooperateCompany());
        this.setStartDate(smartAppInfo.getStartDate());
        this.setEndDate(smartAppInfo.getEndDate());
        this.setPublishDate(smartAppInfo.getPublishDate());
        this.setTaskContent(smartAppInfo.getTaskContent());
        this.setTaskNum(smartAppInfo.getTaskNum());
        this.setApiDescription(smartAppInfo.getApiDescription());
        this.setStatus(smartAppInfo.getStatus());
        this.setAprover(smartAppInfo.getAprover());
        this.setFailueApi(smartAppInfo.getFailueApi());
    }

    public  ChainSmartAppInfo() {

    }

}