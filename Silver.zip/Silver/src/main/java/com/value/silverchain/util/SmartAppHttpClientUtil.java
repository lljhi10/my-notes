package com.value.silverchain.util;

import com.alibaba.fastjson.JSON;
import com.value.silverchain.common.Constants;
import com.value.silverchain.exception.HorizonBizException;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.net.UnknownHostException;

/**
 * 智能应用调用客户端专用工具类
 */
@Slf4j
public final class SmartAppHttpClientUtil {

    private static PoolingHttpClientConnectionManager poolingHttpClientConnectionManager;

    private static final Integer CON_MAX_TOTAL = 200;

    private static final Integer CON_MAX_PERROUTE = 50;

    private static class PoolSingle {
        private static PoolingHttpClientConnectionManager pool = new PoolingHttpClientConnectionManager();
        private PoolSingle(){}
    }

    private static PoolingHttpClientConnectionManager getInstance() {
        poolingHttpClientConnectionManager = PoolSingle.pool;
        if (null != poolingHttpClientConnectionManager) {
            poolingHttpClientConnectionManager.setMaxTotal(CON_MAX_TOTAL);// 整个连接池最大连接数
            poolingHttpClientConnectionManager.setDefaultMaxPerRoute(CON_MAX_PERROUTE);// 每路由最大连接数，默认值是2
        }
        return poolingHttpClientConnectionManager;
    }

    private static CloseableHttpClient getCloseableHttpClient() {
        getInstance();
        return HttpClients.custom().setConnectionManager(poolingHttpClientConnectionManager).build();
    }
    private static CloseableHttpClient getCloseableHttpClient(RequestConfig config) {
        getInstance();
        return HttpClients.custom()
                       .setConnectionManager(poolingHttpClientConnectionManager)
                       .setDefaultRequestConfig(config)
                       .build();
    }

    /**
     * 远程访问
     * @param url
     * @param json
     * @return
     * @throws HorizonBizException
     */
    public static String doPostJson(String url, String json) throws HorizonBizException {
        // 创建Httpclient对象
        CloseableHttpClient httpClient = getCloseableHttpClient();

        CloseableHttpResponse response = null;
        String resultString = null;
        try {
            // 创建Http Post请求
            HttpPost httpPost = new HttpPost(url);
            // 创建请求内容
            StringEntity entity = new StringEntity(json, ContentType.APPLICATION_JSON);
            httpPost.setEntity(entity);
//            httpPost.addHeader("token","token");
            // 执行http请求
            response = httpClient.execute(httpPost);
            log.info("[ httpClient ] POST url : {}", url);
//            String jsonString = JSON.toJSONString(response == null ? "{}" : response);
//			log.info("[ httpClient ] POST response : {}", jsonString);

            if (null != response && response.getStatusLine().getStatusCode() == 200) {
                resultString = EntityUtils.toString(response.getEntity(), "utf-8");
            }else{
                throw new HorizonBizException(Constants.Return.INIT_COMPANY_ERROR,null!=response?"状态码："+response.getStatusLine().getStatusCode():"没有返回信息");
            }
        } catch (UnknownHostException e) {
            log.error("[ httpClient ] GET failed : {}" + url, e);
            throw new HorizonBizException(Constants.Return.HOST_PARSE_ERROR,e.getMessage());
        } catch (HttpHostConnectException e) {
            log.error("[ httpClient ] GET failed : {}" + url, e);
            throw new HorizonBizException(Constants.Return.HOST_CONNECT_ERROR,e.getMessage());
        } catch (Exception e) {
            log.error("[ httpClient ] POST failed : {}", url, e);
            e.printStackTrace();
            throw new HorizonBizException(Constants.Return.RAS_ERR,e.getMessage());
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error("[ httpClient ] Release resources failed : {}", url, e);
            }
        }
        return resultString;
    }

    /**
     * 远程访问，表头中带token参数
     * @param url
     * @param json
     * @param token
     * @return
     * @throws HorizonBizException
     */
    public static String  doPostJsonWithToken(String url, String json,String token) throws HorizonBizException {
        // 创建Httpclient对象
        CloseableHttpClient httpClient = getCloseableHttpClient();

        CloseableHttpResponse response = null;
        String resultString = null;
        try {
            // 创建Http Post请求
            HttpPost httpPost = new HttpPost(url);
            // 创建请求内容
            StringEntity entity = new StringEntity(json, ContentType.APPLICATION_JSON);
            httpPost.setEntity(entity);
            httpPost.addHeader("token",token);
            // 执行http请求
            response = httpClient.execute(httpPost);
            log.info("[ httpClient ] POST url : {}", url);
//            String jsonString = JSON.toJSONString(response == null ? "{}" : response);
//            log.info("[ httpClient ] POST response : {}", jsonString);

            if (null != response && response.getStatusLine().getStatusCode() == 200) {
                resultString = EntityUtils.toString(response.getEntity(), "utf-8");
            }else{
                throw new HorizonBizException(Constants.Return.INIT_COMPANY_ERROR,null!=response?"状态码："+response.getStatusLine().getStatusCode():"没有返回信息");
            }
        } catch (UnknownHostException e) {
            log.error("[ httpClient ] GET failed : {}" + url, e);
            throw new HorizonBizException(Constants.Return.HOST_PARSE_ERROR,e.getMessage());
        } catch (HttpHostConnectException e) {
            log.error("[ httpClient ] GET failed : {}" + url, e);
            throw new HorizonBizException(Constants.Return.HOST_CONNECT_ERROR,e.getMessage());
        } catch (Exception e) {
            log.error("[ httpClient ] POST failed : {}", url, e);
            e.printStackTrace();
            throw new HorizonBizException(Constants.Return.RAS_ERR,e.getMessage());
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error("[ httpClient ] Release resources failed : {}", url, e);
            }
        }
        return resultString;
    }

    /**
     * 远程访问，设置了连接超时时间
     * @param url
     * @param json
     * @param token
     * @return
     */
    public static String doPostJsonTimeout(String url, String json,String token) {
        // 创建Httpclient对象
        RequestConfig defaultRequestConfig = RequestConfig.custom()
                                                     .setSocketTimeout(2000)//socket读数据超时时间：从服务器获取响应数据的超时时间
                                                     .setConnectTimeout(2000)//与服务器连接超时时间：httpclient会创建一个异步线程用以创建socket连接，此处设置该socket的连接超时时间  
                                                     .setConnectionRequestTimeout(1000)//从连接池中获取连接的超时时间 
                                                     .setStaleConnectionCheckEnabled(true)
                                                     .build();
        CloseableHttpClient httpClient = getCloseableHttpClient(defaultRequestConfig);
        CloseableHttpResponse response = null;
        String resultString = null;
        try {
            // 创建Http Post请求
            HttpPost httpPost = new HttpPost(url);
            // 创建请求内容
            StringEntity entity = new StringEntity(json, ContentType.APPLICATION_JSON);
            httpPost.setEntity(entity);
            httpPost.addHeader("token",token);
            // 执行http请求
            response = httpClient.execute(httpPost);
            log.info("[ httpClient ] POST url : {}", url);
            String jsonString = JSON.toJSONString(response == null ? "{}" : response);
//            log.info("[ httpClient ] POST response : {}", jsonString);

            if (null != response && response.getStatusLine().getStatusCode() == 200) {
                resultString = EntityUtils.toString(response.getEntity(), "utf-8");
            }
        } catch (Exception e) {
            log.error("[ httpClient ] POST failed : {}", url, e);
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error("[ httpClient ] Release resources failed : {}", url, e);
            }
        }
        return resultString;
    }

    /**
     * 智能应用调用，只调用，不管回复
     * @param url
     * @param json
     * @param token
     * @return
     */
    public static String doCallExcute(String url, String json,String token) throws HorizonBizException {
        // 创建Httpclient对象
        RequestConfig defaultRequestConfig = RequestConfig.custom()
                                                     .setSocketTimeout(1)//socket读数据超时时间：从服务器获取响应数据的超时时间
                                                     .setConnectTimeout(2000)//与服务器连接超时时间：httpclient会创建一个异步线程用以创建socket连接，此处设置该socket的连接超时时间  
                                                     .setConnectionRequestTimeout(1000)//从连接池中获取连接的超时时间 
                                                     .setStaleConnectionCheckEnabled(true)
                                                     .build();
        CloseableHttpClient httpClient = getCloseableHttpClient(defaultRequestConfig);
        CloseableHttpResponse response = null;
        String resultString = null;
        try {
            // 创建Http Post请求
            HttpPost httpPost = new HttpPost(url);
            // 创建请求内容
            StringEntity entity = new StringEntity(json, ContentType.APPLICATION_JSON);
            httpPost.setEntity(entity);
            httpPost.addHeader("token",token);
            // 执行http请求
            response = httpClient.execute(httpPost);
//            log.info("[ httpClient ] POST url : {}", url);
//            String jsonString = JSON.toJSONString(response == null ? "{}" : response);
////            log.info("[ httpClient ] POST response : {}", jsonString);
//
//            if (null != response && response.getStatusLine().getStatusCode() == 200) {
//                resultString = EntityUtils.toString(response.getEntity(), "utf-8");
//            }
        } catch (UnknownHostException e) {
            log.error("[ httpClient ] GET failed : {}" + url, e);
            throw new HorizonBizException(Constants.Return.HOST_PARSE_ERROR,e.getMessage());
        } catch (HttpHostConnectException e) {
            log.error("[ httpClient ] GET failed : {}" + url, e);
            throw new HorizonBizException(Constants.Return.HOST_CONNECT_ERROR,e.getMessage());
        } catch (Exception e) {
            log.error("[ httpClient ] POST failed : {}", url, e);
            e.printStackTrace();
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error("[ httpClient ] Release resources failed : {}", url, e);
            }
        }
        return resultString;
    }

}