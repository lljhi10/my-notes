package com.value.silverchain.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Id;
import org.mongodb.morphia.annotations.Indexed;
import org.mongodb.morphia.annotations.Transient;
import org.mongodb.morphia.utils.IndexDirection;

import java.io.Serializable;
import java.util.*;

/**
 * 角色信息
 */
@Entity("base_role")
@Data
public class BaseRole  extends BasePage{
    public enum Status {
        VALID("有效"), INVALID("无效");
        private String name;
        Status(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    @Id
    @JsonIgnore
    private ObjectId id;
    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_pkRole",dropDups = true)
    private String pkRole;//主键

    private String roleName;//角色名称

    private String description;//角色描述

    private String pkCompany;//所属商户

    private Status status;//角色状态：有效， 无效

    private List<MenuSource> menuList;//资源权限

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createDate;//创建时间

    private String createManager;//创建人

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateDate;//最后更新时间

    private String updateManager;//最后更新人

    @Transient
    private String companyName;//商户名称

    public void setSid(String sid) {
        this.pkRole = sid;
    }
    /**
     * 获取用户的页面资源权限表
     * @return
     */
    public Set<String> getPaths(){
        Set<String> paths = new HashSet<String>();
        Map<String,String> menuMap = new HashMap<>();
        if (menuList!=null&&menuList.size()>0){
            menuList.forEach(menuSource -> {
                if(menuSource.getRightList()!=null&&menuSource.getRightList().size()>0){
                    String menuName = menuSource.getMenuName();
                    String firstMenuName =menuSource.getFirstMenu();

//                    paths.add(menuName);//二级菜单权限
                    menuSource.getRightList().forEach(baseRight -> {
                        if (baseRight.getIsChecked()!=null&&baseRight.getIsChecked().equals(BaseRight.Status.CHECKED)){
                            paths.add(menuName+"."+baseRight.getRightName());//页面操作权限
                            menuMap.put(menuName,menuName);//二级菜单权限
                            if (firstMenuName != null) {
                                menuMap.put(firstMenuName,firstMenuName);//一级菜单
                            }
                        }
                    });

                }
            });
        }
        //一级和二级菜单显示权限
        for(String value:menuMap.values()){
            paths.add(value);
        }
        return  paths;
    }

    public Map getStatusObject() {
        Map map = new HashMap();
        map.put("name",this.status.getName());
        map.put("value",this.status);
        return map;
    }
}