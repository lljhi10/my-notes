package com.value.silverchain.controller;

import com.value.silverchain.vo.Result;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: ${date}
 * DESC:通信加密
 */
@Controller
@RequestMapping("/encrypted/v1")
public class OrgEncryptedCommController {
    @RequestMapping("/create")
    public String create(){
        Result result = new Result();
        
        return result.toJson();
    }
}
