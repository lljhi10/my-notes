package com.value.silverchain.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.*;
import org.mongodb.morphia.utils.IndexDirection;

/**
 *  交易信息
 */
@Entity("deal_info")
@Data
public class DealInfo extends BasePage implements Cloneable{

    @Id
    @JsonIgnore
    private ObjectId id;
    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_pkDealInfo",dropDups = true)
    private String pkDealInfo;//主键
    @Indexed(unique = true, value = IndexDirection.DESC, name = "idx_dealToken",dropDups = true)
    private String dealToken;//交易token
//    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Indexed(unique = false, value = IndexDirection.ASC, name = "idx_dealDate",dropDups = false)
    private String dealDate;//交易时间
    @Transient
    private String payCompany;//付款方
    @Transient
    private String receiptCompany;//收款方

    private String dealSum;//交易金额(元)

    private Float handlingCharge;//平台手续费(元)
    @Indexed(unique = true, value = IndexDirection.DESC, name = "idx_dealNo",dropDups = true)
    private String dealNo;//新交易流水号=智能应用发布商户的商户号_交易流水号

    
    private String payPkCompanyInfo;//付款方商户主键

    private String receiptPkCompanyInfo;//收款方商户主键

    @Indexed(unique = false, value = IndexDirection.ASC, name = "idx_merId",dropDups = false)
    private String merId;//商户号(收款方商户号)
    
    private String accNo;//银行卡号
    
    private String aid;//智能应用aid

    @Transient
    private String orderId;//交易流水号

    @Transient
    private String logKeyHead;//日志key头

    @Transient
    private Integer logIndex;//日志key下标

    /**
     * 把logIndex+1,并返回
     * @return
     */
    public Integer addLogIndex() {
        this.setLogIndex(this.getLogIndex()+1);
        return this.getLogIndex();
    }
    @Override
    public DealInfo clone() throws CloneNotSupportedException{
        return (DealInfo)super.clone();
    }
}