package com.value.silverchain.controller;

import com.mongodb.DuplicateKeyException;
import com.value.silverchain.bo.PageBo;
import com.value.silverchain.common.Constants;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.ApiTypeInfo;
import com.value.silverchain.model.ManagerInfo;
import com.value.silverchain.service.IApiTypeService;
import com.value.silverchain.service.IChainService;
import com.value.silverchain.vo.ApiTypeRequest;
import com.value.silverchain.vo.LoginManager;
import com.value.silverchain.vo.Result;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: ${date}
 * DESC:智能APP
 */
@Controller
@RequestMapping("/apitype/v1")
public class ApiTypeInfoController {

    private Logger logger = LoggerFactory.getLogger(ApiTypeInfoController.class);
    @Autowired
    private IApiTypeService apiTypeService;

    @Autowired
    private IChainService chainService;

    /**
     * 创建服务接口类型
     * @param apiTypeInfo
     * @param session
     * @return
     */
    @RequestMapping("/create")
    @ResponseBody
    public String create(@RequestBody ApiTypeInfo apiTypeInfo, HttpSession session){

        Result result = checkNull(apiTypeInfo);//参数非空验证
        if (!result.verify()){
            return result.toJson();
        }else{
            try {

                //检查权限
                LoginManager loginManager = (LoginManager)session.getAttribute("loginManager");
                if(null==loginManager){
                    throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
                }
                if(!loginManager.isUp()){//不是UP商户的管理员，没有创建权限
                    throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
                }
                Date date = new Date();
                ManagerInfo loginUser = loginManager.getLoginUser();
                apiTypeInfo.setPkApiTypeInfo(UUID.randomUUID().toString());
                apiTypeInfo.setCreateManager(loginUser.getPkManagerInfo());
                apiTypeInfo.setCreateDate(date);
                apiTypeInfo.setStatus(ApiTypeInfo.Status.NORMAL);
                
                String id =apiTypeService.save(apiTypeInfo);
                if(StringUtils.isBlank(id)){
                    throw new HorizonBizException(Constants.Return.CREATE_API_TYPE_INFO_FALSE);
                }
                //上链
                chainService.invokeApiTypeInfo();
            } catch (DuplicateKeyException e) {
                result.setState(Constants.Return.ACCT_ID_REPEAT);
            } catch (HorizonBizException e) {
                result.setState(e.getError());
            }catch (Exception e) {
                result.setState(Constants.Return.CREATE_API_TYPE_INFO_FALSE);
            }
        }
        return result.toJson();
    }


    /*参数非空验证
    * */
    private Result checkNull(ApiTypeInfo apiTypeInfo) {
            Result result = new Result();
        if (StringUtils.isBlank(apiTypeInfo.getApiTypeName())){
            logger.info("--------------------新建服务接口类型错误:服务接口类型名称不能为空！-------------------------------------");
            result.setState(Constants.Return.APITYPE_NAME_NULL);
        } else if (apiTypeInfo.getTargetType() == null
                           ||(apiTypeInfo.getTargetType().equals(ApiTypeInfo.TargetType.TARGET)&&(apiTypeInfo.getTargetCompany()==null||apiTypeInfo.getTargetCompany().size()<=0))//指定商户时，没有商户数据
                           ||(apiTypeInfo.getTargetType().equals(ApiTypeInfo.TargetType.OPEN)&&apiTypeInfo.getTargetCompany()!=null&&apiTypeInfo.getTargetCompany().size()>0)//公开时，商户有数据
                       ) {
            logger.info("--------------------新建服务接口类型错误: 目标商户类型为空 或 指定商户时没有商户数据 或 公开时商户有数据！-------------------------------------");
            result.setState(Constants.Return.TARGETTYPE_NULL);
        } 

            return result;

    }

   


    /**
     * 查询明细
     * @param param
     * @param session
     * @return
     */
    @RequestMapping("/findById")
    @ResponseBody
    public String findbyId(@RequestBody ApiTypeRequest param, HttpSession session){
        Result result = new Result();
        if(StringUtils.isBlank(param.getPkApiTypeInfo())) {
            result.setState(Constants.Return.PKAPITYPENFO_NULL);
            return result.toJson();
        }
        try {
            //检查权限
            LoginManager loginManager = (LoginManager)session.getAttribute("loginManager");
            if(null==loginManager){
                throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
            }
            if(!loginManager.isUp()){//不是UP商户的管理员，没有查看权限
                throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
            }

            ApiTypeInfo apiTypeInfo =apiTypeService.getByKey(param.getPkApiTypeInfo());
            
            result.getData().put("apiTypeInfo",apiTypeInfo);
        } catch (DuplicateKeyException e) {
            e.printStackTrace();
            result.setState(Constants.Return.ACCT_ID_REPEAT);
        } catch (HorizonBizException e) {
            result.setState(e.getError());
        }catch (Exception e) {
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }


    /**
     * 分页查找
     * @param apiTypeInfo
     * @param requst
     * @return
     */
    @RequestMapping("/findByPage")
    @ResponseBody
    public String findByPage(@RequestBody ApiTypeInfo apiTypeInfo,HttpServletRequest requst){
        Result result = new Result();
        
        try {
            LoginManager loginUser = (LoginManager)requst.getSession().getAttribute("loginManager");
            if(null==loginUser){
                throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
            }
            PageBo<ApiTypeInfo> smartAppInfos = apiTypeService.findPage(apiTypeInfo);
            result.getData().put("list",smartAppInfos);
        } catch (DuplicateKeyException e) {
            e.printStackTrace();
            result.setState(Constants.Return.ACCT_ID_REPEAT);
        } catch (HorizonBizException e) {
//            e.printStackTrace();
            result.setState(e.getError());
        }catch (Exception e) {
            e.printStackTrace();
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }

    /**
     * 分页查找
     * @param requst
     * @return
     */
    @RequestMapping("/findAll")
    @ResponseBody
    public String findAll(HttpServletRequest requst){
        Result result = new Result();

        try {
            LoginManager loginUser = (LoginManager)requst.getSession().getAttribute("loginManager");
            if(null==loginUser){
                throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
            }
            List<ApiTypeInfo> List = apiTypeService.findAll(loginUser.getCompanyInfo().getPkCompanyInfo());
            result.getData().put("list",List);
        } catch (DuplicateKeyException e) {
            e.printStackTrace();
            result.setState(Constants.Return.ACCT_ID_REPEAT);
        } catch (HorizonBizException e) {
//            e.printStackTrace();
            result.setState(e.getError());
        }catch (Exception e) {
            e.printStackTrace();
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }

}
