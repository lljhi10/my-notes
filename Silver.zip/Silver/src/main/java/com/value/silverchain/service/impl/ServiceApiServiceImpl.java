package com.value.silverchain.service.impl;


import com.value.silverchain.bo.PageBo;
import com.value.silverchain.common.Constants;
import com.value.silverchain.dto.ChainServiceApiInfo;
import com.value.silverchain.dto.CompanyInfoDto;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.ManagerInfo;
import com.value.silverchain.model.PayApiInfo;
import com.value.silverchain.model.ServiceApiInfo;
import com.value.silverchain.service.*;
import org.apache.commons.lang3.StringUtils;
import org.bson.types.ObjectId;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:01
 * DESC:
 */
@Service
public class ServiceApiServiceImpl implements IServiceApiService {

    @Autowired
    private Datastore datastore;

    @Autowired
    private IOrgInfoService orgInfoService;

//    @Autowired
//    private IPayApiService payApiService;

    @Autowired
    private IApiTypeService apiTypeService;
    @Autowired
    private IPriceTypeService priceTypeService;


    @Override
    public String save(ServiceApiInfo serviceApiInfo) {

        Key<ServiceApiInfo> key = datastore.save(serviceApiInfo);
        return ((ObjectId) key.getId()).toHexString();
    }

    @Override
    public ServiceApiInfo getByKey(String pkServiceApiInfo) {
        Query<ServiceApiInfo> query = datastore.find(ServiceApiInfo.class).filter("pkServiceApiInfo", pkServiceApiInfo);
        ServiceApiInfo serviceApiInfo=query.get();
        if (serviceApiInfo != null) {
            List<CompanyInfoDto> companyInfoList=orgInfoService.findAllByKeys(serviceApiInfo.getTargetCompany());
            serviceApiInfo.setTargetCompanyName(orgInfoService.getComapnyName(serviceApiInfo.getTargetCompany()));
            serviceApiInfo.setPublishCompanyName(orgInfoService.getComapnyNameByKey(serviceApiInfo.getPkCompanyInfo()));
            serviceApiInfo.setApiTypeInfo(apiTypeService.getByKey(serviceApiInfo.getPkApiTypeInfo()));
            serviceApiInfo.setPriceTypeInfo(priceTypeService.getByKey(serviceApiInfo.getPkPriceTypeInfo()));
        }
        return serviceApiInfo;
    }

    @Override
    public PageBo<ServiceApiInfo> findPage(ServiceApiInfo param) {
        List<ServiceApiInfo> list = new ArrayList<>();
        long count=0;
        if(param.getFindType().equals(ServiceApiInfo.FindType.CREATE)){
            //查自己创建的服务接口
            Query<ServiceApiInfo> query = datastore.find(ServiceApiInfo.class);
            if (param.getPkCompanyInfo()!=null){
                query.field("pkCompanyInfo").equal(param.getPkCompanyInfo());
            }
            if(StringUtils.isNotBlank(param.getApiName())) {
                query.field("apiName").contains(param.getApiName());
            }
            query.order("-_id");
            query.offset(param.getPageNo() * param.getPageSize() - param.getPageSize());
            query.limit(param.getPageSize());
            list=query.asList();
            count=query.count();
            if(list!=null&&list.size()>0){
                list.forEach(serviceApiInfo -> {
                    if (serviceApiInfo.getTargetCompany()!=null&&serviceApiInfo.getTargetCompany().size()>0){
                        serviceApiInfo.setTargetCompanyName(orgInfoService.getComapnyName(serviceApiInfo.getTargetCompany()));
                    }
                    serviceApiInfo.setPublishCompanyName(orgInfoService.getComapnyNameByKey(serviceApiInfo.getPkCompanyInfo()));
                    serviceApiInfo.setApiTypeInfo(apiTypeService.getByKey(serviceApiInfo.getPkApiTypeInfo()));
                    serviceApiInfo.setPriceTypeInfo(priceTypeService.getByKey(serviceApiInfo.getPkPriceTypeInfo()));
                });
            }
        }else{
            //查链上的发布的服务
            Query<ServiceApiInfo> query = datastore.find(ServiceApiInfo.class);
            if (param.getPkCompanyInfo()!=null){
                //不是登录者所属商户发布的
                query.field("pkCompanyInfo").notEqual(param.getPkCompanyInfo());
            }
            query.or(query.criteria("targetType").equal(ServiceApiInfo.TargetType.OPEN),//公开
                    query.criteria("targetCompany").contains(param.getPkCompanyInfo()));//目标商户包含登录者所在商户
            if(StringUtils.isNotBlank(param.getApiName())) {
                query.field("apiName").contains(param.getApiName());
            }
            Date date = new Date();
            query.field("endDate").greaterThanOrEq(date);
            query.field("publish").equal(PayApiInfo.Publish.EFFICIENT).field("status").equal(PayApiInfo.Status.NORMAL);


            query.order("-_id");
            query.offset(param.getPageNo() * param.getPageSize() - param.getPageSize());
            query.limit(param.getPageSize());
            list=query.asList();
            count=query.count();
            if(list!=null&&list.size()>0){
                list.forEach(serviceApiInfo -> {
                    if (serviceApiInfo.getTargetCompany()!=null&&serviceApiInfo.getTargetCompany().size()>0){
                        serviceApiInfo.setTargetCompanyName(orgInfoService.getComapnyName(serviceApiInfo.getTargetCompany()));
                    }
                    serviceApiInfo.setPublishCompanyName(orgInfoService.getComapnyNameByKey(serviceApiInfo.getPkCompanyInfo()));
                    serviceApiInfo.setApiTypeInfo(apiTypeService.getByKey(serviceApiInfo.getPkApiTypeInfo()));
                    serviceApiInfo.setPriceTypeInfo(priceTypeService.getByKey(serviceApiInfo.getPkPriceTypeInfo()));
                });
            }
        }

        return new PageBo(list,count);
    }

    @Override
    public void delete(String pkServiceApiInfo) {
        datastore.delete(datastore.find(ServiceApiInfo.class).field("pkServiceApiInfo").equal(pkServiceApiInfo));
    }

    @Override
    public String update(ServiceApiInfo serviceApiInfo, ManagerInfo loginUser) throws HorizonBizException {
        //查找服务接口
        ServiceApiInfo targetInfo = getByKey(serviceApiInfo.getPkServiceApiInfo());
        if (targetInfo == null) {
            throw new HorizonBizException(Constants.Return.FIND_PAY_API_INFO_FALSE);
        }
        if (targetInfo.getStatus().equals(ServiceApiInfo.Status.TERMINATION)){
            //已经终止的支付接口不能修改
            throw new HorizonBizException(Constants.Return.PAY_API_INFO_TERMINATION);
        }
        if (!targetInfo.getPkCompanyInfo().equals(loginUser.getPkCompanyInfo())){
            //不是登录者所在商户的支付接口不能修改
            throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
        }
        Date date = new Date();

        if (serviceApiInfo.getPkApiTypeInfo() != null) {
            targetInfo.setPkApiTypeInfo(serviceApiInfo.getPkApiTypeInfo());
        }
        if (serviceApiInfo.getApiName() != null) {
            targetInfo.setApiName(serviceApiInfo.getApiName());
        }
        if (StringUtils.isNotBlank(serviceApiInfo.getDescription())) {
            targetInfo.setDescription(serviceApiInfo.getDescription());
        }
        if (serviceApiInfo.getPrice() != null) {
            targetInfo.setPrice(serviceApiInfo.getPrice());
        }

//        if (serviceApiInfo.getAmount()!=null) {
//            targetInfo.setAmount(serviceApiInfo.getAmount());
//        }
        if (serviceApiInfo.getTargetCompany() != null) {
            targetInfo.setTargetCompany(serviceApiInfo.getTargetCompany());
        }
        if (serviceApiInfo.getTargetType()!=null) {
            targetInfo.setTargetType(serviceApiInfo.getTargetType());
        }
//        if (serviceApiInfo.getApiDescription()!=null) {
//            targetInfo.setApiDescription(serviceApiInfo.getApiDescription());
//        }
        if (serviceApiInfo.getStartDate()!=null) {
            targetInfo.setStartDate(serviceApiInfo.getStartDate());
        }
        if (serviceApiInfo.getEndDate()!=null) {
            targetInfo.setEndDate(serviceApiInfo.getEndDate());
        }
        if(serviceApiInfo.getStatus()!=null){
            targetInfo.setStatus(serviceApiInfo.getStatus());
        }

        //如果选择发布则添加
        if(targetInfo.getPublish().equals(ServiceApiInfo.Publish.UNPUBLISH)&&serviceApiInfo.getPublish().equals(ServiceApiInfo.Publish.EFFICIENT)){
//            if(DateUtils.parseDate(DateFormatUtils.format(serviceApiInfo.getStartDate(),"yyyy-mm-dd")).before(DateUtils.parseDate(DateFormatUtils.format(new Date(),"yyyy-mm-dd")))){
//                //开始时间小于当前时间
//                throw new HorizonBizException(Constants.Return.START_DATE_LESS_THEM_CURRENT);
//            }
            if(serviceApiInfo.getEndDate().getTime() <= new Date().getTime()){
                //有效期结束时间小于当前时间
                throw new HorizonBizException(Constants.Return.END_DATE_LESS_THEM_CURRENT);
            }
            //检查唯一性,保证在同一商户下，同一接口类型，同一目标商户(公开看成是一种商户)，同一时间段内正常的生效的支付接口记录只有一条
            checkUniqueness(serviceApiInfo);
            targetInfo.setPublish(serviceApiInfo.getPublish());
            targetInfo.setPublishDate(date);
        }
        if (StringUtils.isNotBlank(serviceApiInfo.getPath())) {
            targetInfo.setPath(serviceApiInfo.getPath());
        }
        if (serviceApiInfo.getMethod()!=null) {
            targetInfo.setMethod(serviceApiInfo.getMethod());
        }
        if (serviceApiInfo.getContentType()!=null) {
            targetInfo.setContentType(serviceApiInfo.getContentType());
        }
        if (StringUtils.isNotBlank(serviceApiInfo.getParamExplain())) {
            targetInfo.setParamExplain(serviceApiInfo.getParamExplain());
        }
        if (StringUtils.isNotBlank(serviceApiInfo.getRequestMessageFormat())) {
            targetInfo.setRequestMessageFormat(serviceApiInfo.getRequestMessageFormat());
        }
        if (StringUtils.isNotBlank(serviceApiInfo.getResponseMessageFormat())) {
            targetInfo.setResponseMessageFormat(serviceApiInfo.getResponseMessageFormat());
        }
        if (StringUtils.isNotBlank(serviceApiInfo.getErrorCodeDefinition())) {
            targetInfo.setErrorCodeDefinition(serviceApiInfo.getErrorCodeDefinition());
        }
        if (StringUtils.isNotBlank(serviceApiInfo.getReportDefinition())) {
            targetInfo.setReportDefinition(serviceApiInfo.getReportDefinition());
        }
        return save(targetInfo);
    }



    private Query<ServiceApiInfo> initQuery() {
        Query<ServiceApiInfo> query = datastore.find(ServiceApiInfo.class);

        query.field("status").equal(ServiceApiInfo.Status.NORMAL);
        query.field("publish").equal(ServiceApiInfo.Publish.EFFICIENT);
        Date date = new Date();
        query.field("startDate").lessThanOrEq(date).field("endDate").greaterThanOrEq(date);
        return  query;
    }


    @Override
    public void checkUniqueness(ServiceApiInfo param) throws HorizonBizException {
//        List<ServiceApiInfo> payApiInfoList=new ArrayList<>();
        Query<ServiceApiInfo> query = initQuery2(param);
        query.field("targetType").equal(param.getTargetType());
        query.or(query.and(query.criteria("startDate").lessThanOrEq(param.getStartDate()),query.criteria("endDate").greaterThanOrEq(param.getEndDate())),//startDate<=start and endDate>=end 新建有效期被已有包含
                query.and(query.criteria("startDate").greaterThanOrEq(param.getStartDate()),query.criteria("endDate").lessThanOrEq(param.getEndDate())),//startDate>=start and endDate<=end 新建有效期包含已有
                query.and(query.criteria("startDate").lessThan(param.getEndDate()),query.criteria("endDate").greaterThanOrEq(param.getEndDate())),//startDate<end and endDate>=end 新建的有效期结束时间在已有的期间
                query.and(query.criteria("startDate").lessThanOrEq(param.getStartDate()),query.criteria("endDate").greaterThan(param.getStartDate()))//startDate<=start and endDate>start 新建的有效期开始时间在已有的期间
        );
        if (param.getTargetType().equals(ServiceApiInfo.TargetType.OPEN)) {
            //公开
            query.field("targetCompany").equal(null);
        }else{
            //指定
            query.field("targetCompany").hasAnyOf(param.getTargetCompany());
        }
//        payApiInfoList=query.asList();
//        throw new HorizonBizException(Constants.Return.PEER_UNFOUND_ERROR);
        if (query.count()>0) {
            throw new HorizonBizException(Constants.Return.PAY_API_INFO_HAS_EFFICIENT);
        }
    }
    private Query<ServiceApiInfo> initQuery2(ServiceApiInfo param) {
        Query<ServiceApiInfo> query = datastore.find(ServiceApiInfo.class);
        query.field("pkCompanyInfo").equal(param.getPkCompanyInfo());//登录用户所在商户
        query.field("pkApiTypeInfo").equal(param.getPkApiTypeInfo());
        query.field("status").equal(ServiceApiInfo.Status.NORMAL);
        query.field("publish").equal(ServiceApiInfo.Publish.EFFICIENT);
        


        return  query;
    }

    @Override
    public int updateFromChain(ChainServiceApiInfo item) {
        //查找本地这条数据,没有返回null
        ServiceApiInfo serviceApiInfo =  datastore.find(ServiceApiInfo.class).filter("pkServiceApiInfo",item.getPkServiceApiInfo()).get();
        if (serviceApiInfo==null){
            serviceApiInfo=new ServiceApiInfo();
            serviceApiInfo.setPkServiceApiInfo(item.getPkServiceApiInfo());
        }

        serviceApiInfo.setPkCompanyInfo( item.getPkCompanyInfo());
        serviceApiInfo.setPkApiTypeInfo( item.getPkApiTypeInfo());
        serviceApiInfo.setPkPriceTypeInfo(item.getPkPriceTypeInfo());
        serviceApiInfo.setApiName( item.getApiName());
        serviceApiInfo.setDescription(item.getDescription());
        serviceApiInfo.setPrice( item.getPrice());
        serviceApiInfo.setTargetCompany( item.getTargetCompany());
        serviceApiInfo.setTargetType( item.getTargetType());
//        serviceApiInfo.setAmount( item.getAmount());
        serviceApiInfo.setPublishDate( item.getPublishDate());
        serviceApiInfo.setStartDate( item.getStartDate());
        serviceApiInfo.setEndDate( item.getEndDate());
        serviceApiInfo.setStatus( item.getStatus());
        serviceApiInfo.setPublish( item.getPublish());
//        serviceApiInfo.setApiDescription( item.getApiDescription());
        serviceApiInfo.setPath(item.getPath());
        serviceApiInfo.setMethod(item.getMethod());
        serviceApiInfo.setContentType(item.getContentType());
        serviceApiInfo.setParamExplain(item.getParamExplain());
        serviceApiInfo.setRequestMessageFormat(item.getRequestMessageFormat());
        serviceApiInfo.setResponseMessageFormat(item.getResponseMessageFormat());
        serviceApiInfo.setErrorCodeDefinition(item.getErrorCodeDefinition());
        serviceApiInfo.setReportDefinition(item.getReportDefinition());

        int i=0;
        String id =save(serviceApiInfo);
        if(StringUtils.isNotBlank(id)){
            i=1;
        }

        return i;
    }

    @Override
    public ServiceApiInfo getByCondition(ServiceApiInfo serviceApiInfo) throws HorizonBizException {
        Query<ServiceApiInfo> query = initQuery2(serviceApiInfo);
        Date date = new Date();
        query.field("startDate").lessThanOrEq(date).field("endDate").greaterThanOrEq(date);
        query.field("targetCompany").hasAnyOf(serviceApiInfo.getTargetCompany());
        if(query.count()==0){
            //没找到指定，查找公开的
            query = initQuery2(serviceApiInfo);
            query.field("startDate").lessThanOrEq(date).field("endDate").greaterThanOrEq(date);
            query.field("targetCompany").equal(null);
        }
        if(query.count()==0){
            throw new HorizonBizException(Constants.Return.FIND_SERVICE_API_INFO_FALSE);
        }
        if(query.count()>1){
            throw new HorizonBizException(Constants.Return.MULTI_SERVICE_API_FIND);
        }
        return query.get();
    }
}
