package com.value.silverchain.service.impl;


import com.value.silverchain.bo.PageBo;
import com.value.silverchain.model.ManagerInfo;
import com.value.silverchain.service.IAccountInfoService;
import com.value.silverchain.service.IUserAccountService;
import org.bson.types.ObjectId;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:01
 * DESC:
 */
@Service
public class AccountInfoServiceImpl implements IAccountInfoService {

    @Autowired
    private Datastore datastore;


    @Override
    public String save(ManagerInfo userAccount) {
        Key<ManagerInfo> key = datastore.save(userAccount);
        return ((ObjectId) key.getId()).toHexString();
    }

    @Override
    public ManagerInfo getByUserID(String userID) {
        Query<ManagerInfo> query = datastore.find(ManagerInfo.class).filter("userId", userID);
        return query.get();


        //return datastore.find(ManagerInfo.class).field("id").equal(new ObjectId("5b15fe7a3420fb1010af7675")).get();
    }

    @Override
    public PageBo<ManagerInfo> findPage(ManagerInfo param) {


        PageBo<ManagerInfo> page=null;
        return page;
    }

    @Override
    public String delete(String userId) {
        datastore.delete(datastore.find(ManagerInfo.class).field("userId").equal(userId));
        return null;
    }

    @Override
    public List<ManagerInfo> getUserListByPhone(String phone) {
        List<ManagerInfo> accountList=datastore.createQuery(ManagerInfo.class).field("phone").contains(phone).asList();
        return accountList;
    }

    @Override
    public int update(ManagerInfo param) {

       /* UpdateOperations<ManagerInfo> ops = datastore.createUpdateOperations(ManagerInfo.class); // 建立一个修改器
        ops.set("managerName", param.getManagerName());
        ops.set("address", param.getAddress());*/
      // param.setId(new ObjectId( param.getIdr()));
       // Query<ManagerInfo> qu = datastore.find(ManagerInfo.class).field("id").equal(param.getId());
        //System.out.print("qqqq"+qu);
        int count = datastore.update(datastore.find(ManagerInfo.class).field("id").equal(param.getId()),
                datastore.createUpdateOperations(ManagerInfo.class).set("managerName", param.getManagerName()).set("address", param.getAddress())).getUpdatedCount();

        return count;
    }


}
