package com.value.silverchain.dto;

import lombok.Data;

@Data
public class ChainCodeInfo {
    private String codeVersion;
    private String codeName;
}
