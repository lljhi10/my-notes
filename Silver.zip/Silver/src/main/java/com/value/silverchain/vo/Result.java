package com.value.silverchain.vo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.value.silverchain.common.Constants;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.util.JsonUtil;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/6/4
 * DESC:返回对象
 */
public class Result {
    @JsonProperty("code")
    private String resCode;
    @JsonProperty("msg")
    private String resMsg;

    //返回业务数据
    private Map<String,Object> data=new HashMap();

    public Result(){
        //默认通信成功
        this(Constants.Return.SUCCESS);
    }

    public Result(Constants.Return res){
        resCode=res.getCode();
        resMsg=res.getMsg();
    }

    public Map<String, Object> getData() {
        return data;
    }

    public Result setState(HorizonBizException e){
        String errMsg=e.getError().getMsg();
        if(StringUtils.isNotBlank(e.getErrorMsg())){
            errMsg=e.getErrorMsg();
        }
        resMsg=errMsg;
        resCode=e.getError().getCode();
        return this;
    }

    public Result setState(Constants.Return ret){
        resMsg=ret.getMsg();
        resCode=ret.getCode();
        return this;
    }

    public Result setState(String code,String msg){
        resMsg=msg;
        resCode=code;
        return this;
    }

    public void setResMsg(String resMsg) {
        this.resMsg = resMsg;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    public boolean verify(){
        if(resCode.equals(Constants.Return.SUCCESS.getCode())){
            return true;
        }
        return false;
    }

    public String toJson(){
        return JsonUtil.writeJson(this);
    }
}
