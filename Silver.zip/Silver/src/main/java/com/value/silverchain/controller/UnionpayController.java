package com.value.silverchain.controller;

import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.service.IUnionpayService;
import com.value.silverchain.vo.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created with IntelliJ IDEA.
 * User: liulvjiang
 * Date: ${date}
 * DESC:银联支付接口
 */
@RestController
@RequestMapping("/unionpay/v1")
public class UnionpayController {
    private Logger logger = LoggerFactory.getLogger(UnionpayController.class);
    @Autowired
    private IUnionpayService unionpayService;
    
    @RequestMapping("/consume")
    public String consume(String merId, String txnTime, String orderId, String txnAmt, String accNo) {

        Result result = new Result();

        String resultMsg= null;
        try {
            resultMsg = unionpayService.consume(merId, txnTime, orderId, txnAmt, accNo);
//            result.getData().put("upaydata",resultMsg );
        } catch (HorizonBizException e) {
            e.printStackTrace();
            result.setState(e);
        }
        return result.toJson();
    }
}

 /* Map<String, String> map = new HashMap<>();
        map.put("merId", merId);
        map.put("orderId", orderId);
        map.put("txnTime", txnTime);
        map.put("txnAmt", txnAmt);
        map.put("accNo", accNo);
        String resultMsg = HttpClientUtil.doGet("http://localhost:8055/upservice/v1/consume", map);
        String codeKey="\"code\":";
//        String b="code:";
        String code = resultMsg.substring(resultMsg.indexOf(codeKey) +7 , resultMsg.indexOf(codeKey) + 13);
        if (code.equals("780001")){
            result.setState(Constants.Return.OPEN_CANT);
        }else if (code.equals("780002")){
            result.setState(Constants.Return.UPCONSUME_CANT);
        }else{
           result.setResMsg("消费成功");
        }*/


