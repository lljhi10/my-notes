package com.value.silverchain.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.value.silverchain.dto.CompanyInfoDto;
import lombok.Data;
import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Id;
import org.mongodb.morphia.annotations.Indexed;
import org.mongodb.morphia.annotations.Transient;
import org.mongodb.morphia.utils.IndexDirection;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *  服务接口信息
 */
@Entity("service_api_info")
@Data
public class ServiceApiInfo extends BasePage{
/*    public enum ApiType {
        POINT("积分兑换");
        private String name;

        ApiType(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }*/
    public enum Status {
        NORMAL("正常"), PAUSE("暂停"), TERMINATION("终止");
        private String name;

        Status(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum Publish {
        UNPUBLISH("未发布"),EFFICIENT("生效中");
        private String name;

        Publish(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }

    public enum TargetType {
        OPEN("公开"),TARGET("指定商户");
        private String name;

        TargetType(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum FindType {
        CREATE("商户创建"), VIEW("查看服务接口");
        private String name;

        FindType(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum Method {
        GET("GET"), POST("POST");
        private String name;

        Method(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum ContentType {
        JSON("JSON"), XML("XML");
        private String name;

        ContentType(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    @Id
    @JsonIgnore
    private ObjectId id;
    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_pkServiceApiInfo",dropDups = true)
    private String pkServiceApiInfo;//服务接口主键

    private String pkCompanyInfo;//服务发布商户主键

//    private Constants.ApiType apiType;//服务接口类型
    private String pkApiTypeInfo;//服务接口类型主键

    private String pkPriceTypeInfo;//价格类型主键

    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_pkServiceApiName",dropDups = true)
    private String apiName;//服务接口名称

    private String description;//服务接口描述
    
    private Float price;//销售价格

    private TargetType targetType;//目标类型：公开/指定商户

    private List<String> targetCompany;//目标商户主键，如果为null则表示公开
    
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date startDate;//有效期-开始时间

    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date endDate;//有效期-结束时间

//    private Float amount;//额度
//    @Transient
//    private Float handlingCharge;//平台手续费率
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date publishDate;//发布日期
    
    
//    private String apiDescription;//API接口描述
    
//    private String callBackDescription;//回调接口描述

    private String path;//调用地址

    private Method method;//请求方式
    
    private ContentType contentType;//返回类型
    
    private String paramExplain;//参数说明
    
    private String requestMessageFormat;//请求报文格式

    private String responseMessageFormat;//返回报文格式
    
    private String errorCodeDefinition;//错误码定义
    
    private String reportDefinition;//订单报表定义

    private Publish publish;//发布状态：未发布/生效中
    
    private Status status;//服务接口状态：正常， 暂停， 终止
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createDate;//创建时间

    private String createManager;//创建人
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateDate;//最后更新时间

    private String updateManager;//最后更新人
    
    @Transient
    private FindType findType;//1查询本商户的服务接口，2查询其他商户的服务接口

    @Transient
    private boolean isPublish;//为真则表示要发布

    @Transient
    private String publishCompanyName;//发布商户

    @Transient
    private String targetCompanyName;//目标商户名称

    @Transient
    private List<CompanyInfoDto> companyInfoList;//目标商户列表

    @Transient
    private ApiTypeInfo apiTypeInfo;//服务接口类型

    @Transient
    private PriceTypeInfo priceTypeInfo;//价格类型
//    public Map getApiTypeObject() {
//        Map map = new HashMap();
//        map.put("name",this.apiType.getName());
//        map.put("value",this.apiType);
//        return map;
//    }

    public Map getStatusObject() {
        Map map = new HashMap();
        map.put("name",this.status.getName());
        map.put("value",this.status);
        return map;
    }

    public Map getPublishObject() {
        Map map = new HashMap();
        map.put("name",this.publish.getName());
        map.put("value",this.publish);
        return map;
    }

    public Map getTargetTypeObject() {
        Map map = new HashMap();
        if(this.targetType != null) {
            map.put("name", this.targetType.getName());
            map.put("value", this.targetType);
        }
        return map;
    }
}