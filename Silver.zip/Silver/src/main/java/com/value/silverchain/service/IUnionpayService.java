package com.value.silverchain.service;

import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.BaseRole;


/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:00
 * DESC:
 */
public interface IUnionpayService {

     String consume(String merId, String txnTime, String orderId, String txnAmt, String accNo) throws HorizonBizException;

}
