package com.value.silverchain.service.impl;


import com.value.silverchain.common.Constants;
import com.value.silverchain.common.UpStatus;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.service.IUnionpayService;
import com.value.silverchain.util.HttpClientUtil;
import org.apache.commons.lang3.StringUtils;
import org.mongodb.morphia.Datastore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:01
 * DESC:
 */
@Service
public class UnionpayServiceImpl implements IUnionpayService {
    private Logger logger = LoggerFactory.getLogger(UnionpayServiceImpl.class);
    @Value("${unionpay.consume}")
    private String urlPath;
    @Autowired
    private Datastore datastore;

    public String consume(String merId, String txnTime, String orderId, String txnAmt, String accNo) throws HorizonBizException{
        Map<String, String> map = new HashMap<>();
        map.put("merId", merId);//商户号
        map.put("orderId", orderId);//订单流水号
        map.put("txnTime", txnTime);//订单交易时间
        map.put("txnAmt", txnAmt);//交易金额
        map.put("accNo", accNo);//银行卡号
        String resultMsg = HttpClientUtil.doGet(urlPath, map);
        if (StringUtils.isBlank(resultMsg)) {
            throw new HorizonBizException(Constants.Return.CALL_CONSUME_ERROR);
        }
        String codeKey="\"code\":\"";
        if(resultMsg.indexOf(codeKey)!=-1){
            String code = resultMsg.substring(resultMsg.indexOf(codeKey) +8 , resultMsg.indexOf(codeKey) + 14);
            if(!code.equals("000000")){
                String respCode=resultMsg.substring(resultMsg.indexOf("respCode=") + 9, resultMsg.indexOf("respCode=") + 11);//银联报表应答码
                String respMsg = "";
                if(resultMsg.indexOf("Invalid field[")!=-1){
                    respMsg=resultMsg.substring(resultMsg.indexOf("Invalid field[") , resultMsg.indexOf("Invalid field[") + 22);//非法参数
                }
                if (code.equals("780001")){
                    throw new HorizonBizException(Constants.Return.OPEN_CANT,"应答码:"+respCode+","+ UpStatus.getReason(respCode)+respMsg);
                }else if (code.equals("780002")){
                    throw new HorizonBizException(Constants.Return.UPCONSUME_CANT,"应答码:"+respCode+","+ UpStatus.getReason(respCode)+respMsg);
                }else if (code.equals("780003")){
                    throw new HorizonBizException(Constants.Return.UPPAY_CANT,"应答码:"+respCode+","+ UpStatus.getReason(respCode)+respMsg);
                }else {
                    throw new HorizonBizException(Constants.Return.SYSTEM_ERR,"状态码:"+code+",应答码:"+respCode+","+ UpStatus.getReason(respCode)+respMsg);
                }
            }
        }else{
            logger.error("异常报文："+resultMsg);
            throw new HorizonBizException(Constants.Return.SYSTEM_ERR,"找不到状态码");
        }
        return resultMsg;
    }
}
