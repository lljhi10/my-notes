package com.value.silverchain.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.value.silverchain.model.AccountInfo;
import com.value.silverchain.model.BasePage;
import lombok.Data;
import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Id;
import org.mongodb.morphia.annotations.Indexed;
import org.mongodb.morphia.annotations.Transient;
import org.mongodb.morphia.utils.IndexDirection;

import java.util.Date;

/**
 *  商户业务账户上链下链类
 */
@Data
public class ChainAccountInfo extends BasePage{
    private String pkAccountInfo;//业务账户主键
    private String pkCompanyInfo;//商户主键哦
    private String accountName;//业务账户名称
    private String accountNo;//银行账号;
    private String cardNo;//银行卡账号
    private Date expiryDate;//有效期
    private String cvn;//银行卡cvn码
    private String mobilePhone;//银行卡预留手机号
    private AccountInfo.SupportTradeType supportTradeType;//业务账户类型:收款， 支付
    private String chainAddr;//业务账户区域链地址
    private AccountInfo.Status status;//业务账户状态：正常，暂停，终止
    public ChainAccountInfo(AccountInfo accountInfo){
        this.setPkAccountInfo(accountInfo.getPkAccountInfo());
        this.setPkCompanyInfo(accountInfo.getPkCompanyInfo());
        this.setAccountName(accountInfo.getAccountName());
        this.setAccountNo(accountInfo.getAccountNo());
        this.setCardNo(accountInfo.getCardNo());
        this.setExpiryDate(accountInfo.getExpiryDate());
        this.setCvn(accountInfo.getCvn());
        this.setMobilePhone(accountInfo.getMobilePhone());
        this.setSupportTradeType(accountInfo.getSupportTradeType());
        this.setChainAddr(accountInfo.getChainAddr());
        this.setStatus(accountInfo.getStatus());
    }

    public ChainAccountInfo() {
    }
}