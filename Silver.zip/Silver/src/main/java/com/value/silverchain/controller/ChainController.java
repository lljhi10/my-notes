package com.value.silverchain.controller;

import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.service.IChainService;
import com.value.silverchain.vo.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;

/**
 * Created with IntelliJ IDEA.
 * User: liulvjiang
 * Date: ${date}
 * DESC:接口*/


@RestController
@RequestMapping("/chain/v1")
public class ChainController {
    private Logger logger = LoggerFactory.getLogger(ChainController.class);
    @Autowired
    private IChainService chainService;

    @RequestMapping("/codeinfo")
    public String codeinfo() {
        Result result = new Result();
        try {
            chainService.invokePeer();

        }catch (HorizonBizException e){
            result.setState(e.getError());
        }
        
//        chainService.invokeCompanyInfo();
        return result.toJson();
    }
//queryAccountInfo

    @RequestMapping("/down")
    public String down() {
        Result result = new Result();
        try {
            chainService.queryPeerSettingInfo();

        }catch (HorizonBizException e){
            result.setState(e.getError());
        }
//        chainService.invokeCompanyInfo();
        return result.toJson();
    }
/*
    @RequestMapping("/invoke")
    public String invoke(String args[]) {

        Result result = new Result();

        String resultMsg= null;

        String channelName="unionchannel";
        String fcn = "set";

        String codeName;String codeVersion;
        chainService.invoke( channelName,  codeName, codeVersion, fcn, args);


        try {
//            resultMsg = chainService.consume(merId, txnTime, orderId, txnAmt, accNo);
            result.getData().put("upaydata",resultMsg );
        } catch (HorizonBizException e) {
            e.printStackTrace();
            result.setState(e.getError());
        }
        return result.toJson();
    }

    @RequestMapping("/info")
    public String info(String merId, String txnTime, String orderId, String txnAmt, String accNo) {

        Result result = new Result();

        String resultMsg= null;
        try {
            resultMsg = unionpayService.consume(merId, txnTime, orderId, txnAmt, accNo);
            result.getData().put("upaydata",resultMsg );
        } catch (HorizonBizException e) {
            e.printStackTrace();
            result.setState(e.getError());
        }
        return result.toJson();
    }

    @RequestMapping("/query")
    public String query(String merId, String txnTime, String orderId, String txnAmt, String accNo) {

        Result result = new Result();

        String resultMsg= null;
        try {
            resultMsg = unionpayService.consume(merId, txnTime, orderId, txnAmt, accNo);
            result.getData().put("upaydata",resultMsg );
        } catch (HorizonBizException e) {
            e.printStackTrace();
            result.setState(e.getError());
        }
        return result.toJson();
    }
*/

}

