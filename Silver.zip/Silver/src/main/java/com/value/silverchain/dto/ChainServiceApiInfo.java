package com.value.silverchain.dto;

import com.value.silverchain.model.BasePage;
import com.value.silverchain.model.ServiceApiInfo;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 *  服务接口信息上链下链类
 */
@Data
public class ChainServiceApiInfo extends BasePage{
    private String pkServiceApiInfo;//服务接口主键
    private String pkCompanyInfo;//服务发布商户主键
//    private Constants.ApiType apiType;//服务接口类型
    private String pkApiTypeInfo;//服务接口类型主键
    private String pkPriceTypeInfo;//价格类型主键
    private String apiName;//服务接口名称
    private String description;//服务接口描述
    private List<String> targetCompany;//目标商户主键，如果为null则表示公开
    private Float price;//销售价格
//    private Float amount;//额度
    private ServiceApiInfo.TargetType targetType;//目标类型：公开/指定商户
    private Date publishDate;//发布日期
    private Date startDate;//有效期-开始时间
    private Date endDate;//有效期-结束时间
//    private String apiDescription;//API接口描述
    private String path;//调用地址

    private ServiceApiInfo.Method method;//请求方式

    private ServiceApiInfo.ContentType contentType;//返回类型

    private String paramExplain;//参数说明

    private String requestMessageFormat;//请求报文格式

    private String responseMessageFormat;//返回报文格式

    private String errorCodeDefinition;//错误码定义

    private String reportDefinition;//订单报表定义
    private ServiceApiInfo.Publish publish;//发布状态：未发布/生效中
    private ServiceApiInfo.Status status;//服务接口状态：正常， 暂停， 终止

    public  ChainServiceApiInfo(ServiceApiInfo serviceApiInfo){
        this.setPkCompanyInfo(serviceApiInfo.getPkCompanyInfo());
        this.setPkServiceApiInfo(serviceApiInfo.getPkServiceApiInfo());
//        this.setApiType(serviceApiInfo.getApiType());
        this.setPkApiTypeInfo(serviceApiInfo.getPkApiTypeInfo());
        this.setPkPriceTypeInfo(serviceApiInfo.getPkPriceTypeInfo());
        this.setApiName(serviceApiInfo.getApiName());
        this.setDescription(serviceApiInfo.getDescription());
        this.setTargetCompany(serviceApiInfo.getTargetCompany());
        this.setPrice(serviceApiInfo.getPrice());
//        this.setAmount(serviceApiInfo.getAmount());
        this.setTargetType(serviceApiInfo.getTargetType());
        this.setPublishDate(serviceApiInfo.getPublishDate());
        this.setStartDate(serviceApiInfo.getStartDate());
        this.setEndDate(serviceApiInfo.getEndDate());
//        this.setApiDescription(serviceApiInfo.getApiDescription());
        this.setPath(serviceApiInfo.getPath());
        this.setMethod(serviceApiInfo.getMethod());
        this.setContentType(serviceApiInfo.getContentType());
        this.setParamExplain(serviceApiInfo.getParamExplain());
        this.setRequestMessageFormat(serviceApiInfo.getRequestMessageFormat());
        this.setResponseMessageFormat(serviceApiInfo.getResponseMessageFormat());
        this.setErrorCodeDefinition(serviceApiInfo.getErrorCodeDefinition());
        this.setReportDefinition(serviceApiInfo.getReportDefinition());
        this.setPublish(serviceApiInfo.getPublish());
        this.setStatus(serviceApiInfo.getStatus());
    }

    public  ChainServiceApiInfo() {

    }

}