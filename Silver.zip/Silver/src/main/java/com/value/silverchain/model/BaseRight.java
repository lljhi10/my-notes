package com.value.silverchain.model;

import lombok.Data;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/6/5
 * DESC:权限信息
 */
@Data
public class BaseRight {
    public BaseRight(){}
    
    public BaseRight(RightName rightName) {
        this.setRightName(rightName);
        this.setIsChecked(Status.CHECKED);
    }

    public enum RightName {
        VIEW("查看"), EDIT("编辑"), PUBLISH("发布"), APPROVER("审核");
        private String name;

        RightName(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum Status {
        CHECKED("选中"), UNCHECKED("不选中");
        private String name;
        Status(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    private RightName rightName;//权限名称
    private Status isChecked;//是否选中
}
