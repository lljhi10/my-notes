package com.value.silverchain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
@ServletComponentScan
public class SilverchainApplication extends SpringBootServletInitializer {
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder  application) {
		return application.sources(SilverchainApplication.class);
	}
	public static void main(String[] args) {
		
		SpringApplication.run(SilverchainApplication.class, args);
		InitializeTask initializeTask =ApplicationContextProvider.getBean("initTask", InitializeTask.class);
		initializeTask.start();
		DownChain downChain =ApplicationContextProvider.getBean("downChain", DownChain.class);
//		downChain.start();
	}

}
