package com.value.silverchain.service.exception;


import com.value.silverchain.common.Constants;

public class MyException extends Exception {
    private Constants.Return error;
    private String errorMsg;

    public MyException(Constants.Return error) {
        this.error = error;
    }

    public MyException(Constants.Return error,String errorMsg) {
        this.error=error;
        this.errorMsg=errorMsg;
    }

    public Constants.Return getError() {
        return error;
    }

    public String getErrorMsg() {
        return errorMsg;
    }
}
