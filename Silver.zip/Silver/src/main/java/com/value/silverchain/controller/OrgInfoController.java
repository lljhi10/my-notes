package com.value.silverchain.controller;

import com.value.silverchain.bo.PageBo;
import com.value.silverchain.common.Constants;
import com.value.silverchain.dto.ChainCompanyInfo;
import com.value.silverchain.dto.CompanyInfoDto;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.*;
import com.value.silverchain.service.IBaseRoleService;
import com.value.silverchain.service.IChainService;
import com.value.silverchain.service.IOrgInfoService;
import com.value.silverchain.service.IPeerSettingInfoService;
import com.value.silverchain.service.IUserAccountService;
import com.value.silverchain.service.exception.MyException;
import com.value.silverchain.util.MD5;
import com.value.silverchain.vo.LoginManager;
import com.value.silverchain.vo.Result;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: ${date}
 * DESC:商户入网管理
 */
@Controller
@RequestMapping("/orginfo/v1")
public class OrgInfoController {

    final static Logger logger = LoggerFactory.getLogger(OrgInfoController.class);

    @Autowired
    private IOrgInfoService orgInfoService;

    @Autowired
    private IUserAccountService userAccountService;

    @Autowired
    private IBaseRoleService baseRoleService;
    @Autowired
    private IPeerSettingInfoService peerSettingInfoService;

    @Autowired
    private IChainService chainService;

    /**
     * 添加商户账号
     * @param company
     * @return
     */
    @RequestMapping("/create")
    @ResponseBody
    public String addCompanyInfo(@RequestBody CompanyInfo company, HttpSession session){
        Result result = new Result();
        String pkCompanyInfo=null;
        String pkRole=null;
        String pkManagerInfo=null;
        boolean isException=false;
        //获取当前登录用户
        LoginManager loginManager =(LoginManager) session.getAttribute("loginManager");
        try {
            Properties prop = new Properties();
            PeerSettingInfo peerSettingInfo =null;
            InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("init.properties");
            prop.load(new InputStreamReader(is,"UTF-8")); /// 加载属性列表
            if (company != null) {
                logger.info("--------------------新建商户-------------------------------------");
                //数据校验
                result=checkNull(company);
                if (!result.verify()){
                    isException=true;
                    return result.toJson();
                }else {
                    //参数合理性验证
                    if(StringUtils.isNotBlank(company.getEmail()) && !company.getEmail().matches(Constants.REGULAR_EMAIL)){
                        logger.info("--------------------修改商户信息错误:邮箱地址不合法！-------------------------------------");
                        result.setState(Constants.Return.EMAIL_ERR);
                        return result.toJson();
                    }
                    //参数唯一性验证
                    CompanyInfo checkResult = orgInfoService.uniqueCheck(company);
                    if(checkResult.getCompanyName() != null) {
                        logger.info("--------------------新建商户错误:商户名称重复!-------------------------------------");
                        result.setState(Constants.Return.COMPANYNAME_EXISTS);
                        return result.toJson();
                    }
                    if(checkResult.getCompanyLicense() != null) {
                        logger.info("--------------------新建商户错误:商户营业执照号码重复!-------------------------------------");
                        result.setState(Constants.Return.COMPANYLICENSE_EXISTS);
                        return result.toJson();
                    }
                    if(checkResult.getCompanyNo() != null) {
                        logger.info("--------------------新建商户错误:商户号重复!-------------------------------------");
                        result.setState(Constants.Return.COMPANYNO_EXISTS);
                        return result.toJson();
                    }
                    if(checkResult.getChainAddr() != null) {
                        logger.info("--------------------新建商户错误:区域链地址重复!-------------------------------------");
                        result.setState(Constants.Return.CHAINADDR_EXISTS);
                        return result.toJson();
                    }
                    //业务检查
                    if(!loginManager.isUp()){
                        logger.info("--------------------新建商户错误:当前管理员不属于UP!-------------------------------------");
                        result.setState(Constants.Return.UNSUCCESS);
                        return result.toJson();
                    }
                    //添加之前需要判断是否存在本地节点,存在才能添加

                    if(company.getJoinType().equals(CompanyInfo.JoinType.PAUSE)){
                        List<PeerSettingInfo> lis = peerSettingInfoService.findByPeerType(PeerSettingInfo.PeerType.LOCAL);
                        if(lis == null || lis.size() <= 0) {
                            logger.info("--------------------新建商户错误:本地节点不存在!-------------------------------------");
                            result.setState(Constants.Return.LOCAL_PREE_NOT_EXISTS);
                            return result.toJson();
                        }else if(lis.size()>1){
                            logger.info("--------------------新建商户错误:存在多个本地节点!-------------------------------------");
                            result.setState(Constants.Return.MULTI_LOCAL_PREE_EXISTS);
                            return result.toJson();
                        }
                        peerSettingInfo=lis.get(0);
                        company.setPkPeerSettingInfo(peerSettingInfo.getPkPeerSettingInfo());
                    }
                    ManagerInfo manger=loginManager.getLoginUser();
                    //自动匹配数据
                    company.setPkCompanyInfo(UUID.randomUUID().toString());
                    company.setCreateDate(new Date());
                    company.setCreateManager(manger.getPkManagerInfo());
                    company.setCompanyType(CompanyInfo.CompanyType.OTHER);
                    company.setJoinType(CompanyInfo.JoinType.PAUSE);

                    //添加
                    String id = orgInfoService.save(company);
                    if(StringUtils.isBlank(id)){
                        isException=true;
                        throw  new MyException(Constants.Return.INIT_COMPANY_ERROR);
                    }
                    pkCompanyInfo=company.getPkCompanyInfo();
                }

                logger.info("--------------------新建商户:创建默认角色-------------------------------------");
                //如果没有创建，初始化
                BaseRole baseRole=new BaseRole();
                baseRole.setPkRole(UUID.randomUUID().toString());
                baseRole.setRoleName(prop.getProperty("other.role.roleName"));
                baseRole.setPkCompany(company.getPkCompanyInfo());
                baseRole.setStatus(BaseRole.Status.VALID);

                List<MenuSource> menuList = new ArrayList<>();//菜单权限列表

                MenuSource menuSource=new MenuSource();
                menuSource.setMenuName(prop.getProperty("other.role.menuName.company"));
                List<BaseRight> baseRightList = new ArrayList<>();
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.company.view.name"))));

                menuSource.setRightList(baseRightList);
                menuList.add(menuSource);

                menuSource=new MenuSource();
                menuSource.setMenuName(prop.getProperty("other.role.menuName.account"));
                baseRightList = new ArrayList<>();
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.account.view.name"))));
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.account.edit.name"))));

                menuSource.setRightList(baseRightList);
                menuList.add(menuSource);

                menuSource=new MenuSource();
                menuSource.setMenuName(prop.getProperty("other.role.menuName.peer"));
                baseRightList = new ArrayList<>();
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.peer.view.name"))));
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.peer.edit.name"))));

                menuSource.setRightList(baseRightList);
                menuList.add(menuSource);

                menuSource=new MenuSource();
                menuSource.setMenuName(prop.getProperty("other.role.menuName.publishService"));
                baseRightList = new ArrayList<>();
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.publishService.view.name"))));
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.publishService.edit.name"))));
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.publishService.publish.name"))));


                menuSource.setRightList(baseRightList);
                menuList.add(menuSource);

                menuSource=new MenuSource();
                menuSource.setMenuName(prop.getProperty("other.role.menuName.viewService"));
                baseRightList = new ArrayList<>();
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.viewService.view.name"))));

                menuSource.setRightList(baseRightList);
                menuList.add(menuSource);

                menuSource=new MenuSource();
                menuSource.setMenuName(prop.getProperty("other.role.menuName.publishSmart"));
                baseRightList = new ArrayList<>();
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.publishSmart.view.name"))));
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.publishSmart.edit.name"))));
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.publishSmart.publish.name"))));

                menuSource.setRightList(baseRightList);
                menuList.add(menuSource);

                menuSource=new MenuSource();
                menuSource.setMenuName(prop.getProperty("other.role.menuName.aproverSmart"));
                baseRightList = new ArrayList<>();
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.aproverSmart.view.name"))));
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.aproverSmart.approver.name"))));

                menuSource.setRightList(baseRightList);
                menuList.add(menuSource);

                menuSource=new MenuSource();
                menuSource.setMenuName(prop.getProperty("other.role.menuName.dealTotal"));
                baseRightList = new ArrayList<>();
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.dealTotal.view.name"))));

                menuSource.setRightList(baseRightList);
                menuList.add(menuSource);

                menuSource=new MenuSource();
                menuSource.setMenuName(prop.getProperty("other.role.menuName.role"));
                baseRightList = new ArrayList<>();
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.role.view.name"))));
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.role.edit.name"))));

                menuSource.setRightList(baseRightList);
                menuList.add(menuSource);

                menuSource=new MenuSource();
                menuSource.setMenuName(prop.getProperty("other.role.menuName.manager"));
                baseRightList = new ArrayList<>();
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.manager.view.name"))));
                baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("other.role.menuName.manager.edit.name"))));

                menuSource.setRightList(baseRightList);
                menuList.add(menuSource);

                baseRole.setMenuList(menuList);
                baseRole.setCreateDate(new Date());
                String id2 =baseRoleService.save(baseRole);
                if(StringUtils.isBlank(id2)){
                    isException=true;
                    throw  new MyException(Constants.Return.INIT_ROLE_ERROR);
                }

                pkRole=baseRole.getPkRole();
                logger.info("--------------------新建商户:创建默认管理员-------------------------------------");
                //如果没有创建,初始化
                ManagerInfo managerInfo=new ManagerInfo();
                managerInfo.setPkManagerInfo(UUID.randomUUID().toString());
                managerInfo.setCompanyName(prop.getProperty("other.companyName"));
                managerInfo.setManagerName(prop.getProperty("other.manager.managerName"));
                managerInfo.setManagerNumber(prop.getProperty("other.manager.managerNumber"));
                managerInfo.setPassword(MD5.strMD5(company.getCompanyName()+prop.getProperty("other.manager.password")));
                managerInfo.setStatus(ManagerInfo.Status.VALID);
                managerInfo.setDefaultKey(ManagerInfo.DefaultKey.YES);
                managerInfo.setPkCompanyInfo(pkCompanyInfo);
                List<String> pkRoles = new ArrayList<>();
                pkRoles.add(baseRole.getPkRole());
                managerInfo.setPkRoles(pkRoles);
                managerInfo.setCreateDate(new Date());
                String id3 =userAccountService.save(managerInfo);
                pkManagerInfo=managerInfo.getPkManagerInfo();
                if(StringUtils.isBlank(id3)){
                    isException=true;
                    throw  new MyException(Constants.Return.INIT_MANAGER_ERROR);
                }
                //更新节点所属商户
                peerSettingInfoService.updateCompany(peerSettingInfo,pkCompanyInfo);
                //调用链接口,上链
//                chainService.invokeCompanyInfo();

            }else{
                result.setState(Constants.Return.UNSUCCESS);
            }

        } catch (IOException e) {
            isException = true;
            result.setState(Constants.Return.UNSUCCESS);
        } catch (MyException e) {
            isException = true;
            result.setState(Constants.Return.UNSUCCESS);
            e.printStackTrace();
        } catch (Exception e) {
            isException = true;
            e.printStackTrace();
            result.setState(Constants.Return.UNSUCCESS);

        } finally {
            if(isException){
                logger.info("--------------------新建商户失败-------------------------------------");
                if (pkCompanyInfo != null) {
                    orgInfoService.realDelete(pkCompanyInfo);
                    logger.info("--------------------新建商户失败:删除已经创建商户-------------------------------------");
                }
                if (pkRole != null) {
                    baseRoleService.realDelete(pkRole);
                    logger.info("--------------------新建商户失败:删除已经创建角色-------------------------------------");
                }
                if (pkManagerInfo != null) {
                    userAccountService.realDelete(pkManagerInfo);
                    logger.info("--------------------新建商户失败:删除已经创建管理员-------------------------------------");
                }
            }else{
                logger.info("--------------------新建商户成功------------------------------------");
                //上链
                try {
                    chainService.invokeCompanyInfo();
                } catch (HorizonBizException e) {
                    e.printStackTrace();
                }
            }
        }
        return result.toJson();
    }

    private Result checkNull(CompanyInfo company) {
        Result result = new Result();
//
//        if(StringUtils.isBlank(company.getCompanyName()) || StringUtils.isBlank(company.getCompanyLicense()) ||
//                StringUtils.isBlank(company.getCompanyNo()) || StringUtils.isBlank(company.getLinkMan()) ||
//                StringUtils.isBlank(company.getLinkPhone()) || StringUtils.isBlank(company.getChainAddr()))
        if (StringUtils.isBlank(company.getCompanyName()) ) {
            logger.info("--------------------参数错误:商户名称不能为空!-------------------------------------");
            result.setState(Constants.Return.COMPANY_NAME_NULL);
        } else if (StringUtils.isBlank(company.getCompanyLicense())) {
            logger.info("--------------------参数错误:商户营业执照不能为空!-------------------------------------");
            result.setState(Constants.Return.COMPANYLICENSE_NULL);
        }else if (StringUtils.isBlank(company.getCompanyNo())) {
            logger.info("--------------------参数错误:商户号不能为空!-------------------------------------");
            result.setState(Constants.Return.COMPANYNO_NULL);
        }else if (StringUtils.isBlank(company.getLinkMan())) {
            logger.info("--------------------参数错误:联系人姓名不能为空!-------------------------------------");
            result.setState(Constants.Return.LINKMAN_NULL);
        }else if (StringUtils.isBlank(company.getLinkPhone())) {
            logger.info("--------------------参数错误:联系人电话不能为空!-------------------------------------");
            result.setState(Constants.Return.LINKPHONE_NULL);
        }else if (StringUtils.isBlank(company.getChainAddr())) {
            logger.info("--------------------参数错误:区块链地址不能为空!-------------------------------------");
            result.setState(Constants.Return.CHAINADDR_NULL);
        }

            return result;
    }

    /**
     * 更新商户账号
     * @param company
     * @return
     */
    @RequestMapping("/edit")
    @ResponseBody
    public String editCompanyInfo(@RequestBody CompanyInfo company,HttpSession session){
        Result result = new Result();
        try {
            //获取当前登录用户
            LoginManager loginManager = (LoginManager) session.getAttribute("loginManager");
            //参数合理性验证
            if(StringUtils.isNotBlank(company.getEmail()) && !company.getEmail().matches(Constants.REGULAR_EMAIL)){
                logger.info("--------------------修改商户信息错误:邮箱地址不合法！-------------------------------------");
                result.setState(Constants.Return.EMAIL_ERR);
                return result.toJson();
            }
            //参数唯一性验证
            CompanyInfo checkResult = orgInfoService.uniqueCheck(company);
            if(checkResult.getCompanyName() != null) {
                logger.info("--------------------修改商户错误:商户名称重复!-------------------------------------");
                result.setState(Constants.Return.COMPANYNO_EXISTS);
                return result.toJson();
            }
            if(checkResult.getCompanyLicense() != null) {
                logger.info("--------------------修改商户错误:商户营业执照号码重复!-------------------------------------");
                result.setState(Constants.Return.COMPANYLICENSE_EXISTS);
                return result.toJson();
            }
            if(checkResult.getCompanyNo() != null) {
                logger.info("--------------------修改商户错误:商户号重复!-------------------------------------");
                result.setState(Constants.Return.COMPANYNO_EXISTS);
                return result.toJson();
            }
            if(checkResult.getChainAddr() != null) {
                logger.info("--------------------修改商户错误:区域链地址重复!-------------------------------------");
                result.setState(Constants.Return.CHAINADDR_EXISTS);
                return result.toJson();
            }
            //业务检查
            if(!loginManager.isUp()){
                logger.info("--------------------修改商户错误:当前管理员不属于UP!-------------------------------------");
                result.setState(Constants.Return.UNSUCCESS);
                return result.toJson();
            }
            //如果想从银联节点改为本地节点则要判断是否已经建好本地节点
            if(company.getJoinType().equals(CompanyInfo.JoinType.PAUSE)){
                List<PeerSettingInfo> lis = peerSettingInfoService.findByPeerType(PeerSettingInfo.PeerType.LOCAL);
                if(lis == null || lis.size() <= 0) {
                    logger.info("--------------------修改商户错误:本地节点不存在!-------------------------------------");
                    result.setState(Constants.Return.LOCAL_PREE_NOT_EXISTS);
                    return result.toJson();
                }
            }
            //自动匹配数据
            company.setUpdateDate(new Date());
            company.setUpdateManager(loginManager.getLoginUser().getPkManagerInfo());
            
            //如果是UP商户，判断UP商户的节点信息是否为空，如果为空，判断创建人是否为空，不为空表示本节点为UP节点，获取本地节点，更新UP商户的节点信息
            if(company.getCompanyType().equals(CompanyInfo.CompanyType.UP)&&company.getCreateDate()!=null&&company.getPkPeerSettingInfo()==null){
                logger.info("--------------------更新UP商户节点信息-------------------------------------");
                List<PeerSettingInfo> lis = peerSettingInfoService.findByPeerType(PeerSettingInfo.PeerType.LOCAL);
                if(lis != null && lis.size() == 1) {
                    logger.info("--------------------设置UP商户节点信息-------------------------------------");
                    company.setPkPeerSettingInfo(lis.get(0).getPkPeerSettingInfo());
                }
                
            }
            int count = orgInfoService.update(company);
            if(count > 0){
                logger.info("--------------------修改商户成功!-------------------------------------");
                result.getData().put("account", company);
                //上链
                chainService.invokeCompanyInfo();
                if(company.getCompanyType().equals(CompanyInfo.CompanyType.UP)){
                    //更新银联商户信息
                    chainService.invokeUpInfo(new ChainCompanyInfo(company));
                }
            }

        } catch (Exception e) {
            logger.info("--------------------修改商户失败!-------------------------------------");
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        }

        return result.toJson();
    }

    /**
     * 按ID商户账号
     * @param companyInfo
     * @return
     */
    @RequestMapping("/findById")
    @ResponseBody
    public String findCompanyInfoById(@RequestBody CompanyInfo companyInfo){
        Result result = new Result();
        try {
            if (StringUtils.isBlank(companyInfo.getPkCompanyInfo())) {
                result.setState(Constants.Return.PKCOMPANYINFO_NULL);
            } else {
                CompanyInfo company = orgInfoService.getCompanyInfoByID(companyInfo);
                result.getData().put("companyInfo",company);
            }

        } catch (Exception e) {
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        }

        return result.toJson();
    }

    /**
     * 按ID商户账号
     * @param companyInfo
     * @return
     */
    @RequestMapping("/findByName")
    @ResponseBody
    public String findCompanyInfoByName(@RequestBody CompanyInfo companyInfo){
        Result result = new Result();
        try {
            if (StringUtils.isBlank(companyInfo.getCompanyName())) {
                result.setState(Constants.Return.COMPANY_NAME_NULL);
            } else {
                CompanyInfo company = orgInfoService.getCompanyInfo(companyInfo);
                result.getData().put("companyInfo",company);
            }

        } catch (Exception e) {
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        }

        return result.toJson();
    }

    /**
     * 按商户账号分页查询
     * @param companyInfo
     * @return
     */
    @RequestMapping("/findByPage")
    @ResponseBody
    public String findCompanyInfoByPage(@RequestBody CompanyInfo companyInfo,HttpSession session){
        Result result = new Result();
        try {
            //获取当前登录用户
            ManagerInfo manger = (ManagerInfo) session.getAttribute("loginUser");
            companyInfo.setPkCompanyInfo(manger.getPkCompanyInfo());
            PageBo<CompanyInfo> companyInfos = orgInfoService.findPage(companyInfo);
            result.getData().put("list",companyInfos);

        } catch (Exception e) {
            result.setState(Constants.Return.UNSUCCESS);
        }

        return result.toJson();
    }

    /**
     * 按商户账号分页查询
     * @param companyInfo
     * @return
     */
    @RequestMapping("/findAllByPage")
    @ResponseBody
    public String findAllByPage(@RequestBody CompanyInfo companyInfo,HttpSession session){
        Result result = new Result();
        try {
            if(companyInfo.getFindType() != null && companyInfo.getFindType().equals(CompanyInfo.FindType.ALL)) {
                companyInfo.setPkCompanyInfo(null);
            } else {
                //获取当前登录用户
                ManagerInfo manger = (ManagerInfo) session.getAttribute("loginUser");
                companyInfo.setPkCompanyInfo(manger.getPkCompanyInfo());

            }

            PageBo<CompanyInfo> companyInfos = orgInfoService.findAllPage(companyInfo);
            result.getData().put("list",companyInfos);

        } catch (Exception e) {
            result.setState(Constants.Return.UNSUCCESS);
        }

        return result.toJson();
    }

    /**
     * 按商户账号分页查询
     * @param companyInfo
     * @return
     */
    @RequestMapping("/findAllByServicePage")
    @ResponseBody
    public String findAllByServicePage(@RequestBody CompanyInfo companyInfo,HttpSession session){
        Result result = new Result();
        try {
            //获取当前登录用户
            ManagerInfo manger = (ManagerInfo) session.getAttribute("loginUser");
            companyInfo.setPkCompanyInfo(manger.getPkCompanyInfo());
            PageBo<CompanyInfo> companyInfos = orgInfoService.findAllServicePage(companyInfo);
            result.getData().put("list",companyInfos);

        } catch (Exception e) {
            result.setState(Constants.Return.UNSUCCESS);
        }

        return result.toJson();
    }
    /**
     * 查询所有商户
     * @param 
     * @return
     */
    @RequestMapping("/findAll")
    @ResponseBody
    public String findAll(HttpSession session){
        Result result = new Result();
        try {
            ManagerInfo manger = (ManagerInfo) session.getAttribute("loginUser");
            
            List<CompanyInfo> list = orgInfoService.findAll(manger.getPkCompanyInfo());
            result.getData().put("list", CompanyInfoDto.change(list));
        } catch (Exception e) {
            result.setState(Constants.Return.UNSUCCESS);
        }

        return result.toJson();
    }
    
}
