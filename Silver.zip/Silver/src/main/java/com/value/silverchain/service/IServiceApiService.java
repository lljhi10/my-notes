package com.value.silverchain.service;

import com.value.silverchain.bo.PageBo;
import com.value.silverchain.dto.ChainServiceApiInfo;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.ManagerInfo;
import com.value.silverchain.model.ServiceApiInfo;

import java.text.ParseException;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:00
 * DESC:
 */
public interface IServiceApiService {

    /**
     * 保存
     * @param serviceApiInfo
     * @return
     */
    String save(ServiceApiInfo serviceApiInfo);

    /**
     * 根据主键查询
     * @param pkServiceApiInfo
     * @return
     */
    ServiceApiInfo getByKey(String pkServiceApiInfo);

    /**
     * 分页查询
     * @param param
     * @return
     */
    PageBo<ServiceApiInfo> findPage(ServiceApiInfo param);

    /**
     * 根据主键删除
     * @param id
     */
    void delete(String id);

    /**
     * 更新
     * @param param
     * @param loginUser
     * @return
     */
    String update(ServiceApiInfo param, ManagerInfo loginUser) throws HorizonBizException, ParseException;
    

    /**
     * 检查唯一性,保证在同一商户下，同一接口类型，同一目标商户(公开看成是一种商户)，同一时间段内正常的生效的支付接口记录只有一条
     * @param serviceApiInfo
     */
    void checkUniqueness(ServiceApiInfo serviceApiInfo) throws HorizonBizException;

    /**
     * 根据条件，查询服务接口
     * @param serviceApiInfo
     */
    ServiceApiInfo getByCondition(ServiceApiInfo serviceApiInfo) throws HorizonBizException;

    int updateFromChain(ChainServiceApiInfo item);
}
