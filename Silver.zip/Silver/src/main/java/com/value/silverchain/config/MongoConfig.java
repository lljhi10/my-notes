package com.value.silverchain.config;

import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.value.silverchain.common.Constants;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Morphia;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.mongo.MongoProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;

@Configuration
@ConfigurationProperties(prefix = "spring.data.mongodb")
public class MongoConfig {
    @Value("${spring.data.mongodb.database}")
    private String dbName;
    
    @Autowired(required = false)
    private MongoClientOptions options;

    @Autowired
    private Environment environment;

    @Bean
    @ConfigurationProperties("spring.data.mongodb")
    @Primary
    public MongoProperties horizonConnProperties() {
        return new MongoProperties();
    }


    @Bean
    @Autowired
    public Datastore initDataStore(Mongo mongo) {
        final Morphia morphia = new Morphia();
        morphia.mapPackage(Constants.DEFAULT_PACKAGE);
//        Datastore datastore = morphia.createDatastore((MongoClient) mongo, Constants.DUFAULT_DB_NAME);
        Datastore datastore = morphia.createDatastore((MongoClient) mongo, dbName);
        datastore.ensureIndexes();
        return datastore;
    }

    @Bean
    @ConfigurationProperties("datasource.ann-transaction.mongodb")
    public MongoProperties hubbleConnProperties() {
        return new MongoProperties();
    }

    /*@Bean(name = "hubble")
    public Mongo hubble() throws UnknownHostException {
        //TODO Fuck!
//        return hubbleConnProperties().createMongoClient(options, environment);
        return new MongoClient("10.139.53.231", 27017);
    }*/

}
