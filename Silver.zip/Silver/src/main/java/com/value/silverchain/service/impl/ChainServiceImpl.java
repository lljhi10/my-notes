package com.value.silverchain.service.impl;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.value.silverchain.common.Constants;
import com.value.silverchain.dto.*;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.*;
import com.value.silverchain.service.*;
import com.value.silverchain.util.DateHelper;
import com.value.silverchain.util.HttpClientUtil;
import com.value.silverchain.util.JsonUtil;
import com.value.silverchain.vo.Result;
import org.apache.commons.lang3.StringUtils;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:01
 * DESC:
 */
@Service
public class ChainServiceImpl implements IChainService {

    @Value("${chain.ip}")
    private String urlHead;

    @Value("${dev.suffix}")
    private String devSuffix;


    private Logger logger = LoggerFactory.getLogger(ChainServiceImpl.class);
    @Autowired
    private Datastore datastore;

    @Autowired
    private IBusinessInfoService businessInfoService;

    @Autowired
    private IOrgInfoService orgInfoService;

    @Autowired
    private IPeerSettingInfoService peerSettingInfoService;



    @Autowired
    private IPayApiService payApiService;

    @Autowired
    private IServiceApiService serviceApiService;

    @Autowired
    private ISmartAppInfoService smartAppInfoService;
    @Autowired
    private IChainUpdateTimeService chainUpdateTimeService;
    @Autowired
    private IApiTypeService apiTypeService;
    @Autowired 
    private IPriceTypeService priceTypeService;
    
    /*商户上链
        * */
    @Override
    public void invokeCompanyInfo()  {
        String chainKey=devSuffix+Constants.CHAIN_KEY_COMPANY_INFO+Constants.CHAIN_UPDATE_INFO_SUFFIX;
        Query<CompanyInfo> query=datastore.find(CompanyInfo.class);
        List<CompanyInfo> companyInfoList=query.asList();
        List<ChainCompanyInfo> chainCompanyInfoList=new ArrayList<>();
        companyInfoList.forEach(companyInfo->chainCompanyInfoList.add(new ChainCompanyInfo(companyInfo)));
        String value = JsonUtil.writeJson(chainCompanyInfoList);
        try {
            invoke(devSuffix+Constants.CHAIN_KEY_COMPANY_INFO,value);
            String updateTime =new Date().getTime()+"";

            //更新链上的更新时间
            invoke(chainKey,updateTime);//更新时间
            //更新本地的更新时间
            chainUpdateTimeService.save(chainKey,updateTime);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    //业务账户上链
    @Override
    public void invokeAccountInfo() {
        String chainKey=devSuffix+Constants.CHAIN_KEY_ACCOUNT_INFO+Constants.CHAIN_UPDATE_INFO_SUFFIX;
        Query<AccountInfo> query=datastore.find(AccountInfo.class);
        List<AccountInfo> accountInfoList=query.asList();
        List<ChainAccountInfo> chainAccountInfoList=new ArrayList<>();
        accountInfoList.forEach(accountInfo->chainAccountInfoList.add(new ChainAccountInfo(accountInfo)));
        String value = JsonUtil.writeJson(chainAccountInfoList);
        try {
            invoke(devSuffix+Constants.CHAIN_KEY_ACCOUNT_INFO,value);
            String updateTime =new Date().getTime()+"";

            //更新链上的更新时间
            invoke(chainKey,updateTime);//更新时间
            //更新本地的更新时间
            chainUpdateTimeService.save(chainKey,updateTime);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    //节点上链
    @Override
    public void invokePeer()  {
        String chainKey=devSuffix+Constants.CHAIN_KEY_PEERSETTING_INFO+Constants.CHAIN_UPDATE_INFO_SUFFIX;
        Query<PeerSettingInfo> query=datastore.find(PeerSettingInfo.class);
        List<PeerSettingInfo> peerSettingInfoList=query.asList();
        List<ChainPeerSettingInfo> chainPeerSettingInfoList=new ArrayList<>();
        peerSettingInfoList.forEach(peer->chainPeerSettingInfoList.add(new ChainPeerSettingInfo(peer)));
        String value = JsonUtil.writeJson(chainPeerSettingInfoList);
        try {
            invoke(devSuffix+Constants.CHAIN_KEY_PEERSETTING_INFO,value);
            String updateTime =new Date().getTime()+"";
            //更新链上的更新时间
            invoke(chainKey,updateTime);//更新时间
            //更新本地的更新时间
            chainUpdateTimeService.save(chainKey,updateTime);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    /**
     * 服务接口类型上链
     * @throws HorizonBizException
     */
    @Override
    public void invokeApiTypeInfo() throws HorizonBizException {
        String chainKey=devSuffix+Constants.CHAIN_KEY_API_TYPE_INFO+"_"+Constants.CHAIN_UPDATE_INFO_SUFFIX;
        Query<ApiTypeInfo> query=datastore.find(ApiTypeInfo.class);
        List<ApiTypeInfo> apiTypeInfoList=query.asList();
        List<ChainApiTypeInfo> chainApiTypeInfoList=new ArrayList<>();
        apiTypeInfoList.forEach(apiTypeInfo->chainApiTypeInfoList.add(new ChainApiTypeInfo(apiTypeInfo)));
        String value = JsonUtil.writeJson(chainApiTypeInfoList);
        try {
            invoke(devSuffix+Constants.CHAIN_KEY_API_TYPE_INFO,value);
            String updateTime =new Date().getTime()+"";

            //更新链上的更新时间
            invoke(chainKey,updateTime);//更新时间
            //更新本地的更新时间
            chainUpdateTimeService.save(chainKey,updateTime);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * 价格类型上链
     * @throws HorizonBizException
     */
    @Override
    public void invokePriceTypeInfo() throws HorizonBizException {
        String chainKey=devSuffix+Constants.CHAIN_KEY_PRICE_TYPE_INFO+"_"+Constants.CHAIN_UPDATE_INFO_SUFFIX;
        Query<ApiTypeInfo> query=datastore.find(ApiTypeInfo.class);
        List<ApiTypeInfo> apiTypeInfoList=query.asList();
        List<ChainApiTypeInfo> chainApiTypeInfoList=new ArrayList<>();
        apiTypeInfoList.forEach(apiTypeInfo->chainApiTypeInfoList.add(new ChainApiTypeInfo(apiTypeInfo)));
        String value = JsonUtil.writeJson(chainApiTypeInfoList);
        try {
            invoke(devSuffix+Constants.CHAIN_KEY_PRICE_TYPE_INFO,value);
            String updateTime =new Date().getTime()+"";

            //更新链上的更新时间
            invoke(chainKey,updateTime);//更新时间
            //更新本地的更新时间
            chainUpdateTimeService.save(chainKey,updateTime);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //支付服务上链
    @Override
    public void invokePayApiInfo()   {
        String chainKey=devSuffix+Constants.CHAIN_KEY_PAYAPI_INFO+Constants.CHAIN_UPDATE_INFO_SUFFIX;
        Query<PayApiInfo> query=datastore.find(PayApiInfo.class);
        List<PayApiInfo> payApiInfoList=query.asList();
        List<ChainPayApiInfo> chainPayApiInfoList=new ArrayList<>();
        payApiInfoList.forEach(payApiInfo->chainPayApiInfoList.add(new ChainPayApiInfo(payApiInfo)));
        String value = JsonUtil.writeJson(chainPayApiInfoList);
        try {
            invoke(devSuffix+Constants.CHAIN_KEY_PAYAPI_INFO,value);
            String updateTime =new Date().getTime()+"";

            //更新链上的更新时间
            invoke(chainKey,updateTime);//更新时间
            //更新本地的更新时间
            chainUpdateTimeService.save(chainKey,updateTime);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

//发布服务上链
    @Override
    public void invokeServiceApiInfo()   {
        String chainKey=devSuffix+Constants.CHAIN_KEY_SERVICEAPI_INFO+Constants.CHAIN_UPDATE_INFO_SUFFIX;
        Query<ServiceApiInfo> query=datastore.find(ServiceApiInfo.class);
        List<ServiceApiInfo> serviceApiInfoList=query.asList();
        List<ChainServiceApiInfo> chainServiceApiInfoList=new ArrayList<>();
        serviceApiInfoList.forEach(serviceApiInfo->chainServiceApiInfoList.add(new ChainServiceApiInfo(serviceApiInfo)));
        String value = JsonUtil.writeJson(chainServiceApiInfoList);
        try {
            invoke(devSuffix+Constants.CHAIN_KEY_SERVICEAPI_INFO,value);
            String updateTime =new Date().getTime()+"";

            //更新链上的更新时间
            invoke(chainKey,updateTime);//更新时间
            //更新本地的更新时间
            chainUpdateTimeService.save(chainKey,updateTime);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //智能应用上链
    @Override
    public void invokeSmartAppInfo()  {
        String chainKey=devSuffix+Constants.CHAIN_KEY_SMARTAPI_INFO+Constants.CHAIN_UPDATE_INFO_SUFFIX;
        Query<SmartAppInfo> query=datastore.find(SmartAppInfo.class);
        List<SmartAppInfo> smartAppInfoList=query.asList();
        List<ChainSmartAppInfo> chainSmartAppInfoList=new ArrayList<>();
        smartAppInfoList.forEach(smartAppInfo->chainSmartAppInfoList.add(new ChainSmartAppInfo(smartAppInfo)));
        String value = JsonUtil.writeJson(chainSmartAppInfoList);

        try {
            invoke(devSuffix+Constants.CHAIN_KEY_SMARTAPI_INFO,value);
            String updateTime =new Date().getTime()+"";

            //更新链上的更新时间
            invoke(chainKey,updateTime);//更新时间
            //更新本地的更新时间
            chainUpdateTimeService.save(chainKey,updateTime);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 日志上链
     * @param key
     * @param logStr
     */
    @Override
    public void invokeLog(String key, String logStr) {
        key=devSuffix+key;
        try {
            
            invoke(key,"[系统时间："+ DateHelper.getDateTime_II(new Date())+"] "+logStr);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*获取版本号和codeName
    * */
    private ChainCodeInfo getCodeInfo() {
        String resultMsg = null;
        try {
            resultMsg = HttpClientUtil.doGet(urlHead+"/chain/v1/codeinfo");
        } catch (HorizonBizException e) {
            e.printStackTrace();
        }
        if (StringUtils.isBlank(resultMsg)) {
            return  null;
        }
        JSONObject jsonObject = JSON.parseObject(resultMsg);
        ChainCodeInfo chainCodeInfo=JsonUtil.jsonToObject(jsonObject.getString("data"),ChainCodeInfo.class);
        return chainCodeInfo;
    }
        /*上链访问接口*/
    private String invoke(String key, String value) throws HorizonBizException{
        //取version
        ChainCodeInfo chainCodeInfo=getCodeInfo();
        if (chainCodeInfo == null) {
            return null;
        }
        Map<String, Object> map = new HashMap<>();
        map.put("channelName", "unionchannel");
        map.put("codeName", chainCodeInfo.getCodeName());
        map.put("codeVersion", chainCodeInfo.getCodeVersion());
        map.put("fcn", "set");
        map.put("args", new String[]{key,value});
        String json =JsonUtil.writeJson(map);
//        logger.info(json);
//        String resultMsg = HttpClientUtil.doPostJson("http://236.valuecom.io:6010/chain/v1/chaincode/invoke", JsonUtil.writeJson(map));
        String resultMsg;
                try {
                    resultMsg=excuteInvoke(map);

                }catch (Exception e){
                    try {
                        resultMsg=excuteInvoke(map);
                    }catch (Exception e2){
                        resultMsg=excuteInvoke(map);
                    }

                }

        return resultMsg;
    }

    
    /**
     *
     * @return
     * @param map
     */
    private String excuteInvoke(Map<String, Object> map) throws HorizonBizException {
        String resultMsg = HttpClientUtil.doPostJson(urlHead+"/chain/v1/chaincode/invoke", JsonUtil.writeJson(map));
        JSONObject jsonObject = JSON.parseObject(resultMsg);
        if(!jsonObject.getString("res_code").equals(Constants.Return.SUCCESS.getCode())){
            //不成功
            logger.info(jsonObject.getString("res_code")+"  "+jsonObject.getString("res_msg"));
            throw new HorizonBizException(Constants.Return.UNSUCCESS);
        }
        return  resultMsg;
    }


    /*业务账户下链
    * */
    @Override
    public void queryAccountInfo()  {
        String chainKey=devSuffix+Constants.CHAIN_KEY_ACCOUNT_INFO+Constants.CHAIN_UPDATE_INFO_SUFFIX;
        String updateTimeInfo = null;
        try {
            updateTimeInfo = query(chainKey);
            boolean update;
            if(StringUtils.isBlank(updateTimeInfo)){
                //链上没数据则不进行下链
                update=false;
            }else {
                //链上有数据则比较updateTime,ture是改变了,false是链上与本地数据相等
                update=chainUpdateTimeService.compare(chainKey,updateTimeInfo);
            }
            if(update){
                //进行下链
                String info=query(devSuffix+Constants.CHAIN_KEY_ACCOUNT_INFO);
                if (info==null){
                    return;
                }else {
//                String jsonObjectQuery = JSON.parseObject(info).getJSONObject("data").getString("query");
                    List<ChainAccountInfo> list = JSONArray.parseArray(info).toJavaList(ChainAccountInfo.class);
                    list.forEach(item -> {

                        businessInfoService.updateFromChain(item);
                    });
                }
                //更新本地更新时间
                chainUpdateTimeService.save(chainKey,updateTimeInfo);
            }
            logger.info("---------------------------业务账户下链成功-------------------");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }



    /*商户下链
     * */
    @Override
    public void queryCompanyInfo()  {
        String chainKey=devSuffix+Constants.CHAIN_KEY_COMPANY_INFO+Constants.CHAIN_UPDATE_INFO_SUFFIX;
        String updateTimeInfo = null;
        try {
            updateTimeInfo = query(chainKey);
            boolean update;
            if(StringUtils.isBlank(updateTimeInfo)){
                //链上没数据则不进行下链
                update=false;
            }else {
                //链上有数据则比较updateTime,ture是改变了,false是链上与本地数据相等
                update=chainUpdateTimeService.compare(chainKey,updateTimeInfo);
            }
            if(update){
                //进行下链
                String info=query(devSuffix+Constants.CHAIN_KEY_COMPANY_INFO);
                if (info==null){
                    return;
                }else {
                    List<ChainCompanyInfo> list = JSONArray.parseArray(info).toJavaList(ChainCompanyInfo.class);
                    list.forEach(item -> {

                        orgInfoService.updateFromChain(item);
                    });
                }
                //更新本地更新时间
                chainUpdateTimeService.save(chainKey,updateTimeInfo);
            }
            logger.info("---------------------------商户信息下链成功-------------------");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /*节点下链
     * */
    @Override
    public void queryPeerSettingInfo()  {

        String chainKey=devSuffix+Constants.CHAIN_KEY_PEERSETTING_INFO+Constants.CHAIN_UPDATE_INFO_SUFFIX;
        String updateTimeInfo = null;
        try {
            updateTimeInfo = query(chainKey);
            boolean update;
            if(StringUtils.isBlank(updateTimeInfo)){
                //链上没数据则不进行下链
                update=false;
            }else {
                //链上有数据则比较updateTime,ture是改变了,false是链上与本地数据相等
                update=chainUpdateTimeService.compare(chainKey,updateTimeInfo);
            }
            if(update){//进行下链
                //
                String info=query(devSuffix+Constants.CHAIN_KEY_PEERSETTING_INFO);
                if (info==null){
                    return;
                }else {
//                String jsonObjectQuery = JSON.parseObject(info).getJSONObject("data").getString("query");
                    List<ChainPeerSettingInfo> list = JSONArray.parseArray(info).toJavaList(ChainPeerSettingInfo.class);
                    list.forEach(item -> {

                        peerSettingInfoService.updateFromChain(item);
                    });
                }
                //更新本地更新时间
                chainUpdateTimeService.save(chainKey,updateTimeInfo);
            }
            logger.info("---------------------------节点信息下链成功-------------------");
        } catch (Exception e) {
            e.printStackTrace();
        }


    }
    /*服务接口类型下链*/
    @Override
    public void queryApiTypeInfo() throws HorizonBizException {
        String chainKey=devSuffix+Constants.CHAIN_KEY_API_TYPE_INFO+"_"+Constants.CHAIN_UPDATE_INFO_SUFFIX;
        String updateTimeInfo = null;
        try {
            updateTimeInfo = query(chainKey);
            boolean update;
            if(StringUtils.isBlank(updateTimeInfo)){
                //链上没数据则不进行下链
                update=false;
            }else {
                //链上有数据则比较updateTime,ture是改变了,false是链上与本地数据相等
                update=chainUpdateTimeService.compare(chainKey,updateTimeInfo);
            }
            if(update){//进行下链
                //
                String info=query(devSuffix+Constants.CHAIN_KEY_API_TYPE_INFO);
                if (info==null){
                    return;
                }else {
                    List<ChainApiTypeInfo> list = JSONArray.parseArray(info).toJavaList(ChainApiTypeInfo.class);
                    list.forEach(item -> {

                        apiTypeService.updateFromChain(item);
                    });
                }
                //更新本地更新时间
                chainUpdateTimeService.save(chainKey,updateTimeInfo);
            }
            logger.info("---------------------------服务接口类型下链成功-------------------");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*价格类型下链*/
    @Override
    public void queryPriceTypeInfo() throws HorizonBizException {
        String chainKey=devSuffix+Constants.CHAIN_KEY_PRICE_TYPE_INFO+"_"+Constants.CHAIN_UPDATE_INFO_SUFFIX;
        String updateTimeInfo = null;
        try {
            updateTimeInfo = query(chainKey);
            boolean update;
            if(StringUtils.isBlank(updateTimeInfo)){
                //链上没数据则不进行下链
                update=false;
            }else {
                //链上有数据则比较updateTime,ture是改变了,false是链上与本地数据相等
                update=chainUpdateTimeService.compare(chainKey,updateTimeInfo);
            }
            if(update){//进行下链
                //
                String info=query(devSuffix+Constants.CHAIN_KEY_PRICE_TYPE_INFO);
                if (info==null){
                    return;
                }else {
                    List<ChainPriceTypeInfo> list = JSONArray.parseArray(info).toJavaList(ChainPriceTypeInfo.class);
                    list.forEach(item -> {

                        priceTypeService.updateFromChain(item);
                    });
                }
                //更新本地更新时间
                chainUpdateTimeService.save(chainKey,updateTimeInfo);
            }
            logger.info("---------------------------价格类型下链成功-------------------");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*支付服务下链
     * */
    @Override
    public void queryPayApiInfo()  throws HorizonBizException{
        String chainKey=devSuffix+Constants.CHAIN_KEY_PAYAPI_INFO+Constants.CHAIN_UPDATE_INFO_SUFFIX;
        String updateTimeInfo = null;
        try {
            updateTimeInfo = query(chainKey);
            boolean update;
            if(StringUtils.isBlank(updateTimeInfo)){
                //链上没数据则不进行下链
                update=false;
            }else {
                //链上有数据则比较updateTime,ture是改变了,false是链上与本地数据相等
                update=chainUpdateTimeService.compare(chainKey,updateTimeInfo);
            }
            if(update){//进行下链
                //
                String info=query(devSuffix+Constants.CHAIN_KEY_PAYAPI_INFO);
                if (info==null){
                    return;
                }else {
                    List<ChainPayApiInfo> list = JSONArray.parseArray(info).toJavaList(ChainPayApiInfo.class);
                    list.forEach(item -> {

                        payApiService.updateFromChain(item);
                    });
                }
                //更新本地更新时间
                chainUpdateTimeService.save(chainKey,updateTimeInfo);
            }
            logger.info("---------------------------支付服务接口下链成功-------------------");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /*智能应用下链*/
    @Override
    public void querySmartAppInfo() throws HorizonBizException {
        String chainKey=devSuffix+Constants.CHAIN_KEY_SMARTAPI_INFO+Constants.CHAIN_UPDATE_INFO_SUFFIX;
        String updateTimeInfo = null;
        try {
            updateTimeInfo = query(chainKey);
            boolean update;
            if(StringUtils.isBlank(updateTimeInfo)){
                //链上没数据则不进行下链
                update=false;
            }else {
                //链上有数据则比较updateTime,ture是改变了,false是链上与本地数据相等
                update=chainUpdateTimeService.compare(chainKey,updateTimeInfo);
            }
            if(update){//进行下链
                //
                String info=query(devSuffix+Constants.CHAIN_KEY_SMARTAPI_INFO);
                if (info==null){
                    return;
                }else {
                    List<ChainSmartAppInfo> list = JSONArray.parseArray(info).toJavaList(ChainSmartAppInfo.class);
                    list.forEach(item -> {

                        smartAppInfoService.updateFromChain(item);
                    });
                }
                //更新本地更新时间
                chainUpdateTimeService.save(chainKey,updateTimeInfo);
            }
            logger.info("---------------------------智能应用下链成功-------------------");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*发布服务下链
     * */
    @Override
    public void queryServiceApiInfo() {
        String chainKey=devSuffix+Constants.CHAIN_KEY_SERVICEAPI_INFO+Constants.CHAIN_UPDATE_INFO_SUFFIX;
        String updateTimeInfo = null;
        try {
            updateTimeInfo = query(chainKey);
            boolean update;
            if(StringUtils.isBlank(updateTimeInfo)){
                //链上没数据则不进行下链
                update=false;
            }else {
                //链上有数据则比较updateTime,ture是改变了,false是链上与本地数据相等
                update=chainUpdateTimeService.compare(chainKey,updateTimeInfo);
            }
            if(update){//进行下链
                //
                String info=query(devSuffix+Constants.CHAIN_KEY_SERVICEAPI_INFO);
                if (info==null){
                    return;
                }else {
                    List<ChainServiceApiInfo> list = JSONArray.parseArray(info).toJavaList(ChainServiceApiInfo.class);
                    list.forEach(item -> {

                        serviceApiService.updateFromChain(item);
                    });
                }
                //更新本地更新时间
                chainUpdateTimeService.save(chainKey,updateTimeInfo);
            }
            logger.info("---------------------------服务接口下链成功-------------------");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }






    /*下链调用查询接口*/
    public String query(String key) throws HorizonBizException{
        //取version
        ChainCodeInfo chainCodeInfo=getCodeInfo();
        if (chainCodeInfo == null) {
            return null;
        }
        Map<String, Object> map = new HashMap<>();
        map.put("channelName", "unionchannel");
        map.put("codeName", chainCodeInfo.getCodeName());
        map.put("codeVersion", chainCodeInfo.getCodeVersion());
        map.put("fcn", "get");
        map.put("args", new String[]{key});
        String json =JsonUtil.writeJson(map);
//        logger.info(json);
//        String resultMsg = HttpClientUtil.doPostJson("http://236.valuecom.io:6010/chain/v1/chaincode/invoke", JsonUtil.writeJson(map));
        String resultMsg = HttpClientUtil.doPostJson(urlHead+"/chain/v1/chaincode/query", JsonUtil.writeJson(map));
        if (resultMsg==null){
            return null;
        }
        JSONObject jsonObject = JSON.parseObject(resultMsg);
        if(!jsonObject.getString("res_code").equals(Constants.Return.SUCCESS.getCode())){
            //不成功
            logger.info(jsonObject.getString("res_code")+"  "+jsonObject.getString("res_msg"));
            throw new HorizonBizException(Constants.Return.UNSUCCESS);
        }

        return JSON.parseObject(resultMsg).getJSONObject("data").getString("query");
    }


    /**
     * 取银链上UP商户信息
     * @return
     */
    @Override
    public Result queryUPInfo() {
        Result result = new Result();
        ChainCompanyInfo chainCompanyInfo = null;
        String upInfoJson=null;
        try {
            //从链上取UP信息
            upInfoJson = query(devSuffix+Constants.CHAIN_KEY_UP_COMPANY_INFO);
            if(StringUtils.isNotBlank(upInfoJson)){
                //取到，转成对象
                chainCompanyInfo=JsonUtil.jsonToObject(upInfoJson,ChainCompanyInfo.class);
                if(StringUtils.isNotBlank(chainCompanyInfo.getPkCompanyInfo())){
                    //解释出有值才传
                    result.getData().put("upInfo",chainCompanyInfo);
                }
            }
            return result;
        } catch (HorizonBizException e) {
            e.printStackTrace();
            result.setState(e.getError());
            return result;
        }catch (Exception e){
            e.printStackTrace();
            result.setState(Constants.Return.QUEYR_EXCEPTION);
            return result;
        }
    }
    /**
     * UP商户信息上链
     * @param chainCompanyInfo
     */
    @Override
    public void invokeUpInfo(ChainCompanyInfo chainCompanyInfo) throws HorizonBizException {
        String value = JsonUtil.writeJson(chainCompanyInfo);

        invoke(devSuffix+Constants.CHAIN_KEY_UP_COMPANY_INFO,value);

    }

    @Override
    public List<String> queryLog(String aid, String orderId) throws HorizonBizException {
        List<String> logList = new ArrayList<>();
        String log = "";
            for (int i = 1; log!=null; i++) {
                log=query(devSuffix + aid + "_" + orderId +"_"+ i);
                if (log != null) {
                    logList.add(log);
                }
            }
        return logList;
    }

    @Override
    public List<String> querySmartLog(String keyHead) {
        List<String> result=new ArrayList<>();

        try {
            String maxLogIndex=query(keyHead);
            if(StringUtils.isNotBlank(maxLogIndex)){
                maxLogIndex=maxLogIndex.substring(maxLogIndex.lastIndexOf("]")+1);
                int max=Integer.parseInt(maxLogIndex.trim());
                for (int i=1;i<=max;i++){
                    try {
                        String str = query(keyHead+"_"+i);
//                        if (str == null) {
//                            break;
//                        }
                        if (str != null) {
                            result.add(str);
                        }
                    } catch (HorizonBizException e) {
                        e.printStackTrace();
//                        break;
                    }
                }
            }else{
                for (int i=1;;i++){
                    try {
                        String str = query(keyHead+"_"+i);
                        if (str == null) {
                            break;
                        }
                        result.add(str);
                    } catch (HorizonBizException e) {
                        e.printStackTrace();
                        break;
                    }
                }
            }
        } catch (HorizonBizException e) {
            e.printStackTrace();
        }
        return result;
    }
}
