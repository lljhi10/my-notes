package com.value.silverchain.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.value.silverchain.dto.CompanyInfoDto;
import lombok.Data;
import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Id;
import org.mongodb.morphia.annotations.Indexed;
import org.mongodb.morphia.annotations.Transient;
import org.mongodb.morphia.utils.IndexDirection;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *  价格类型信息
 */
@Entity("price_type_info")
@Data
public class PriceTypeInfo extends BasePage{
    public enum Status {
        NORMAL("正常"), PAUSE("暂停"), TERMINATION("终止");
        private String name;

        Status(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum TargetType {
        OPEN("公开"),TARGET("指定商户");
        private String name;

        TargetType(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    @Id
    @JsonIgnore
    private ObjectId id;
    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_pkPriceTypeInfo",dropDups = true)
    private String pkPriceTypeInfo;//价格类型主键

    private String priceTypeName;//价格类型名称

    private String description;//描述
    
    private List<String> targetCompany;//目标商户：接收前台传来的数据


    private TargetType targetType;//目标类型：公开/指定商户


    private Status status;//接口状态：正常， 暂停， 终止

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createDate;//创建时间

    private String createManager;//创建人

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateDate;//最后更新时间

    private String updateManager;//最后更新人

    @Transient
    private String targetCompanyName;//目标商户名称
    @Transient
    private List<CompanyInfoDto> companyInfoList;//目标商户列表
    

    public Map getStatusObject() {
        Map map = new HashMap();
        if(status != null) {
            map.put("name", this.status.getName());
            map.put("value", this.status);
        }
        return map;
    }


    public Map getTargetTypeObject() {
        Map map = new HashMap();
        if(this.targetType != null) {
            map.put("name", this.targetType.getName());
            map.put("value", this.targetType);
        }
        return map;
    }
}