package com.value.silverchain.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Id;
import org.mongodb.morphia.annotations.Indexed;
import org.mongodb.morphia.annotations.Transient;
import org.mongodb.morphia.utils.IndexDirection;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 *  商户业务账户
 */
@Entity("account_info")
@Data
public class AccountInfo  extends BasePage{
    public enum Status {
        NORMAL("正常"), PAUSE("暂停"), TERMINATION("终止");
        private String name;

        Status(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum SupportTradeType {
        NORMAL("收款"), PAUSE("支付");
        private String name;
        SupportTradeType(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    @Id
    @JsonIgnore
    private ObjectId id;
    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_pkAccountInfo",dropDups = true)
    private String pkAccountInfo;//业务账户主键

    private String pkCompanyInfo;//商户主键哦

    private String accountName;//业务账户名称
    
//    private String orgNo;//商户号
    
    private String accountNo;//银行账号;

    private String cardNo;//银行卡账号

    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date expiryDate;//有效期

    private String cvn;//银行卡cvn码

    private String mobilePhone;//银行卡预留手机号

    private SupportTradeType supportTradeType;//业务账户类型:收款， 支付

    private String chainAddr;//业务账户区域链地址

    private Status status;//业务账户状态：正常，暂停，终止

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createDate;//创建时间

    private String createManager;//创建人

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateDate;//最后更新时间

    private String updateManager;//最后更新人

    public void setSid(String sid) {
        this.pkAccountInfo = sid;
    }

    @Transient
    private String companyName;//商户名称

    public Map getStatusObject() {
        Map map = new HashMap();
        map.put("name",this.status.getName());
        map.put("value",this.status);
        return map;
    }

}