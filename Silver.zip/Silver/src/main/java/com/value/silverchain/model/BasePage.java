package com.value.silverchain.model;

import lombok.Data;
import org.mongodb.morphia.annotations.Transient;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/6/4
 * DESC:
 */
@Data
public class BasePage {
    /**扩展参数**/
    @Transient
    private int pageNo;//页码
    @Transient
    private int pageSize;//每页条数
}
