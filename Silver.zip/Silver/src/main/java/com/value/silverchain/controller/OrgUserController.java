package com.value.silverchain.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpSession;

import com.value.silverchain.model.BaseRole;
import com.value.silverchain.vo.LoginManager;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.value.silverchain.bo.PageBo;
import com.value.silverchain.common.Constants;
import com.value.silverchain.model.ManagerInfo;
import com.value.silverchain.service.IOrgInfoService;
import com.value.silverchain.service.IUserAccountService;
import com.value.silverchain.util.MD5;
import com.value.silverchain.vo.Result;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: ${date}
 * DESC:账号管理
 */
@Controller
@RequestMapping("/orguser/v1")
public class OrgUserController {

    private Logger logger = LoggerFactory.getLogger(OrgUserController.class);
    @Autowired
    private IUserAccountService userAccountService;

    @Autowired
    private IOrgInfoService orgInfoService;


    /**
     * 注册管理员账号
     * @param userAccount
     * @return
     */
    @RequestMapping("/register")
    @ResponseBody
    public String register(@RequestBody ManagerInfo userAccount, HttpSession session){
        Result result = new Result();
        try {
            //校验参数
            result=checkNull(userAccount);

            if(result.verify()){
                //参数合理性验证
                if(StringUtils.isNotBlank(userAccount.getEmail()) && !userAccount.getEmail().matches(Constants.REGULAR_EMAIL)){
                    logger.info("--------------------注册用户信息错误:邮箱地址不合法！-------------------------------------");
                    result.setState(Constants.Return.EMAIL_ERR);
                    return result.toJson();
                }
                //获取当前登录用户
                ManagerInfo manger = (ManagerInfo) session.getAttribute("loginUser");
                //初始化新增用户
                userAccount.setStatus(ManagerInfo.Status.VALID);
                userAccount.setDefaultKey(ManagerInfo.DefaultKey.YES);
                userAccount.setPkManagerInfo(UUID.randomUUID().toString());
                userAccount.setCreateDate(new Date());
                userAccount.setCreateManager(manger.getPkManagerInfo());
                userAccount.setPkCompanyInfo(manger.getPkCompanyInfo());
                //查询当前商户下的管理员账号
                ManagerInfo mi = userAccountService.getByUserNumber(userAccount);

                if(mi != null) {
                    //账号重复
                    result.setState(Constants.Return.ACCT_ID_REPEAT);
                    return result.toJson();
                }
                //密码的加密方式为所属商户名称加密码正文
                userAccount.setPassword(MD5.strMD5(manger.getCompanyName()+"123456"));
                String resultStr = userAccountService.save(userAccount);
                if (StringUtils.isBlank(resultStr)){
                    result.setState(Constants.Return.UNSUCCESS);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.setState(Constants.Return.UNSUCCESS);
        }
        result.getData().put("userAccount", userAccount);

        return result.toJson();
    }

    private Result checkNull(ManagerInfo userAccount) {
        Result result = new Result();
        if (StringUtils.isBlank(userAccount.getManagerNumber())){
            logger.info("--------------------参数错误:管理员账号不能为空!-------------------------------------");
            result.setState(Constants.Return.MANAGERNUMBER_NULL);
        } else if (userAccount.getPkRoles() == null) {
            logger.info("--------------------参数错误:角色主键列表不能为空!-------------------------------------");
            result.setState(Constants.Return.PKROLES_NULL);
        }else if (StringUtils.isBlank(userAccount.getManagerName())) {
            logger.info("--------------------参数错误:管理员名称不能为空!-------------------------------------");
            result.setState(Constants.Return.MANAGERNAME_NULL);
        }else if (StringUtils.isBlank(userAccount.getPhone())) {
            logger.info("--------------------参数错误:联系电话不能为空!-------------------------------------");
            result.setState(Constants.Return.PHONE_NULL);
        }else if (StringUtils.isBlank(userAccount.getEmail())) {
            logger.info("--------------------参数错误:邮箱不能为空!-------------------------------------");
            result.setState(Constants.Return.EMAIL_NULL);
        }
        return result;
    }

    /**
     * 更新管理员信息
     * @param managerInfo
     * @return
     */
    @RequestMapping("/edit")
    @ResponseBody
    public String edit(@RequestBody ManagerInfo managerInfo,HttpSession session){
        Result result = new Result();
        try {

            //参数合理性验证
            if(StringUtils.isNotBlank(managerInfo.getEmail()) && !managerInfo.getEmail().matches(Constants.REGULAR_EMAIL)){
                logger.info("--------------------注册用户信息错误:邮箱地址不合法！-------------------------------------");
                result.setState(Constants.Return.EMAIL_ERR);
                return result.toJson();
            }
            //获取当前登录用户
            LoginManager loginUser = (LoginManager)session.getAttribute("loginManager");

            //UP管理员能够查看但是只能修改自己的用户
            ManagerInfo mi = userAccountService.getByUserID(managerInfo);
            if(mi != null) {
                if(!loginUser.getLoginUser().getPkCompanyInfo().equals(mi.getPkCompanyInfo())){
                    result.setState(Constants.Return.TIGTH_LESS_THAN);
                    return result.toJson();
                }
            }
            //查询当前商户下的管理员账号
            mi = userAccountService.getByUserNumber(managerInfo);

            if(mi != null && !mi.getPkManagerInfo().equals(managerInfo.getPkManagerInfo())) {
                //账号重复
                result.setState(Constants.Return.ACCT_ID_REPEAT);
                return result.toJson();
            }
            //商户的默认管理员不能被修改       
            mi = userAccountService.getByUserID(managerInfo);
            if("admin".equals(mi.getManagerNumber())){
                result.setState(Constants.Return.TIGTH_LESS_THAN);
                return result.toJson();
            }

            managerInfo.setPassword(null);
            managerInfo.setUpdateDate(new Date());
            managerInfo.setUpdateManager(loginUser.getLoginUser().getPkManagerInfo());
            managerInfo.setCompanyName(loginUser.getLoginUser().getCompanyName());
            int updCount = userAccountService.update(managerInfo);

            if (updCount <= 0){
                result.setState(Constants.Return.UNSUCCESS);
            }
            result.getData().put("managerInfo", managerInfo);
        } catch (Exception e) {
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        }
        return result.toJson();
    }

    /**
     * 删除管理员信息：注意，这里的删除是软删除，只把用户状态一更改为无效
     * @param managerInfo
     * @return
     */
    @RequestMapping("/delete")
    @ResponseBody
    public String delete(@RequestBody ManagerInfo managerInfo,HttpSession session){
        Result result = new Result();
        try {
            LoginManager loginUser = (LoginManager)session.getAttribute("loginManager");

            //管理员只能修改自己的用户
            ManagerInfo mi = userAccountService.getByUserID(managerInfo);
            if(mi != null) {
                if(!loginUser.getLoginUser().getPkCompanyInfo().equals(mi.getPkCompanyInfo())){
                    result.setState(Constants.Return.TIGTH_LESS_THAN);
                    return result.toJson();
                }
            }else {
                result.setState(Constants.Return.MANAGER_NULL);
                return result.toJson();
            }
            
            //商户的默认管理员不能被修改       
            if("admin".equals(mi.getManagerNumber())){
                result.setState(Constants.Return.TIGTH_LESS_THAN);
                return result.toJson();
            }
            managerInfo = userAccountService.getByUserID(managerInfo);
            managerInfo.setStatus(ManagerInfo.Status.INVALID);
            String resultStr = userAccountService.delete(managerInfo);
            if (StringUtils.isBlank(resultStr)){
                result.setState(Constants.Return.UNSUCCESS);
            }
            result.getData().put("managerInfo", managerInfo);
        } catch (Exception e) {
            //throw new HorizonBizException(USEID_REPEAT);
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        }
        return result.toJson();
    }

    /**
     * 根据主键查询管理员信息
     * @param managerInfo
     * @return
     */
    @RequestMapping("/findById")
    @ResponseBody
    public String findByKey(@RequestBody ManagerInfo managerInfo){
        Result result = new Result();
        try {
            managerInfo = userAccountService.getByUserID(managerInfo);
            result.getData().put("managerInfo", managerInfo);
        } catch (Exception e) {
            result.setState(Constants.Return.QUEYR_EXCEPTION);
            
        }
        return result.toJson();
    }

    /**
     * 根据帐号查询管理员信息
     * @param managerInfo
     * @return
     */
    @RequestMapping("/findByNumber")
    @ResponseBody
    public Map findByNumber(ManagerInfo managerInfo,HttpSession session){
        Map map = new HashMap();
        boolean result = true;
        try {
            //获取当前登录用户
            ManagerInfo manger = (ManagerInfo) session.getAttribute("loginUser");
            managerInfo.setPkCompanyInfo(manger.getPkCompanyInfo());
            managerInfo = userAccountService.getByUserNumber(managerInfo);


            if(managerInfo != null) {
                result = false;
            }
        } catch (Exception e) {
            result = false;

        }
        map.put("valid", result);
        return map;
    }

    /**
     * 查询管理员信息列表
     * @param param
     * @return
     */
    @RequestMapping("/findByPage")
    @ResponseBody
    public String page(@RequestBody ManagerInfo param,HttpSession session){
        Result result = new Result();
        try {
            //获取当前登录用户
            ManagerInfo manger = (ManagerInfo) session.getAttribute("loginUser");
            param.setPkCompanyInfo(manger.getPkCompanyInfo());
            result.getData().put("list",userAccountService.findPage(param));
        } catch (Exception e) {
            e.printStackTrace();

        }
        return result.toJson();
    }



}
