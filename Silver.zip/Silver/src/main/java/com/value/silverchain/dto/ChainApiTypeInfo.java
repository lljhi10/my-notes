package com.value.silverchain.dto;

import com.value.silverchain.model.ApiTypeInfo;
import com.value.silverchain.model.BasePage;
import lombok.Data;

import java.util.List;

/**
 *  接口类型信息上链下链类
 */
@Data
public class ChainApiTypeInfo extends BasePage{
    private String pkApiTypeInfo;//服务接口类型主键

    private String apiTypeName;//服务接口类型名称

    private String description;//描述

    private List<String> targetCompany;//目标商户：接收前台传来的数据

    private ApiTypeInfo.TargetType targetType;//目标类型：公开/指定商户

    private ApiTypeInfo.Status status;//接口状态：正常， 暂停， 终止
    public ChainApiTypeInfo (ApiTypeInfo apiTypeInfo) {
        this.setPkApiTypeInfo(apiTypeInfo.getPkApiTypeInfo());
        this.setApiTypeName(apiTypeInfo.getApiTypeName());
        this.setDescription(apiTypeInfo.getDescription());
        this.setTargetCompany(apiTypeInfo.getTargetCompany());
        this.setTargetType(apiTypeInfo.getTargetType());
        this.setStatus(apiTypeInfo.getStatus());
    }

    public  ChainApiTypeInfo(){

    }
}