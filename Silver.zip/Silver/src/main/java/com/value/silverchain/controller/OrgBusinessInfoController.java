package com.value.silverchain.controller;

import com.value.silverchain.bo.PageBo;
import com.value.silverchain.common.Constants;
import com.value.silverchain.model.AccountInfo;
import com.value.silverchain.model.ManagerInfo;
import com.value.silverchain.service.IBusinessInfoService;
import com.value.silverchain.service.IChainService;
import com.value.silverchain.service.exception.MyException;
import com.value.silverchain.vo.LoginManager;
import com.value.silverchain.vo.Result;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.UUID;


/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: ${date}
 * DESC:业务账号管理
 */
@Controller
@RequestMapping("/business/v1")
public class OrgBusinessInfoController {

    final static Logger logger = LoggerFactory.getLogger(OrgBusinessInfoController.class);

    @Autowired
    private IBusinessInfoService businessInfoService;

    @Autowired
    private IChainService chainService;

    /**
     * 添加业务账号
     * @param accountInfo
     * @return
     */
    @RequestMapping("/create")
    @ResponseBody
    public String addAccountInfo(@RequestBody AccountInfo accountInfo, HttpSession session){
        Result result = new Result();
        //获取当前登录用户
        LoginManager loginManager =(LoginManager) session.getAttribute("loginManager");
        try {
            //判断参数不为空
            result = checkNull(accountInfo);
            //如果参数不为空
            if (result.verify())  {
                if (accountInfo.getSupportTradeType().equals(AccountInfo.SupportTradeType.NORMAL)) {
//                    accountInfo.setOrgNo(loginManager.getLoginUser().getPkCompanyInfo());
                    if (StringUtils.isBlank(accountInfo.getAccountNo()) ) {
                        logger.info("--------------------参数错误:银行账号为空!-------------------------------------");
                        result.setState(Constants.Return.ACCOUNTNO_NULL);
                    } else if (accountInfo.getExpiryDate() == null) {
                        logger.info("--------------------参数错误:有效期不能为空!-------------------------------------");
                        result.setState(Constants.Return.EXPIRYDATE_NULL);
                    }
                } else {
                    if (StringUtils.isBlank(accountInfo.getCardNo()) ) {
                        logger.info("--------------------参数错误:卡号不能为空!-------------------------------------");
                        result.setState(Constants.Return.CARDNO_NULL);
                    } else if (StringUtils.isBlank(accountInfo.getCvn())) {
                        logger.info("--------------------参数错误:cvn不能为空!-------------------------------------");
                        result.setState(Constants.Return.CVN_NULL);
                    }
                }
                //唯一性验证
                AccountInfo checkResult = businessInfoService.uniqueCheck(accountInfo);
                if (checkResult.getAccountName() != null) {
                    logger.info("--------------------新建业务账号错误:业务账号名称重复!-------------------------------------");
                    result.setState(Constants.Return.ACCOUNTNAME_EXISTS);
                    return result.toJson();
                }
                if (checkResult.getChainAddr() != null) {
                    logger.info("--------------------新建业务账号错误:区块链地址重复!-------------------------------------");
                    result.setState(Constants.Return.CHAINADDR_EXISTS);
                    return result.toJson();
                }
                if (checkResult.getAccountNo() != null) {
                    logger.info("--------------------新建业务账号错误:银行账号重复!-------------------------------------");
                    result.setState(Constants.Return.ACCOUNTNO_EXISTS);
                    return result.toJson();
                }
                if (checkResult.getCardNo() != null) {
                    logger.info("--------------------新建业务账号错误:银行卡号名称重复!-------------------------------------");
                    result.setState(Constants.Return.CARDNO_EXISTS);
                    return result.toJson();
                }
                //业务检查
                //up用户不能创建业务账号
                /*if(loginManager.isUp()) {
                    logger.info("--------------------新建业务账号错误:up用户不能创建业务账号!-------------------------------------");
                    result.setState(Constants.Return.TIGTH_LESS_THAN);
                    return result.toJson();
                }*/
                //有效日期不能低于系统日期
                logger.info("--------------------修改业务账号错误:" + accountInfo.getExpiryDate().getTime() + "-----------" + new Date().getTime() + "-------------------------");
                if (accountInfo.getExpiryDate().getTime() <= new Date().getTime()) {
                    logger.info("--------------------新建业务账号错误:有效日期不能小于系统当前日期!-------------------------------------");
                    result.setState(Constants.Return.EXPIRYDATE_ERR);
                    return result.toJson();
                }
                //自动匹配数据
                accountInfo.setStatus(AccountInfo.Status.NORMAL);
                accountInfo.setPkAccountInfo(UUID.randomUUID().toString());
                accountInfo.setCreateDate(new Date());
                accountInfo.setCreateManager(loginManager.getLoginUser().getPkManagerInfo());
                accountInfo.setPkCompanyInfo(loginManager.getLoginUser().getPkCompanyInfo());
                //保存....
                String id = businessInfoService.save(accountInfo);
                if (StringUtils.isBlank(id)) {
                    throw new MyException(Constants.Return.CREATE_BUSINESS_INFO_FALSE);
                }
                result.getData().put("accountInfo", accountInfo);
                //上链
                chainService.invokeAccountInfo();
            }

        } catch (MyException e) {
            e.printStackTrace();
            result.setState(e.getError());

        } catch (Exception e) {
//                e.printStackTrace();
            result.setState(Constants.Return.UNSUCCESS);
        }

        return result.toJson();
    }

    private Result checkNull(AccountInfo accountInfo) {
        Result result = new Result();

//        if(StringUtils.isBlank(accountInfo.getAccountName()) || accountInfo.getSupportTradeType() == null ||
//                StringUtils.isBlank(accountInfo.getChainAddr())) {

        if (StringUtils.isBlank(accountInfo.getAccountName())) {
            logger.info("--------------------参数错误:业务账号名称不能空!-------------------------------------");
            result.setState(Constants.Return.ACCOUNTNAME_NULL);
        } else if (accountInfo.getSupportTradeType() == null) {
            logger.info("--------------------参数错误:业务账号类型不能空!-------------------------------------");
            result.setState(Constants.Return.SUPPORTTRADETYPE_NULL);
        }else if (StringUtils.isBlank(accountInfo.getChainAddr())) {
            logger.info("--------------------参数错误:区块链地址不能为空!-------------------------------------");
            result.setState(Constants.Return.CHAINADDR_NULL);
        }
        return result;
    }

    /**
     * 更新商户账号
     * @param accountInfo
     * @return
     */
    @RequestMapping("/edit")
    @ResponseBody
    public String editAccountInfo(@RequestBody AccountInfo accountInfo,HttpSession session){
        Result result = new Result();
        try {
            //获取当前登录用户
            LoginManager loginManager = (LoginManager) session.getAttribute("loginManager");
            accountInfo.setUpdateDate(new Date());
            accountInfo.setUpdateManager(loginManager.getLoginUser().getPkManagerInfo());
            //唯一性验证
            AccountInfo checkResult = businessInfoService.uniqueCheck(accountInfo);
            if(checkResult.getAccountName() != null) {
                logger.info("--------------------修改业务账号错误:业务账号名称重复!-------------------------------------");
                result.setState(Constants.Return.ACCOUNTNAME_EXISTS);
                return result.toJson();
            }
            if(checkResult.getChainAddr() != null) {
                logger.info("--------------------修改业务账号错误:区块链地址重复!-------------------------------------");
                result.setState(Constants.Return.CHAINADDR_EXISTS);
                return result.toJson();
            }
            if(checkResult.getAccountNo() != null) {
                logger.info("--------------------修改业务账号错误:银行账号重复!-------------------------------------");
                result.setState(Constants.Return.ACCOUNTNAME_EXISTS);
                return result.toJson();
            }
            if(checkResult.getCardNo() != null) {
                logger.info("--------------------修改业务账号错误:银行卡号名称重复!-------------------------------------");
                result.setState(Constants.Return.CARDNO_EXISTS);
                return result.toJson();
            }
            //业务检查
            //up用户不能创建业务账号
            /*if(loginManager.isUp()) {
                logger.info("--------------------修改业务账号错误:up用户不能创建业务账号!-------------------------------------");
                result.setState(Constants.Return.TIGTH_LESS_THAN);
                return result.toJson();
            }*/
            //管理员只能修改本商户下面的所属信息
            AccountInfo checkIsNull = businessInfoService.getAccountInfoByID(accountInfo);
            if(checkIsNull != null){
            	if(!checkIsNull.getPkCompanyInfo().equals(loginManager.getCompanyInfo().getPkCompanyInfo())){
            		logger.info("--------------------修改业务账号错误:管理员只能修改所属商户下的信息!-------------------------------------");
                    result.setState(Constants.Return.PKCOMPANY_OUTOFRANGE);
                    return result.toJson();
            	}
            }else{
            	logger.info("--------------------修改业务账号错误:该业务账号不存在!-------------------------------------");
                result.setState(Constants.Return.ACCOUNT_NULL);
                return result.toJson();
            }
            //有效日期不能低于系统日期
            logger.info("--------------------修改业务账号错误:"+accountInfo.getExpiryDate().getTime()+"-----------"+new Date().getTime()+"-------------------------");
            if(accountInfo.getExpiryDate().getTime() <= accountInfo.getCreateDate().getTime()) {
                logger.info("--------------------修改业务账号错误:有效日期不能小于创建日期!-------------------------------------");
                result.setState(Constants.Return.EXPIRYDATE_ERR);
                return result.toJson();
            }
            int count =businessInfoService.update(accountInfo);
            if(count!=1){
                throw new MyException(Constants.Return.EDIT_BUSINESS_INFO_FALSE);
            }
            result.getData().put("accountInfo", accountInfo);
            //上链
            chainService.invokeAccountInfo();
        } catch (MyException e) {
            result.setState(e.getError());
        } catch (Exception e) {
//            e.printStackTrace();
            result.setState(Constants.Return.UPDATE_EXCEPTION);

        }
        return result.toJson();
    }

    /**
     * 按ID查找商户业务账号
     * @param accountInfo
     * @return
     */
    @RequestMapping("/findById")
    @ResponseBody
    public String findAccountInfoById(@RequestBody  AccountInfo accountInfo){
        Result result = new Result();
        try {
            if (StringUtils.isBlank(accountInfo.getPkAccountInfo())) {
                result.setState(Constants.Return.PKACCONTINFO_NULL);
            } else {
                AccountInfo account = businessInfoService.getAccountInfoByID(accountInfo);
                result.getData().put("accountInfo",account);
            }

        } catch (Exception e) {
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        }

        return result.toJson();
    }

    /**
     * 按名称查找商户业务账号
     * @param accountInfo
     * @return
     */
    @RequestMapping("/findByName")
    @ResponseBody
    public String findAccountInfoByName(@RequestBody  AccountInfo accountInfo,HttpSession session){
        Result result = new Result();
        try {
            if (StringUtils.isBlank(accountInfo.getAccountName())) {
                logger.info("--------------------参数错误:业务账户名称为空!-------------------------------------");
                result.setState(Constants.Return.ACCOUNTNAME_NULL);
            } else {
                //获取当前登录用户
                ManagerInfo manger = (ManagerInfo) session.getAttribute("loginUser");
                accountInfo.setPkCompanyInfo(manger.getPkCompanyInfo());
                AccountInfo account = businessInfoService.getAccountInfoByName(accountInfo);
                result.getData().put("accountInfo",account);
            }

        } catch (Exception e) {
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        }

        return result.toJson();
    }

    /**
     * 按商户账号分页查询
     * @param accountInfo
     * @return
     */
    @RequestMapping("/findByPage")
    @ResponseBody
    public String findAccountInfoByPage(@RequestBody AccountInfo accountInfo,HttpSession session){
        Result result = new Result();
        try {
            //获取当前登录用户
            ManagerInfo manger = (ManagerInfo) session.getAttribute("loginUser");
            accountInfo.setPkCompanyInfo(manger.getPkCompanyInfo());
            PageBo<AccountInfo> accountInfos = businessInfoService.findPage(accountInfo);
            result.getData().put("list",accountInfos);

        } catch (Exception e) {
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        }

        return result.toJson();
    }
}
