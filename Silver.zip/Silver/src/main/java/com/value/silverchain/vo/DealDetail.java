package com.value.silverchain.vo;

import lombok.Data;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/6/5
 * DESC:交易明细
 */
@Data
public class DealDetail {
    private Date dealDate;//交易时间
    
    private String payCompany;//付款方
    
    private String receiptCompany;//收款方
    
    private Float dealSum;//交易金额(元)
    
    private Float handlingCharge;//平台手续费(元)
    
    private String dealNo;//交易流水号
}
