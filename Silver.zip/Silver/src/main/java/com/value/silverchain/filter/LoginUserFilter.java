package com.value.silverchain.filter;

import com.value.silverchain.common.Constants;
import com.value.silverchain.service.IBaseRoleService;
import com.value.silverchain.service.IOrgInfoService;
import com.value.silverchain.service.IUserAccountService;
import com.value.silverchain.vo.LoginManager;
import com.value.silverchain.vo.Result;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@WebFilter(filterName="loginUserFilter",urlPatterns={"/*"})
@Order(value = 1)
@Component
public class LoginUserFilter implements Filter {
    final static Logger logger = LoggerFactory.getLogger(LoginUserFilter.class);

    @Value("${tocken}")
    private String passTocken;
    
    @Autowired
    private IOrgInfoService orgInfoService;

    @Autowired
    private IUserAccountService userAccountService;

    @Autowired
    private IBaseRoleService baseRoleService;
    /**
     * 不做登录用户检查的路径
     */
    private static final Set<String> NO_LOGIN_PATHS = Collections.unmodifiableSet(new HashSet<>(
            Arrays.asList("/login", "/logout", "/login.html")));
    /**
     * 不做登录用户检查的匹配符
     */
    private static final Set<String> NO_LOGIN_REGEX_PATH = Collections.unmodifiableSet(new HashSet<>(
                    Arrays.asList("/task/v1/", "/include/","/log/v1/","/httpclient/test","/blockChain/v1")));
    /**
     * 不做登录用户检查的文件类型
     */
    private static final Set<String> NO_LOGIN_REGEX_FILE = Collections.unmodifiableSet(new HashSet<>(
            Arrays.asList( "^\\S*\\.ico$")));
    /**
     * 需要做令牌检查的匹配符
     */
    private static final Set<String> TOKEN_REGEX_PATH = Collections.unmodifiableSet(new HashSet<>(
            Arrays.asList( "/task/v1/","/log/v1/","/httpclient/test")));

    private static Set<String> paths;
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("init-----------filter");
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;


        Result result = new Result();
        //截取最后一个/后面的字符
        String path = request.getRequestURI().substring(request.getRequestURI().lastIndexOf("/"));
        String path2 =request.getRequestURI();

        logger.info("访问路径："+path2);
        System.out.println("截取路径:"+path);

        HttpSession session = request.getSession();
        System.out.println("SessionId:"+session.getId());

        LoginManager loginManager = (LoginManager)session.getAttribute("loginManager");
        String token =  request.getHeader("token");
        System.out.println("token:"+token);
        if(checkAllowed(request.getRequestURI())){
            //不登录就能访问
//        boolean r = checkAllowed(request.getRequestURI());
//        System.out.println("path:"+path2+"  allowedPath:"+allowedPath+" r:"+r);
//        if(allowedPath){
//            boolean a =path2.startsWith("/task/v1/");
//            boolean c =path2.startsWith("/log/v1/");
//            boolean b =needToken (request.getRequestURI());
//            System.out.println("a:"+(a||c)+"  b:"+b);
            if(needToken (request.getRequestURI())){
//            if(path2.startsWith("/task/v1/")){
                //需要做令牌检查
                if(checkToken(token,request)){
                    chain.doFilter(req, res);
                }else{
                    result.setState(Constants.Return.TIGTH_LESS_THAN);
                    response.getWriter().write(result.toJson());
                }
            }else{
                //不做令牌检查
                chain.doFilter(req, res);
            }
        }else{
            if (loginManager != null &&!path.equals("/")&&checkToken(token,request)) {
                //获取权限
                paths = loginManager.getPaths();
//                System.out.println(loginManager.getPaths());
                if (paths == null||paths.size()<=0) {
                    //如果没有任何权限，表示用户不能做任何操作，直接弹出提示
                    result.setState(Constants.Return.TIGTH_LESS_THAN);
                    response.getWriter().write(result.toJson());
                }else{
                    //有权限，做权限检查
                    /*System.out.println(request.getRequestURI());
                    System.out.println(request.getRequestURI().equals("/manager/index.html"));
                    System.out.println(!paths.contains("账号管理"));*/

                    response.setHeader("Content-Type", "application/json;charset=utf-8");
                    if(!checkRight(request,paths)){
                        result.setState(Constants.Return.TIGTH_LESS_THAN);
                        response.getWriter().write(result.toJson());
                    }else{
                        chain.doFilter(req, res);
                    }
                }


            }else {
                path = request.getContextPath();
                String basePath = req.getScheme()+"://"+req.getServerName()+":"+req.getServerPort()+path;
                System.out.println(request.getRequestURI());
                //response.setHeader("Content-Type", "application/javascript;charset=utf-8");
                response.setHeader("Cache-Control", "no-store");
                response.setDateHeader("Expires", 0);
                response.setHeader("Prama", "no-cache");
                //response.sendRedirect(basePath+"/login.html");//跳转到登录页面
                response.getWriter().write("<script>location.href=\"/login.html\"</script>");
            }
        }
    }

    /**
     * 检查路径是否不需要用户登录就能访问
     * @param path
     * @return 
     */
    private boolean checkAllowed(String path) {
        String pathSub=path.substring(path.lastIndexOf("/"));
        boolean result=NO_LOGIN_PATHS.contains(pathSub);
        if(result){
            return result;
        }
        for(String regex:NO_LOGIN_REGEX_PATH){
            result = path.startsWith(regex);
            if(result){
                break;
            }
        }
        if (result){
            return result;
        }
        for(String regex:NO_LOGIN_REGEX_FILE){
            result = pathSub.matches(regex);
            if(result){
                break;
            }
        }
        return result;
    }
    /**
     * 检查路径是否需要检查令牌才可以访问
     * @param path
     * @return
     */
    private boolean needToken(String path) {
        String pathSub=path.substring(path.lastIndexOf("/"));
        boolean result=false;
        for(String regex:TOKEN_REGEX_PATH){
            result = path.startsWith(regex);
            if(result){
                break;
            }
        }
        return result;
    }
    /**
     * 检查token，匹配返回true，不匹配返回false
     * @param token
     * @return
     */
    private boolean checkToken(String token,HttpServletRequest request) {
        //html页面不做token检查
        if(request.getRequestURI().matches("^\\S*\\.html$")){
            return true;
        }
        if(StringUtils.isNotBlank(token)&&passTocken.equals(token)){
            return true;
        }else{
            return false;
        }
    }

    //判断具有权限
    private boolean checkRight(HttpServletRequest request, Set<String> paths) {
        boolean ifRight = true;
        /**
         * 备注 审核智能应用,有问题 ,待议
         */
        if(request.getRequestURI().equals("/role/index.html") && !paths.contains("角色管理")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/role/v1/findByPage") && !paths.contains("角色管理.VIEW")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/role/v1/edit") && !paths.contains("角色管理.EDIT")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/manager/index.html") && !paths.contains("账号管理")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/orguser/v1/findByPage") && !paths.contains("账号管理.VIEW")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/orguser/v1/edit") && !paths.contains("账号管理.EDIT")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/company/index.html") && !paths.contains("商户信息管理")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/orginfo/v1/findByPage") && !paths.contains("商户信息管理.VIEW")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/orginfo/v1/edit") && !paths.contains("商户信息管理.EDIT")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/account/index.html") && !paths.contains("业务账户管理")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/business/v1/findByPage") && !paths.contains("业务账户管理.VIEW")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/business/v1/edit") && !paths.contains("业务账户管理.EDIT")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/peersetting/index.html") && !paths.contains("节点信息管理")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/peersetting/v1/findByPage") && !paths.contains("节点信息管理.VIEW")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/peersetting/v1/edit") && !paths.contains("节点信息管理.EDIT")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/servicesapi/index.html") && !paths.contains("发布服务接口")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/service/v1/service/page") && !paths.contains("发布服务接口.VIEW")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/service/v1/service/edit") && !paths.contains("发布服务接口.EDIT")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/payapi/index.html") && !paths.contains("支付服务接口")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/service/v1/pay/page") && !paths.contains("支付服务接口.VIEW")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/service/v1/pay/edit") && !paths.contains("支付服务接口.EDIT")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/service/v1/pay/publish") && !paths.contains("支付服务接口.PUBLISH")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/smartapp/index.html") && !paths.contains("发布智能应用")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/smartapp/v1/findByPage") && !paths.contains("发布智能应用.VIEW")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/smartapp/v1/service/edit") && !paths.contains("发布智能应用.EDIT")){
            ifRight = false;
        }else if(request.getRequestURI().equals("/smartapp/v1/service/publish") && !paths.contains("发布智能应用.PUBLISH")){
            ifRight = false;
        }
        return ifRight;
    }


    @Override
    public void destroy() {
        System.out.println("destroy----------filter");
    }


}
