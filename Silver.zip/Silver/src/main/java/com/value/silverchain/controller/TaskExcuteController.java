package com.value.silverchain.controller;

import cn.hyperchain.sdk.crypto.ECKey;
import cn.hyperchain.sdk.crypto.ECPriv;
import cn.hyperchain.sdk.rpc.utils.ByteUtil;
import com.alibaba.fastjson.JSONObject;
import com.mongodb.DuplicateKeyException;
import com.value.silverchain.common.Constants;
import com.value.silverchain.dto.SmartAppSnapshotInfo;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.*;
import com.value.silverchain.service.*;
import com.value.silverchain.util.JsonUtil;
import com.value.silverchain.util.SmartAppHttpClientUtil;
import com.value.silverchain.vo.Result;
import com.value.silverchain.vo.SmartFunJsonDetail;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/6/13
 * DESC:智能合约任务调用控制器
 */
@Controller
@RequestMapping("/task/v1")
public class TaskExcuteController {
    private Logger logger = LoggerFactory.getLogger(OrgSmartAPPController.class);
    @Autowired
    private ISmartAppInfoService smartAppInfoService;
    @Autowired
    private IOrgInfoService orgInfoService;
    @Autowired
    private IPeerSettingInfoService peerSettingInfoService;
    @Autowired
    private IPayApiService payApiService;
    @Autowired
    private IDealInfoService dealInfoService;
    @Autowired
    private IServiceApiService serviceApiService;
    @Autowired
    private IChainService chainService;
    @Autowired
    private  IUnionpayService unionpayService;
    @Autowired
    private IBusinessInfoService businessInfoService;

 
    /**
     * 合约执行
     * @param params
     * @param request
     * @param response
     * @return
     */
    @RequestMapping("/excute")
    @ResponseBody
    public String excute(@RequestBody Map<String,Object> params, HttpServletRequest request, HttpServletResponse response){
        Result result = new Result();
        String token = request.getHeader("token");//令牌
        boolean firstCall=params.get("firstCall")==null;
        try{
            //检查参数值是否为空，如果是初次调用，检查流水号是否已经使用，获取智能应用信息快照
            checkNull(params,token);
            //接收调用时，上链日志，标记已经收到
            logSmartStart(params);
            //执行应用
            excuteSmartApp(params,token);
        }catch (HorizonBizException e){
            e.printStackTrace();
            logError(params,e);
            result.setState(e.getError());
            result.getData().put("errmsg",e.getErrorMsg());
            if(!firstCall){
                //不是第一次调用，调用失败回调API，通知应用发布商户，交易失败
                callFailue(params,token);
            }
        }catch (Exception e){
            e.printStackTrace();
            logError(params,new HorizonBizException(Constants.Return.SYSTEM_ERR,e.getMessage()));
            result.setState(Constants.Return.SYSTEM_ERR);
            if(!firstCall){
                //不是第一次调用，调用失败回调API，通知应用发布商户，交易失败
                callFailue(params,token);
            }
        }
        return result.toJson();
    }

    /**
     * 调用失败回调API，通知应用发布商户，交易失败
     * @param params
     * @param token
     */
    private void callFailue(Map<String, Object> params, String token) {
        SmartAppSnapshotInfo smartAppSnapshotInfo =(SmartAppSnapshotInfo)params.get("smartAppSnapshotInfo");
        if(StringUtils.isNotBlank(smartAppSnapshotInfo.getFailueApi())){
            //当智能应用有失败回调api时，需要执行api，通知应用发布商户，交易失败
            try {
                PeerSettingInfo smartPeer = getIpByPk(smartAppSnapshotInfo.getPkPeerSettingInfo());
                if(smartPeer.getPeerType()==PeerSettingInfo.PeerType.LOCAL){
                    log((String )params.get("logKeyHead"),addLogIndex(params),(String)params.get("excutePeer"),"交易失败，通知应用发布商户。");
                    //发布商户注册节点是本地节点，执行失败回调api
                    params=serviceExcute(smartAppSnapshotInfo.getFailueApi(),params);
                    //把日志下标上链
                    chainService.invokeLog((String)params.get("logKeyHead"),((Integer)params.get("logIndex")).toString());
                }else{
                    callFailue(smartPeer,params,token);
                }
            } catch (HorizonBizException e) {
                e.printStackTrace();
                logError(params,e);
                //把日志下标上链
                chainService.invokeLog((String)params.get("logKeyHead"),((Integer)params.get("logIndex")).toString());
            }
        }else{
            //当没有失败回调api时，
            //把日志下标上链
            chainService.invokeLog((String)params.get("logKeyHead"),((Integer)params.get("logIndex")).toString());
        }
    }

    /**
     * 调用失败回调API接口，通知应用发布商户，交易失败
     * @param peer
     * @param params
     * @param token
     * @throws HorizonBizException
     */
    private void callFailue(PeerSettingInfo peer, Map<String, Object> params, String token) throws HorizonBizException {
        addLogIndex(params);
        logSmartEnd(params,"交易失败，通知应用发布商户。",peer.getPeerNameAndIpWithBorder());
        //远程调用注册节点的失败回调接口
        StringBuffer url = new StringBuffer();
        url.append("http://").append(peer.getIp()).append("/task/v1/failue");
        callExcute(url.toString(),params,token,null);
    }

    /**
     * logIndex自增+1
     * @param params
     * @return
     */
    private Integer addLogIndex(Map<String, Object> params) {
        Integer logIndex = (Integer)params.get("logIndex");
        if (logIndex != null) {
            params.replace("logIndex",++logIndex);
        }
        return logIndex;
    }

    /**
     * 失败回调接口，通知客户交易失败
     * @param params
     * @param request
     * @param response
     * @return
     */
    @RequestMapping("/failue")
    @ResponseBody
    public String failue(@RequestBody Map<String,Object> params, HttpServletRequest request, HttpServletResponse response){
        Result result = new Result();
        String token = request.getHeader("token");//令牌
        try{
            //检查参数值是否为空
            checkNull(params,token);
            //接收调用时，上链日志，标记已经收到
            logSmartStart(params);
            //解释获取智能应用快照信息
            SmartAppSnapshotInfo smartAppSnapshotInfo= parseSmartAppSnapshotInfo(params,token);
            //发布商户注册节点是本地节点，执行失败回调api
            params=serviceExcute(smartAppSnapshotInfo.getFailueApi(),params);
        }catch (Exception e){
            e.printStackTrace();
            logError(params,new HorizonBizException(Constants.Return.SYSTEM_ERR,e.getMessage()));
            result.setState(Constants.Return.SYSTEM_ERR);
        }finally {
            //把日志下标上链
            chainService.invokeLog((String)params.get("logKeyHead"),((Integer)params.get("logIndex")).toString());
        }
        return result.toJson();
    }

    /**
     * 检查参数值是否为空，如果是初次调用，检查流水号是否已经使用，获取智能应用信息快照
     * @param params
     * @param token
     */
    private void checkNull(Map<String, Object> params,  String token) throws Exception {
        boolean firstCall=params.get("firstCall")==null;
        if (firstCall) {//是否第一次调用
            //是
            String aid = (String)params.get("aid");//智能应用aid
            if (StringUtils.isBlank(aid)) {
                throw new HorizonBizException(Constants.Return.AID_IS_NULL);
            }
            String apiType = (String)params.get("apiType");//接口类型
            if (StringUtils.isBlank(apiType)) {
                throw new HorizonBizException(Constants.Return.APITYPE_NULL);
            }
//            String merId = (String)params.get("merId");//商户号
//            if (StringUtils.isBlank(merId)) {
//                throw new HorizonBizException(Constants.Return.MERID_NULL);
//            }
            String orderId = (String)params.get("orderId");//订单流水号
            if (StringUtils.isBlank(orderId)) {
                throw new HorizonBizException(Constants.Return.ORDERID_NULL);
            }
            String txnTime = (String)params.get("txnTime");//订单交易时间
            if (StringUtils.isBlank(txnTime)) {
                throw new HorizonBizException(Constants.Return.TXNTIME_NULL);
            }
            String txnAmt = (String)params.get("txnAmt");//交易金额
            if (StringUtils.isBlank(txnAmt)) {
                throw new HorizonBizException(Constants.Return.TXNAMT_NULL);
            }
//            String accNo = (String)params.get("accNo");//银行卡号
//            if (StringUtils.isBlank(accNo)) {
//                throw new HorizonBizException(Constants.Return.ACCNO_NULL);
//            }
            String privkey = (String)params.get("privkey");//银行卡号
            if (StringUtils.isBlank(privkey)) {
                throw new HorizonBizException(Constants.Return.PRIVKEY_NULL);
            }
            //从params中取参数，查询智能应用相关信息，保存成快照
            saveSnapshot(params,token);

        }else{
            //否
            if (StringUtils.isBlank((String)params.get("logKeyHead"))) {
                throw new HorizonBizException(Constants.Return.LOG_KEY_HEAD_NOT_FOUND);
            }
            if ((Integer)params.get("logIndex")==null) {
                throw new HorizonBizException(Constants.Return.LOG_INDEX_NOT_FOUND);
            }
            Object smartAppSnapshotInfo=params.get("smartAppSnapshotInfo");
            if (smartAppSnapshotInfo == null) {
                throw new HorizonBizException(Constants.Return.SMART_SNAPSHOT_INFO_ERROR);
            }
        }
    }

    /**
     * 检查交易流水号是否已经被使用过
     * @param dealNo
     * @param token
     * @throws HorizonBizException
     */
    private void checkOrderIdUsed(String dealNo,String token) throws HorizonBizException {
        //银联注册节点信息
        PeerSettingInfo upPeer= getIpByName("银联");
        Map<String,Object> params = new HashMap<>();
        params.put("dealNo",dealNo);
        StringBuffer url = new StringBuffer();
        url.append("http://").append(upPeer.getIp()).append("/task/v1/checkused");
        logger.info("------------------------------------------------检查交易流水号是否已经被使用过");
        checkOrderIdUsed(url.toString(),JsonUtil.writeJson(params),token,null);
    }

    /**
     * 检查交易流水号是否已经被使用过，异常时重调，最多2次
     * @param url
     * @param json
     * @param token
     * @param recallTimes
     * @throws HorizonBizException
     */
    private void checkOrderIdUsed(String url, String json, String token, Integer recallTimes) throws HorizonBizException {
        if (recallTimes == null) {
            recallTimes=0;
        }
        try{
            String result=SmartAppHttpClientUtil.doPostJsonWithToken(url,json,token);
            if(StringUtils.isNotBlank(result)){
                JSONObject jsonObject = JSONObject.parseObject(result);
                if (!Constants.Return.SUCCESS.getCode().equals(jsonObject.getString("code"))){
                    recallTimes=2;//当调用有结果返回，抛异常时不会再重调
                    throw new HorizonBizException(Constants.getReturnByCode(jsonObject.getString("code")));
                }
            }else{
                throw new HorizonBizException(Constants.Return.DEAL_NO_CHECK_REGISTED_RAS_ERR);
            }
        }catch (HorizonBizException e){
            if(recallTimes<2){
                sleep(1);
                checkOrderIdUsed(url,json,token,++recallTimes);
            }else{
                throw e;
            }
        }
    }

    /**
     * 检查交易流水号是否已经被使用
     * @return
     */
    @RequestMapping("/checkused")
    @ResponseBody
    public String checkused(@RequestBody Map<String,Object> params, HttpServletRequest request, HttpServletResponse response){
        Result result = new Result();
        String dealNo=(String )params.get("dealNo");
        try{
            DealInfo existsDeal = dealInfoService.getDealByDealNo(dealNo);
            if (existsDeal != null) {
                result.setState(Constants.Return.DEAL_NO_HAS_BEEN_REGISTED);
            }
        }catch (Exception e){
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }
    /**
     * 异常日志，异常日志不能为日志的第一条
     * @param params
     * @param e
     */
    private void logError(Map<String, Object> params, HorizonBizException e) {
        String logKeyHead=(String)params.get("logKeyHead");
        if(StringUtils.isNotBlank(logKeyHead)){
            //当日志key头不为空时，表示第一条正常日志已经上链，异常日志才能上链，否则不上链
            String excutPeer=(String)params.get("excutePeer");
            log(logKeyHead,addLogIndex(params),excutPeer,e.getCodeAndMsg());
        }
    }

    /**
     * 执行智能应用
     * @param params
     * @param token
     */
    private void excuteSmartApp(Map<String, Object> params, String token) throws HorizonBizException{
        String logStr=null;//日志内容
        String logKeyHead=(String)params.get("logKeyHead");
        String excutPeer=(String)params.get("excutePeer");
        boolean firstCall=params.get("firstCall")==null;//是否第一次调用

        //解释获取智能应用快照信息
        SmartAppSnapshotInfo smartAppSnapshotInfo= parseSmartAppSnapshotInfo(params,token);
        Integer smartappIndex = smartAppSnapshotInfo.getSmartappIndex();
        if(smartappIndex==0){
            //协作商户注册节点信息
            PeerSettingInfo coopPeer = getIpByPk(smartAppSnapshotInfo.getCooperatePeer());
            if(coopPeer.getPeerType().equals(PeerSettingInfo.PeerType.LOCAL)){
                //协作商户注册节点是本地节点，执行定位任务
                logger.info("------------------------------------------------定位任务执行节点:"+smartAppSnapshotInfo.getDealInfo().getDealNo());
                logger.info("------------------------------------------------5、核对交易:"+smartAppSnapshotInfo.getDealInfo().getDealNo());
                //银联注册节点信息
                PeerSettingInfo upPeer= getIpByName("银联");
                Integer logIndex;
                if(firstCall){
                    //第一次调用，不做核对交易处理
                    logIndex=(Integer)params.get("logIndex");
                    logStr="备案交易完成，调用UP节点，执行扣费，任务下标："+smartAppSnapshotInfo.getSmartappIndex()+"。";
                }else {
                    //5、核对交易
                    logIndex  =checkDeal(upPeer,smartAppSnapshotInfo.getDealInfo().getDealToken(),token,logKeyHead,(Integer)params.get("logIndex"),excutPeer);
                    logStr="定位协作商户节点完成，调用UP节点，执行扣费，任务下标："+smartAppSnapshotInfo.getSmartappIndex()+"。";
                }

                //6、调用UP节点的合约执行api
                smartAppSnapshotInfo.setSmartappIndex(++smartappIndex);//更新任务下标
                logger.info("------------------------------------------------6、调用UP节点的合约执行api  smartappIndex:"+smartappIndex+","+smartAppSnapshotInfo.getDealInfo().getDealNo());
                smartAppSnapshotInfo.setLogIndex(++logIndex);
                callExcute(upPeer,params,token,logStr,smartAppSnapshotInfo);
            }else{
                //3、调用协作商户注册节点的合约执行api
                logger.info("------------------------------------------------3、调用协作商户注册节点的合约执行api  smartappIndex:"+smartappIndex+","+smartAppSnapshotInfo.getDealInfo().getDealNo());
                Integer logIndex =(Integer)params.get("logIndex");
                smartAppSnapshotInfo.setLogIndex(++logIndex);
                logStr="备案交易完成，定位协作商户节点，任务下标："+smartAppSnapshotInfo.getSmartappIndex()+"。";
                callExcute(coopPeer,params,token,  logStr, smartAppSnapshotInfo);
            }
        }else if (smartappIndex==1){
            Integer logIndex=(Integer)params.get("logIndex");
            //协作商户注册节点信息
            PeerSettingInfo coopPeer = getIpByPk(smartAppSnapshotInfo.getCooperatePeer());
            logger.info("------------------------------------------------扣费任务执行:"+smartAppSnapshotInfo.getDealInfo().getDealNo());
            //扣费任务
            //8、核对交易
            logger.info("------------------------------------------------8、核对交易:"+smartAppSnapshotInfo.getDealInfo().getDealNo());
            DealInfo existsDeal = dealInfoService.getDealByToken(smartAppSnapshotInfo.getDealInfo().getDealToken());
            if (existsDeal == null) {
                throw new HorizonBizException(Constants.Return.DEAL_INFO_UNFOUND);
            }
            log(logKeyHead,++logIndex,excutPeer,"核对交易成功。");
            logger.info("------------------------------------------------11、通知UP扣费:"+smartAppSnapshotInfo.getDealInfo().getDealNo());
            //11、通知UP扣费
            DealInfo dealInfo = smartAppSnapshotInfo.getDealInfo();
            String resultMsg = unionpayService.consume(dealInfo.getMerId(), dealInfo.getDealDate(), dealInfo.getOrderId(), dealInfo.getDealSum(), dealInfo.getAccNo());

            //12、调用协作商户注册节点的合约执行api
            smartAppSnapshotInfo.setSmartappIndex(++smartappIndex);//更新任务下标
            logger.info("------------------------------------------------12、调用协作商户注册节点的合约执行api  smartappIndex:"+smartappIndex+","+smartAppSnapshotInfo.getDealInfo().getDealNo());
            smartAppSnapshotInfo.setLogIndex(++logIndex);
            logStr="扣费完成，调用协作商户节点执行服务，任务下标："+smartAppSnapshotInfo.getSmartappIndex()+"。";
            callExcute(coopPeer,params,token,logStr, smartAppSnapshotInfo);

        }else if (smartappIndex==2){
            //智能应用发布商户注册节点信息
            PeerSettingInfo smartPeer = getIpByPk(smartAppSnapshotInfo.getPkPeerSettingInfo());
            logger.info("------------------------------------------------服务任务:"+smartAppSnapshotInfo.getDealInfo().getDealNo());
            //服务任务
            //13、执行服务业务
            logger.info("------------------------------------------------13、执行服务业务:"+smartAppSnapshotInfo.getDealInfo().getDealNo());
            //执行业务
            params=serviceExcute(smartAppSnapshotInfo.getServiceApi(),params);
            //保存交易信息到本地
            logger.info("------------------------------------------------保存交易信息到本地:"+smartAppSnapshotInfo.getDealInfo().getDealNo());
            saveDealInfoLocal(smartAppSnapshotInfo.getDealInfo(),smartAppSnapshotInfo.getDealInfo().getMerId());
            //15、调用智能应用发布商户注册节点的合约执行api
            smartAppSnapshotInfo.setSmartappIndex(++smartappIndex);//更新任务下标
            logger.info("------------------------------------------------15、调用智能应用发布商户注册节点的合约执行api  smartappIndex:"+smartappIndex+","+smartAppSnapshotInfo.getDealInfo().getDealNo());
            Integer logIndex =(Integer)params.get("logIndex");
            System.out.println("logIndex:"+logIndex);
            smartAppSnapshotInfo.setLogIndex(++logIndex);
            logStr="服务业务完成，调用发布商户节点执行回调业务，任务下标："+smartAppSnapshotInfo.getSmartappIndex()+"。";
            callExcute(smartPeer,params,token, logStr, smartAppSnapshotInfo);
        }else if (smartappIndex==3){
            logger.info("------------------------------------------------回调任务:"+smartAppSnapshotInfo.getDealInfo().getDealNo());
            //回调任务
            logger.info("------------------------------------------------17、执行回调业务:"+smartAppSnapshotInfo.getDealInfo().getDealNo());
            for(String content:smartAppSnapshotInfo.getTaskContent()){
                params=serviceExcute(content,params);
            }
            //保存交易信息到本地
            saveDealInfoLocal(smartAppSnapshotInfo.getDealInfo(), (String)params.get("smartCompanyNo"));
            logger.info("------------------------------------------------任务结束:"+smartAppSnapshotInfo.getDealInfo().getDealNo());
            Integer logIndex =addLogIndex(params);
            log(logKeyHead,logIndex,excutPeer,"回调业务完成，智能应用执行完成，任务下标："+smartAppSnapshotInfo.getSmartappIndex()+"。");

            //把日志下标上链
            chainService.invokeLog(logKeyHead,logIndex.toString());
        }else{
            throw new HorizonBizException(Constants.Return.TASK_INDEX_ERROR);
        }
    }
    /**
     * 备案交易
     * @param upPeer
     * @param dealInfo
     * @param token
     * @param excutePeer
     * @return
     */
    private JSONObject registerDeal(PeerSettingInfo upPeer, DealInfo dealInfo, String token, String excutePeer) throws HorizonBizException {
        //到银联节点交易备案，获取token
        dealInfo.addLogIndex();
        log(dealInfo.getLogKeyHead(),dealInfo.getLogIndex(),excutePeer,"调用交易备案接口备案交易信息。");
        StringBuffer url = new StringBuffer();
        url.append("http://").append(upPeer.getIp()).append("/task/v1/register");
        return registerDeal(url.toString(),JsonUtil.writeJson(dealInfo),token,null);
    }

    /**
     * 备案交易，异常时重调，最多2次
     * @param url
     * @param json
     * @param token
     * @param recallTimes
     * @return
     * @throws HorizonBizException
     */
    private JSONObject registerDeal(String url, String json, String token, Integer recallTimes) throws HorizonBizException {
        if(recallTimes==null){
            recallTimes=0;
        }
        try{
            String result=SmartAppHttpClientUtil.doPostJsonWithToken(url,json,token);
            if (StringUtils.isNotBlank(result)) {
                JSONObject jsonObject = JSONObject.parseObject(result);
                if(Constants.Return.SUCCESS.getCode().equals(jsonObject.getString("code"))){
                    return JSONObject.parseObject(jsonObject.getString("data"));
                }else {
                    recallTimes=2;//当调用有结果返回，抛异常时不会再重调
                    throw new HorizonBizException(Constants.getReturnByCode(jsonObject.getString("code")));
                }
            }else{
                throw new HorizonBizException(Constants.Return.DEAL_REGISTED_RAS_ERR);
            }
        }catch (HorizonBizException e){
            if(recallTimes<2){
                sleep(1);
                return registerDeal(url,json,token,++recallTimes);
            }else{
                throw new HorizonBizException(Constants.Return.DEAL_REGISTED_RAS_ERR);
            }
        }
    }
    /**
     * 延时i秒
     * @param i
     */
    private void sleep(int i){
        try
        {
//            System.out.println( "延时前:"+new Date().toString()  );
            Thread.currentThread().sleep(i*1000);//毫秒   
//            System.out.println( "延时后:"+new Date().toString()  );
        }
        catch(Exception e){}
    }
    /**
     * 交易备案
     * @return
     */
    @RequestMapping("/register")
    @ResponseBody
    public String register(@RequestBody DealInfo dealInfo, HttpServletRequest request, HttpServletResponse response){
        Result result = new Result();
        dealInfo.setPkDealInfo(UUID.randomUUID().toString());
        dealInfo.setDealToken(dealInfo.getPkDealInfo());
        String logStr=null;
        String excutePeer=null;
        try{
            excutePeer=getExcutePeer();
            //日志上链
            log(dealInfo.getLogKeyHead(),dealInfo.addLogIndex(),excutePeer,"收到备案请求。");
//            保存交易信息
            String id =dealInfoService.save(dealInfo);
            if(StringUtils.isBlank(id)){
                result.setState(Constants.Return.CREATE_DEAL_INFO_FALSE);
                logStr=Constants.Return.CREATE_DEAL_INFO_FALSE.getMsg()+"。";
            }
            if(StringUtils.isNotBlank(id)){
                logStr="保存交易信息成功。";
                result.getData().put("dealToken",dealInfo.getDealToken());
                logger.info("-----------------dealToken:"+dealInfo.getDealToken());
            }
        }catch (DuplicateKeyException e){
            e.printStackTrace();
            result.setState(Constants.Return.DEAL_NO_HAS_BEEN_REGISTED);
            logStr=Constants.Return.DEAL_NO_HAS_BEEN_REGISTED.getMsg()+"。";
        }finally {
            //备案结束上链
            log(dealInfo.getLogKeyHead(),dealInfo.addLogIndex(),excutePeer,logStr);
            result.getData().put("logIndex",dealInfo.getLogIndex());
        }
        return result.toJson();
    }
    /**
     * 核对交易
     * @param upPeer
     * @param dealToken
     * @param logKeyHead
     * @param logIndex
     * @param excutePeer
     * @return
     */
    private Integer checkDeal(PeerSettingInfo upPeer, String dealToken, String token, String logKeyHead, Integer logIndex, String excutePeer) throws HorizonBizException {
        //到银联节点核对交易是否已经备案
        StringBuffer url = new StringBuffer();
        url.append("http://").append(upPeer.getIp()).append("/task/v1/check");
        Map<String,Object> params = new HashMap<>();
        System.out.println("dealToken:"+dealToken);
        params.put("dealToken",dealToken);
        params.put("logKeyHead",logKeyHead);
        params.put("logIndex",++logIndex);
        log(logKeyHead,logIndex,excutePeer,"调用交易核对接口，核对交易。");
        return checkDeal(url.toString(),JsonUtil.writeJson(params),token,null);
    }

    /**
     * 核对交易,异常时重调，最多2次
     * @param url
     * @param json
     * @param token
     * @param recallTimes
     * @return
     * @throws HorizonBizException
     */
    private Integer checkDeal(String url, String json, String token, Integer recallTimes) throws HorizonBizException {
        if (recallTimes == null) {
            recallTimes=0;
        }
        try {
            String result=SmartAppHttpClientUtil.doPostJsonWithToken(url,json,token);
            logger.info("------------------------------------------------核对交易 结果："+result);
            JSONObject jsonObject = JSONObject.parseObject(result);
            if(Constants.Return.SUCCESS.getCode().equals(jsonObject.getString("code"))){
                JSONObject data =JSONObject.parseObject(jsonObject.getString("data"));
                return data.getInteger("logIndex");
            }else{
                throw new HorizonBizException(Constants.Return.CHECK_DEAL_INFO_FALSE);
            }
        }catch (HorizonBizException e){
            if(recallTimes<=2){
                return checkDeal(url,json,token,++recallTimes);
            }else{
                throw e;
            }
        }
    }

    /**
     * 交易核对
     * @return
     */
    @RequestMapping("/check")
    @ResponseBody
    public String check(@RequestBody Map<String,Object> params, HttpServletRequest request, HttpServletResponse response){
        Result result = new Result();
        String dealToken=(String )params.get("dealToken");
        String logKeyHead=(String )params.get("logKeyHead");
        Integer logIndex=(Integer )params.get("logIndex");
        String excutePeer=null;
        String logStr=null;
        try{
            excutePeer=getExcutePeer();
            //日志上链
            logger.info("---------------check dealToken:"+dealToken);

            log(logKeyHead,++logIndex,excutePeer,"收到核对交易请求。");

            if (dealToken == null) {
                result.setState(Constants.Return.DEAL_INFO_TOKEN_NOT_FOUND);
                logStr=Constants.Return.DEAL_INFO_TOKEN_NOT_FOUND.getMsg()+"。";
            }else{
                DealInfo existsDeal = dealInfoService.getDealByToken(dealToken);
                if (existsDeal == null) {

                    result.setState(Constants.Return.DEAL_INFO_UNFOUND);
                    logStr=Constants.Return.DEAL_INFO_UNFOUND+"。";
                }else{
                    logStr="核对交易完成。";
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            logStr="系统异常，异常信息："+e.getMessage()+"。";
            result.setState(Constants.Return.CHECK_DEAL_INFO_FALSE);
        }finally {
            log(logKeyHead,++logIndex,excutePeer,logStr);
            result.getData().put("logIndex",logIndex);
        }
        return result.toJson();
    }
    /**
     * 解释获取智能应用快照信息
     * @param params
     * @param token
     * @return
     */
    private SmartAppSnapshotInfo parseSmartAppSnapshotInfo(Map<String, Object> params, String token) throws HorizonBizException{
        SmartAppSnapshotInfo smartAppSnapshotInfo;
        if (params.get("firstCall")==null) {//是否第一次调用
            smartAppSnapshotInfo=(SmartAppSnapshotInfo)params.get("smartAppSnapshotInfo");
            //是
            logger.info("------------------------------------------------任务开始:"+smartAppSnapshotInfo.getDealInfo().getDealNo());
            //1、交易调用合约发布方节点
            logger.info("------------------------------------------------1、交易调用合约发布方节点:"+smartAppSnapshotInfo.getDealInfo().getDealNo());
            params.put("firstCall","firstCall");
            //2、备案
            logger.info("------------------------------------------------2、到银联节点备案交易:"+smartAppSnapshotInfo.getDealInfo().getDealNo());
            smartAppSnapshotInfo.getDealInfo().setLogIndex((Integer)params.get("logIndex"));
            PeerSettingInfo upPeer= getIpByName("银联");
            JSONObject registerResult = registerDeal(upPeer,smartAppSnapshotInfo.getDealInfo(),token,(String)params.get("excutePeer"));
            smartAppSnapshotInfo.getDealInfo().setDealToken(registerResult.getString("dealToken"));
            params.replace("logIndex",registerResult.getInteger("logIndex"));
        }else{
            smartAppSnapshotInfo=JsonUtil.jsonToObject(JsonUtil.writeJson(params.get("smartAppSnapshotInfo")),SmartAppSnapshotInfo.class);
        }
        params.replace("smartAppSnapshotInfo", smartAppSnapshotInfo);
        return smartAppSnapshotInfo;
    }
    /**
     * 接收调用时日志上链
     * @param params
     * @throws HorizonBizException
     */
    private String logSmartStart(Map<String, Object> params) throws HorizonBizException {
        String logKeyHead =(String)params.get("logKeyHead");//日志key头
        Integer logIndex;//日志key下标
        String logStr;//日志内容
        StringBuffer logBotton=new StringBuffer();//日志内容尾
        String excutePeer=getExcutePeer();//执行节点信息
        
        boolean firstCall=(String)params.get("firstCall")==null;
        if (firstCall) {//是否第一次调用
            //是
            params.put("excutePeer",excutePeer);
            logIndex=1;
            params.put("logIndex",logIndex);
            logStr="智能应用开始执行。";
            logBotton.append(" [执行节点"+excutePeer+"]");
        }else{
            String callPeer=(String)params.get("excutePeer");//调用节点信息
            params.replace("excutePeer",excutePeer);
            logIndex=(Integer)params.get("logIndex");
            logIndex++;
            params.replace("logIndex",logIndex);
            logStr="成功接收调用请求。";
            logBotton.append(" [发起调用节点"+callPeer+"] [执行节点"+excutePeer+"]");
        }
        String key = logKeyHead+"_"+logIndex;
        String value=logIndex+"、"+logStr+logBotton.toString();
        chainService.invokeLog(key,value);
        return logKeyHead;
    }
    /**
     * 智能应用在节点执行完成后上链日志
     */
    private void logSmartEnd(Map<String, Object> params,String logStr,String callPeer) {
        Integer logIndex=(Integer)params.get("logIndex") ;
        String key = (String)params.get("logKeyHead")+"_"+logIndex;
        String value=logIndex+"、"+logStr+"[执行节点"+(String)params.get("excutePeer")+"] [调用接收节点"+callPeer+"]";
        //日志上链
        chainService.invokeLog(key,value);
    }
    /**
     * 节点执行过程中的日志上链
     * @param logKeyHead
     * @param logIndex
     * @param excutePeer
     * @param logStr
     */
    private void log(String logKeyHead, Integer logIndex, String excutePeer, String logStr) {
        String key = logKeyHead+"_"+logIndex;
        String value=logIndex+"、"+logStr+"[执行节点"+excutePeer+"]";
        chainService.invokeLog(key,value);
    }
    /**
     * 获取执行节点
     * @return
     */
    private String getExcutePeer() {
        String excutePeer=null;
        //查找本地节点信息，节点信息异常时，不能影响应用的调用
        try{
            List<PeerSettingInfo> lis = peerSettingInfoService.findByPeerType(PeerSettingInfo.PeerType.LOCAL);
            PeerSettingInfo localPeer;
            if(lis==null||lis.size()==0){
                excutePeer="[未找到本地节点]";
            }else if (lis.size()==1){
                excutePeer=lis.get(0).getPeerNameAndIpWithBorder();
            }else{
                StringBuffer str =new StringBuffer();
                for (PeerSettingInfo p:lis){
                    str.append(p.getPeerNameAndIp()+";");
                }

                excutePeer="[找到多个本地节点："+str.toString()+"]";
            }
        }catch (Exception e){
            excutePeer="[查找本地节点异常,异常信息:"+e.getMessage()+"]";
        }
        return excutePeer;
    }
    /**
     * 封装智能应用快照
     * @param params
     * @return
     * @throws Exception
     */
    private void  saveSnapshot(Map<String, Object> params,String token) throws HorizonBizException,Exception {
        Date date = new Date();//智能应用调用时间
        String aid = (String)params.get("aid");//智能应用aid
        params.remove("aid");
        
        String apiType = (String)params.get("apiType");//接口类型
        params.remove("apiType");

//        String merId = (String)params.get("merId");//商户号
//        params.remove("merId");

        String orderId = (String)params.get("orderId");//订单流水号
        params.remove("orderId");

        String txnTime = (String)params.get("txnTime");//订单交易时间
        params.remove("txnTime");
        
        String txnAmt = (String)params.get("txnAmt");//交易金额
        params.remove("txnAmt");
        
//        String accNo = (String)params.get("accNo");//银行卡号
//        params.remove("accNo");

        String privkey = (String)params.get("privkey");//私钥
        params.remove("privkey");
        
        String address =privkey2ECPriv(privkey);
        
        params.put("logKeyHead",aid+"_"+orderId);//日志key头
        //查智能应用
        SmartAppInfo smartAppInfo = smartAppInfoService.getSmartAppInfoByAid(aid,apiType);
        if (smartAppInfo == null) {
            throw new HorizonBizException(Constants.Return.FIND_SMART_APP_INFO_FALSE);
        }
        //查发布商户
        CompanyInfo smartCompany  = new CompanyInfo();
        smartCompany.setPkCompanyInfo(smartAppInfo.getPkCompanyInfo());
        smartCompany=orgInfoService.getCompanyInfoByID(smartCompany);//智能应用发布商户
        if (smartCompany == null) {
            throw new HorizonBizException(Constants.Return.SMART_COMPANY_UNFOUND);
        }
        //检查私钥是否正确
        if(!address.equals(smartCompany.getChainAddr())){
            throw new HorizonBizException(Constants.Return.PRIVKEY_CHECK_ERROR);
        }
        //查协作商户
        CompanyInfo coopCompany=new CompanyInfo();
        coopCompany.setPkCompanyInfo(smartAppInfo.getCooperateCompany().get(0));
        coopCompany=orgInfoService.getCompanyInfoByID(coopCompany);//收款方(协作商户)
        if (coopCompany == null) {
            throw new HorizonBizException(Constants.Return.COOP_COMPANY_UNFOUND);
        }
        String merId=coopCompany.getCompanyNo();
        //检查订单号是否已经备案
        checkOrderIdUsed(merId+"_"+orderId,token);

        //查发布商户的银行卡号
        AccountInfo accountInfo=businessInfoService.getAccountInfoByCompany(smartCompany.getPkCompanyInfo(),AccountInfo.SupportTradeType.PAUSE);

        //取协作商户服务接口信息
         ServiceApiInfo serviceApiInfo = new ServiceApiInfo();
        serviceApiInfo.setPkApiTypeInfo(smartAppInfo.getPkApiTypeInfo());//接口类型
        serviceApiInfo.setPkCompanyInfo(smartAppInfo.getCooperateCompany().get(0));//服务发布方
        List<String> targetCompany=new ArrayList<>();
        targetCompany.add(smartAppInfo.getPkCompanyInfo());//目标商户
        serviceApiInfo.setTargetCompany(targetCompany);
        serviceApiInfo=serviceApiService.getByCondition(serviceApiInfo);
        
        //封装交易信息
        DealInfo dealInfo =new DealInfo();
        dealInfo.setDealDate(txnTime);//交易时间
        dealInfo.setDealSum(txnAmt);//交易金额
        dealInfo.setPayPkCompanyInfo(smartAppInfo.getPkCompanyInfo());//交易发起方即付款方
        dealInfo.setReceiptPkCompanyInfo(coopCompany.getPkCompanyInfo());//服务方即收款方
        dealInfo.setMerId(merId);//商户号
        dealInfo.setAccNo(accountInfo.getCardNo());//银行卡号
        dealInfo.setOrderId(orderId);//交易流水号
        dealInfo.setDealNo(merId+"_"+orderId);//商户号+交易流水号
        dealInfo.setAid(smartAppInfo.getAid());//智能应用aid
        dealInfo.setLogKeyHead((String)params.get("logKeyHead"));
        //取协作商户平台手续费率
        Float coopRate =getRate(smartAppInfo.getPkApiTypeInfo(),coopCompany.getPkCompanyInfo(),PayApiInfo.PayType.SERVICE,date);
        //取智能应用发布方平台手续费率
        Float smartRate = getRate(smartAppInfo.getPkApiTypeInfo(),smartAppInfo.getPkCompanyInfo(),PayApiInfo.PayType.SMART,date);
        dealInfo.setHandlingCharge(Float.parseFloat(txnAmt)*(coopRate+smartRate)/100);
        
        SmartAppSnapshotInfo smartAppSnapshotInfo =new SmartAppSnapshotInfo();
        smartAppSnapshotInfo.setDate(date);
        smartAppSnapshotInfo.setAid(aid);
        smartAppSnapshotInfo.setPkCompanyInfo(smartAppInfo.getPkCompanyInfo());
        smartAppSnapshotInfo.setPkPeerSettingInfo(smartCompany.getPkPeerSettingInfo());
        smartAppSnapshotInfo.setCooperateCompany(coopCompany.getPkCompanyInfo());
        smartAppSnapshotInfo.setCooperatePeer(coopCompany.getPkPeerSettingInfo());
        smartAppSnapshotInfo.setTaskContent(smartAppInfo.getTaskContent());
        smartAppSnapshotInfo.setTaskContent(smartAppInfo.getTaskContent());
        smartAppSnapshotInfo.setDealInfo(dealInfo);
//        smartAppSnapshotInfo.setServiceApi(serviceApiInfo.getApiDescription());
        smartAppSnapshotInfo.setFailueApi(smartAppInfo.getFailueApi());
        params.put("smartCompanyNo",smartCompany.getCompanyNo());//发布商户的商户号
        params.put("smartAppSnapshotInfo",smartAppSnapshotInfo);
    }

    /**
     * 通过私钥，解释出地址
     * @param privkey
     * @return
     */
    private String privkey2ECPriv(String privkey) {
        byte[] bytes = ByteUtil.hexStringToBytes(privkey);
        ECKey ecKey = ECKey.fromPrivate(bytes);
        return new ECPriv(ecKey).address();
    }
    /**
     * 保存交易到本地
     * @param dealInfo
     * @param merId
     */
    private DealInfo saveDealInfoLocal(DealInfo dealInfo, String merId) throws HorizonBizException {
        String dealToken=dealInfo.getDealToken();//原token
        String newDealToken=merId+"_"+dealInfo.getDealToken();
        DealInfo existsDeal = dealInfoService.getDealByToken(newDealToken);
        if (existsDeal == null) {
            dealInfo.setPkDealInfo(UUID.randomUUID().toString());
            dealInfo.setDealToken(newDealToken);
            String  id =dealInfoService.save(dealInfo);
            if(StringUtils.isBlank(id)){
                throw new HorizonBizException(Constants.Return.CREATE_DEAL_INFO_FALSE);
            }
            dealInfo.setDealToken(dealToken);//换回原token
            return dealInfo;
        }else {
            return existsDeal;
        }
    }

    /**
     * 取平台手续费率
     * @param pkApiTypeInfo
     * @param pkCompanyInfo
     * @param payType
     * @param date
     * @return
     * @throws HorizonBizException
     */
    private Float getRate(String pkApiTypeInfo, String pkCompanyInfo, PayApiInfo.PayType payType, Date date) throws HorizonBizException {
        PayApiInfo payApiInfo = new PayApiInfo();
        payApiInfo.setPkApiTypeInfo(pkApiTypeInfo);//接口类型主键
        List<String> targetCompany = new ArrayList<>();
        targetCompany.add(pkCompanyInfo);//目标商户
        payApiInfo.setTargetCompany(targetCompany);
        payApiInfo.setPayType(payType);
        payApiInfo.setStartDate(date);
        Float rate =payApiService.getRate(payApiInfo);
        return rate;
    }


    /**
     * 执行业务
     * @param apiDescription
     * @param params
     */
    private Map<String, Object>  serviceExcute(String apiDescription, Map<String, Object> params) throws HorizonBizException {
        String logKeyHead=(String )params.get("logKeyHead");
        String excutePeer=(String)params.get("excutePeer");
        log(logKeyHead,addLogIndex(params),excutePeer,"执行业务方法："+apiDescription+"。");
        logger.info("执行业务方法 apiDescription:"+apiDescription);
        //解释方法
        SmartFunJsonDetail fun = JsonUtil.jsonToObject(apiDescription,SmartFunJsonDetail.class);
        //组装方法参数map
        Map<String,String> funParams=initFunParams(params,fun.getParams());

//        String resultStr= serviceExcute(fun.getUrlPath(),JsonUtil.writeJson(funParams),null);
        String resultStr=SmartAppHttpClientUtil.doPostJson(fun.getUrlPath(),JsonUtil.writeJson(funParams));//执行业务
        logger.info("执行业务方法  resultStr:"+resultStr);
        if(StringUtils.isNotBlank(fun.getReturnName())){
            if(params.get(fun.getReturnName())==null){
                params.put(fun.getReturnName(),resultStr);//保存参数到MAP
            }else{
                params.replace(fun.getReturnName(),resultStr);//更新合约参数MAP
            }
        }
        logger.info(fun.getUrlPath()+"   result:"+resultStr);
        log(logKeyHead,addLogIndex(params),excutePeer,"执行业务方法完成。");
        return params;
    }

//    /**
//     * 执行业务，异常时重调，最多2次
//     * @param urlPath
//     * @param json
//     * @param recallTimes
//     * @return
//     * @throws HorizonBizException
//     */
//    private String serviceExcute(String urlPath, String json, Integer recallTimes) throws HorizonBizException {
//        if (recallTimes == null) {
//            recallTimes=0;
//        }
//        String resultStr;
//        try{
//            resultStr= SmartAppHttpClientUtil.doPostJson(urlPath,json);//执行业务
//        }catch (HorizonBizException e){
//            if(recallTimes<=2){
//                resultStr=serviceExcute(urlPath,json,++recallTimes);
//            }else{
//                throw e;
//            }
//        }
//        return resultStr;
//    }

    /**
     * 调用节点合约执行api
     * @param peer
     * @param params
     * @param logStr
     * @param smartAppSnapshotInfo
     */
    private void callExcute(PeerSettingInfo peer, Map<String, Object> params, String token, String logStr, SmartAppSnapshotInfo smartAppSnapshotInfo) throws HorizonBizException {
        params.replace("logIndex",smartAppSnapshotInfo.getLogIndex());//更新日志下标
        params.replace("smartAppSnapshotInfo",smartAppSnapshotInfo);//更新快照参数
        logSmartEnd(params,logStr,peer.getPeerNameAndIpWithBorder());
        //调用协作商户注册节点的合约执行api
        StringBuffer url = new StringBuffer();
        url.append("http://").append(peer.getIp()).append("/task/v1/excute");
        callExcute(url.toString(),params,token,null);
    }



    /**
     * 调用节点接口，异常时重调，最多2次
     * @param url
     * @param params
     * @param token
     * @param recallTimes
     * @throws HorizonBizException
     */
    private void callExcute(String url, Map<String, Object> params, String token, Integer recallTimes) throws HorizonBizException {
        if (recallTimes == null) {
            recallTimes=0;
        }
        try {
            SmartAppHttpClientUtil.doCallExcute(url,JsonUtil.writeJson(params),token);
        } catch (HorizonBizException e) {
            e.printStackTrace();
            if(recallTimes<=2){
                sleep(1);
                callExcute(url,params,token,++recallTimes);
            }else{
                throw e;
            }
        }
    }


    /**
     * 取IP地址
     * @param companyName
     * @return
     */
    private PeerSettingInfo getIpByName(String companyName) throws HorizonBizException {
        //取任务执行商户
        
        CompanyInfo companyInfo =new CompanyInfo();
        companyInfo.setCompanyName(companyName);
        companyInfo = orgInfoService.getCompanyInfo(companyInfo);
        if(companyInfo==null){
            throw new HorizonBizException(Constants.Return.COMPNAY_UNFOUND_ERROR);
        }
        return getIpByPk(companyInfo.getPkPeerSettingInfo());

    }
    
    /**
     * 获取节点
     * @param pkPeerSettingInfo
     * @return
     * @throws HorizonBizException
     */
    private PeerSettingInfo getIpByPk(String pkPeerSettingInfo)throws HorizonBizException{
        //取商户所在节点
        PeerSettingInfo peerSettingInfo = new PeerSettingInfo();
        peerSettingInfo.setPkPeerSettingInfo(pkPeerSettingInfo);
        peerSettingInfo=  peerSettingInfoService.getPeerSettingInfoByID(peerSettingInfo);
        if (peerSettingInfo == null) {
            throw new HorizonBizException(Constants.Return.PEER_UNFOUND_ERROR);
        }
        return  peerSettingInfo;
    }

    /**
     * 从合约参数MAP中取出方法需要的参数的值，组成方法参数MAP，这里需要合约MAP中包含了方法的参数，否则报异常
     * @param params
     * @param paramsValue
     * @return
     */
    private Map<String,String> initFunParams(Map<String, Object> params, List<String> paramsValue) throws HorizonBizException {
        Map<String,String> result= new HashMap<>();
        for (String key:paramsValue){
            Object value =params.get(key);
            if (value != null) {
                //传来参数中有值，存入匹配的参数
                result.put(key,value.toString());
            }else{
                //没有值
                throw new HorizonBizException(Constants.Return.FUN_PARAMS_UNFOUND_ERROR);
            }
        }
        return result;
    }

    /**
     * 日志列表
     * @return
     */
    @RequestMapping("/loglist")
    @ResponseBody
    public String loglist(@RequestBody String keyHead, HttpServletRequest request, HttpServletResponse response){
        Result result = new Result();
        List<String> loglist=new ArrayList<>();
        try{
            loglist = chainService.querySmartLog(keyHead);
            
        }catch (DuplicateKeyException e){
            e.printStackTrace();
            result.setState(Constants.Return.ACCT_ID_REPEAT);
            return result.toJson();
        }
        result.getData().put("loglist",loglist);
        response.setContentType("text/javascript;charset=UTF-8"); //设置编码字符
        return result.toJson();
    }
}
