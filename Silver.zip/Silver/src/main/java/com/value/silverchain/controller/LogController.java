package com.value.silverchain.controller;

import com.value.silverchain.common.Constants;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.util.FileDownloadUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.File;
import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/8/1
 * DESC:日志控制器
 */
@Controller
@RequestMapping("/log/v1")
public class LogController {

    @RequestMapping("getlog/{path}/{name}")
    @ResponseBody
    public void download(@PathVariable("path") String path, @PathVariable("name") String name)throws Exception{
        
        if(StringUtils.isNotBlank(path)&&StringUtils.isNotBlank(name)){
            try {
                int i =FileDownloadUtil.downloadFile("applog"+File.separator+path+ File.separator+name, name);
                if(i==1){
                    throw new HorizonBizException(Constants.Return.FILE_PATH_NULL);
                }else if(i==2){
                    throw new HorizonBizException(Constants.Return.FILE_NOT_FOUND);
                }
            }catch (IOException e){
                e.printStackTrace();
                throw new HorizonBizException(Constants.Return.FILE_IO_ERROR);
            }catch (Exception e){
                e.printStackTrace();
                throw new HorizonBizException(Constants.Return.SYSTEM_ERR);
            }

        }else{
            throw new HorizonBizException(Constants.Return.FILE_PATH_NULL);
        }
    }   
}
