package com.value.silverchain.vo;

import lombok.Data;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/6/11
 * DESC:智能合约-任务解释类
 */
@Data
public class SmartTaskJsonDetail {
    private String taskMark;//任务标识UUID
    private String taskName;//任务名称
    private String companyName;//公司名称
    private List<SmartFunJsonDetail> funs;//方法列表
}
