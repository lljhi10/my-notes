package com.value.silverchain.controller;

import com.value.silverchain.common.Constants;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.util.HttpClientUtil;
import com.value.silverchain.util.JsonUtil;
import com.value.silverchain.vo.HttpClientParams;
import com.value.silverchain.vo.Result;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/8/1
 * DESC:远程访问控制器
 */
@Controller
@RequestMapping
public class HttpClientController {

    @RequestMapping("/httpclient/test")
    @ResponseBody
    public String download(@RequestBody HttpClientParams httpClientParams, HttpServletResponse response)throws Exception{
        
        Result result = new Result();
        String str=null;
        try{
            if(StringUtils.isBlank(httpClientParams.getUrl())){
                throw new HorizonBizException(Constants.Return.URL_IS_NULL);
            }
            if(StringUtils.isNotBlank(httpClientParams.getType())&&"POST".equals(httpClientParams.getType())){
                //post访问
                str= HttpClientUtil.doPostJsonTest(httpClientParams.getUrl(), JsonUtil.writeJson(httpClientParams.getParams()));
            }else{
                //get访问
                str=HttpClientUtil.doGetTest(httpClientParams.getUrl(),httpClientParams.getParams());
            }
            if (str != null) {
                List<String> list =JsonUtil.jsonToObject(str, List.class);
                if (list != null&&list.size()>0) {

                    for (int i=0;i<list.size();i++){

                        result.getData().put("resultStr"+i,JsonUtil.jsonToObject(list.get(i), Object.class));
                    }
                }
            }

        }catch (HorizonBizException e){
            result.setState(e.getError());
        }catch (UnknownHostException e){
            e.printStackTrace();
            result.setState(Constants.Return.HOST_PARSE_ERROR);
        }catch (SocketTimeoutException e){
            e.printStackTrace();
            result.setState(Constants.Return.READ_TIMED_OUT);
        }catch (Exception e){
            e.printStackTrace();
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        response.setContentType("application/json; charset=UTF-8"); //设置编码字符
        return result.toJson();
    }   
}
