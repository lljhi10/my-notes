package com.value.silverchain.service;

import com.value.silverchain.bo.PageBo;
import com.value.silverchain.dto.ChainPriceTypeInfo;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.PriceTypeInfo;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:00
 * DESC:
 */
public interface IPriceTypeService {

    /**
     * 保存
     * @param payApiInfo
     * @return
     */
    String save(PriceTypeInfo payApiInfo) throws HorizonBizException;

    /**
     * 根据主键查询
     * @param pkPriceTypeInfo
     * @return
     */
    PriceTypeInfo getByKey(String pkPriceTypeInfo);

    /**
     * 分页查询
     * @param param
     * @return
     */
    PageBo<PriceTypeInfo> findPage(PriceTypeInfo param);

    /**
     * 查询列表
     * @param pkCompanyInfo
     * @return
     */
    List<PriceTypeInfo> findAll(String pkCompanyInfo);

    int updateFromChain(ChainPriceTypeInfo item);
}
