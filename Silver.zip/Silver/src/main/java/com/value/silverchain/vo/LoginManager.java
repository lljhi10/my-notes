package com.value.silverchain.vo;

import com.value.silverchain.model.BaseRole;
import com.value.silverchain.model.CompanyInfo;
import com.value.silverchain.model.ManagerInfo;
import lombok.Data;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/6/7
 * DESC:登录管理员信息
 */
@Data
public class LoginManager {
    private ManagerInfo loginUser;//当前登录用户
    
    private CompanyInfo companyInfo;//用户所属商户
    
    private List<BaseRole> roles=new ArrayList<>();//用户角色
    
    private Set<String> paths;//用户权限路径
    
    public void setRoles(List<BaseRole> roles){
        this.roles=roles;
        paths=new HashSet<String>();
        if (this.roles != null&&this.roles.size()>0) {
            roles.forEach(baseRole -> {
                paths.addAll(baseRole.getPaths());
            });
        }
        //去重
        LinkedHashSet<String> set = new LinkedHashSet<String>(paths.size());
        set.addAll(paths);
        paths.clear();
        paths.addAll(set);
    }
    /**
     * 判断管理员所属商户是否UP
     * @return
     */
    public boolean isUp(){
        if (companyInfo.getCompanyType().equals(CompanyInfo.CompanyType.UP)){
            return true;
        }
        return  false;
    }
}
