package com.value.silverchain.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Id;
import org.mongodb.morphia.annotations.Indexed;
import org.mongodb.morphia.annotations.Transient;
import org.mongodb.morphia.utils.IndexDirection;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 16:44
 * DESC:管理员帐号
 */
@Entity("manager_info")
@Data
public class ManagerInfo extends BasePage{
    public enum Status {
        VALID("有效"), INVALID("无效");
        private String name;
        Status(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum DefaultKey {
        YES("是"), NO("否");
        private String name;
        DefaultKey(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    @Id
    @JsonIgnore
    private ObjectId id;

    private String managerName;//管理员名称
    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_userID",dropDups = true)
    private String pkManagerInfo;//管理员主键
    private String pkCompanyInfo;//商户主键
    private String phone;//联系电话
    private String province;//省份
    private String city;//城市
//    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_managerNumber",dropDups = true)
    private String managerNumber;//管理员账号
    private String password;//登录密码
    private String address;//地址
    private Status status;//管理员状态：有效， 无效
    

    private List<String> pkRoles = new ArrayList<>();
    //角色主键列表
//    @Transient
//    private List<BaseRole> roles;//角色列表

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createDate;//创建时间

    private String createManager;//创建人

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateDate;//最后更新时间

    private String updateManager;//最后更新人
    
    private String priKey;//私钥
    private String pubKey;//公钥

    @Transient
    private String rolesNameList;//角色名称列表
    
    private DefaultKey defaultKey; //是否是默认密码
    
    private String email;//邮箱

    @Transient
    private String companyName;//商户名称

    public void setSid(String sid) {
        this.pkManagerInfo = sid;
    }

    public Map getStatusObject() {
        Map map = new HashMap();
        map.put("name",this.status.getName());
        map.put("value",this.status);
        return map;
    }
}
