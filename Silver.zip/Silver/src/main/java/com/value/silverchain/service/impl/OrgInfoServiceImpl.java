package com.value.silverchain.service.impl;

import com.mongodb.WriteResult;
import com.value.silverchain.bo.PageBo;
import com.value.silverchain.common.Constants;
import com.value.silverchain.dto.ChainCompanyInfo;
import com.value.silverchain.dto.CompanyInfoDto;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.CompanyInfo;
import com.value.silverchain.model.ServiceApiInfo;
import com.value.silverchain.service.IOrgInfoService;
import com.value.silverchain.service.IServiceApiService;
import org.apache.commons.lang3.StringUtils;
import org.bson.types.ObjectId;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.UpdateOperations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrgInfoServiceImpl implements IOrgInfoService {

    @Autowired
    private Datastore datastore;
    @Autowired
    private IServiceApiService serviceApiService;

    @Override
    public String save(CompanyInfo userAccount) {
        Key<CompanyInfo> key = datastore.save(userAccount);
        return ((ObjectId) key.getId()).toHexString();
    }

    @Override
    public CompanyInfo getCompanyInfoByID(CompanyInfo company) {
       
        Query<CompanyInfo> query = datastore.find(CompanyInfo.class).field("pkCompanyInfo").equal(company.getPkCompanyInfo());
        return query.get();
    }

    @Override
    public PageBo<CompanyInfo> findPage(CompanyInfo companyInfo) {
        Query<CompanyInfo> query = datastore.find(CompanyInfo.class);

        //判断当前用户是否是UP
        CompanyInfo company = new CompanyInfo();
        company.setPkCompanyInfo(companyInfo.getPkCompanyInfo());
        company = getCompanyInfoByID(company);
        if(company != null && !company.getCompanyType().equals(CompanyInfo.CompanyType.UP)) {
            query.field("pkCompanyInfo").contains(companyInfo.getPkCompanyInfo());
        }
        if(company == null) return null;
        if(StringUtils.isNotBlank(companyInfo.getCompanyName())) {
            query.field("companyName").contains(companyInfo.getCompanyName());
        }
        query.order("-createDate");
        query.offset(companyInfo.getPageNo() * companyInfo.getPageSize() - companyInfo.getPageSize());
        query.limit(companyInfo.getPageSize());
        return new PageBo(query.asList(),query.count());
    }

    /**
     *
     *  此接口给那些需要关联商户的查找选项,因此是所有,并且可用的商户,如果是up查看所有
     * @param companyInfo
     * @return
     */
    @Override
    public PageBo<CompanyInfo> findAllPage(CompanyInfo companyInfo) {
        Query<CompanyInfo> query = datastore.find(CompanyInfo.class);

        query.order("-createDate");
        query.filter("status ==",CompanyInfo.Status.NORMAL);
        /*query.filter("companyType !=",CompanyInfo.CompanyType.UP);*/
        if(StringUtils.isNotBlank(companyInfo.getCompanyName())) {
            query.field("companyName").contains(companyInfo.getCompanyName());
        }
        if (companyInfo.getPkCompanyInfo() != null) {
            query.filter("pkCompanyInfo !=",companyInfo.getPkCompanyInfo());
        }

        query.offset(companyInfo.getPageNo() * companyInfo.getPageSize() - companyInfo.getPageSize());
        query.limit(companyInfo.getPageSize());
        return new PageBo(query.asList(),query.count());
    }

    /**
     * 发布智能应用是需要选择合作商户时选择此接口
     * @param companyInfo
     * @return
     */
    @Override
    public PageBo<CompanyInfo> findAllServicePage(CompanyInfo companyInfo) {
        Query<CompanyInfo> query = datastore.find(CompanyInfo.class);

        if(StringUtils.isNotBlank(companyInfo.getCompanyName())) {
            query.field("companyName").contains(companyInfo.getCompanyName());
        }
        query.order("-createDate");
        /*query.filter("companyType !=",CompanyInfo.CompanyType.UP);*/
        query.filter("pkCompanyInfo !=",companyInfo.getPkCompanyInfo());
        //查找的商户就是除了自己以外所有发布了服务接口的商家,
        // 如果商户没有发布公开的服务接口，但发布了指定商户的服务接口，登录者所在商户在指定的商户列表中，那么显示发布商户
        ServiceApiInfo param = new ServiceApiInfo();
        param.setFindType(ServiceApiInfo.FindType.VIEW);
        param.setPkCompanyInfo(companyInfo.getPkCompanyInfo());

        PageBo<ServiceApiInfo> pageBo = serviceApiService.findPage(param);

        List<ServiceApiInfo> serviceApiInfos = pageBo.getRows();
        List<String> pkComanys = new ArrayList<String>();
        for (ServiceApiInfo item : serviceApiInfos){
            pkComanys.add(item.getPkCompanyInfo());
        }
        query.field("pkCompanyInfo").in(pkComanys);

        query.offset(companyInfo.getPageNo() * companyInfo.getPageSize() - companyInfo.getPageSize());
        query.limit(companyInfo.getPageSize());
        return new PageBo(query.asList(),query.count());
    }

    @Override
    public String delete(CompanyInfo company) {
     
        UpdateOperations<CompanyInfo> ops = datastore.createUpdateOperations(CompanyInfo.class);

        if(StringUtils.isNotBlank(company.getPkCompanyInfo())){
            ops.set("pkCompanyInfo", company.getPkCompanyInfo());
        }
        company.setStatus(CompanyInfo.Status.TERMINATION);
        ops.set("status", company.getStatus());
        int count = datastore.update(datastore.find(CompanyInfo.class).field("pkCompanyInfo").equal(company.getPkCompanyInfo()),ops) .getUpdatedCount();
        return count + "";
    }

    @Override
    public CompanyInfo getCompanyInfo(CompanyInfo company) throws HorizonBizException {
        
        Query<CompanyInfo> query = datastore.find(CompanyInfo.class);
        if (StringUtils.isNotBlank(company.getCompanyName())) {
            query.field("companyName").equal(company.getCompanyName());
        }
        if (StringUtils.isNotBlank(company.getPkCompanyInfo())) {
            query.field("pkCompanyInfo").equal(company.getPkCompanyInfo());
        }
        if(query.count()>1){
            throw new HorizonBizException(Constants.Return.QUEYR_EXCEPTION);
        }
        return query.get();
    }

    @Override
    public int update(CompanyInfo company) {

        UpdateOperations<CompanyInfo> ops = datastore.createUpdateOperations(CompanyInfo.class);

        if(StringUtils.isNotBlank(company.getCompanyLicense())){
            ops.set("companyLicense", company.getCompanyLicense());
        }
        if(StringUtils.isNotBlank(company.getCompanyNo())){
            ops.set("companyNo", company.getCompanyNo());
        }
        if(StringUtils.isNotBlank(company.getLinkMan())){
            ops.set("linkMan", company.getLinkMan());
        }
        if(StringUtils.isNotBlank(company.getLinkPhone())){
            ops.set("linkPhone", company.getLinkPhone());
        }
        if(StringUtils.isNotBlank(company.getEmail())){
            ops.set("email", company.getEmail());
        }
        if(company.getCompanyName() != null){
            ops.set("companyName",company.getCompanyName());
        }
        if(company.getChainAddr() != null){
            ops.set("chainAddr",company.getChainAddr());
        }
        if(company.getStatus() != null){
            ops.set("status", company.getStatus());
        }
        if(company.getPkPeerSettingInfo() != null){
            ops.set("pkPeerSettingInfo", company.getPkPeerSettingInfo());
        }

        ops.set("updateDate", company.getUpdateDate());
        ops.set("updateManager", company.getUpdateManager());

        int count = datastore.update(datastore.find(CompanyInfo.class).field("pkCompanyInfo").equal(company.getPkCompanyInfo()),ops) .getUpdatedCount();

        return count;
    }

    @Override
    public String getComapnyName(List<String> keys) {
        StringBuffer result = new StringBuffer("");
        if (keys != null&&keys.size()>0) {
            keys.forEach(id->{
 
                CompanyInfo companyInfo = datastore.find(CompanyInfo.class).filter("pkCompanyInfo",id).get();
                if (companyInfo != null) {
                    result.append(companyInfo.getCompanyName()).append(",");
                }
            });
        }
        if (result.length()>0){
            return result.toString().substring(0,(result.toString().length()-1));
        }else{
            return result.toString();
        }
    }

    @Override
    public String getComapnyNameByKey(String key) {

        CompanyInfo companyInfo = datastore.find(CompanyInfo.class).filter("pkCompanyInfo",key).get();
        if (companyInfo == null) {
            return null;
        }else {
            return companyInfo.getCompanyName();
        }
        
    }

    @Override
    public void realDelete(String pkCompanyInfo) {
        WriteResult result=datastore.delete(datastore.find(CompanyInfo.class).field("pkCompanyInfo").equal(pkCompanyInfo));
    }

    @Override
    public List<CompanyInfoDto> findAllByKeys(List<String> keys) {
        List<CompanyInfoDto> result = new ArrayList<>();
        if (keys != null&&keys.size()>0) {
            keys.forEach(id->{

                CompanyInfo companyInfo = datastore.find(CompanyInfo.class).filter("pkCompanyInfo",id).get();
                if (companyInfo != null) {
                    result.add(new CompanyInfoDto(companyInfo));
                }
            });
        }
        return result;
    }

    public CompanyInfo uniqueCheck(CompanyInfo company){
        CompanyInfo companyInfo = new CompanyInfo();

        Query<CompanyInfo> query;

        if (StringUtils.isNotBlank(company.getCompanyName())) {
            query = datastore.find(CompanyInfo.class);
            query.field("companyName").equal(company.getCompanyName());
            if(StringUtils.isNotBlank(company.getPkCompanyInfo())) {
                query.field("pkCompanyInfo").notEqual(company.getPkCompanyInfo());
            }
            if (query.get() != null) {
               companyInfo.setCompanyName(query.get().getCompanyName());
               return companyInfo;
           }
        }

        if (StringUtils.isNotBlank(company.getCompanyLicense())) {
            query = datastore.find(CompanyInfo.class);
            query.field("companyLicense").equal(company.getCompanyLicense());
            if(StringUtils.isNotBlank(company.getPkCompanyInfo())) {
                query.field("pkCompanyInfo").notEqual(company.getPkCompanyInfo());
            }
            if (query.get() != null) {
                companyInfo.setCompanyLicense(query.get().getCompanyLicense());
                return companyInfo;
            }
        }

        if (StringUtils.isNotBlank(company.getCompanyNo())) {
            query = datastore.find(CompanyInfo.class);
            query.field("companyNo").equal(company.getCompanyNo());
            if(StringUtils.isNotBlank(company.getPkCompanyInfo())) {
                query.field("pkCompanyInfo").notEqual(company.getPkCompanyInfo());
            }
            if (query.get() != null) {
                companyInfo.setCompanyNo(query.get().getCompanyNo());
                return companyInfo;
            }
        }

        if (StringUtils.isNotBlank(company.getChainAddr())) {
            query = datastore.find(CompanyInfo.class);
            query.field("chainAddr").equal(company.getChainAddr());
            if(StringUtils.isNotBlank(company.getPkCompanyInfo())) {
                query.field("pkCompanyInfo").notEqual(company.getPkCompanyInfo());
            }
            if (query.get() != null) {
                companyInfo.setChainAddr(query.get().getChainAddr());
                return companyInfo;
            }
        }

        return companyInfo;
    }

    @Override
    public CompanyInfo getCompanyInfoByNo(String companyNo) {
        Query<CompanyInfo> query = datastore.find(CompanyInfo.class).field("companyNo").equal(companyNo);
        return query.get();
    }

    @Override
    public int updateFromChain(ChainCompanyInfo item) {
        //查找本地这条数据,没有返回null
        CompanyInfo companyInfo =  datastore.find(CompanyInfo.class).filter("pkCompanyInfo",item.getPkCompanyInfo()).get();
        if (companyInfo==null){
            companyInfo = new CompanyInfo();
            companyInfo.setPkCompanyInfo(item.getPkCompanyInfo());
        }
        companyInfo.setCompanyName(item.getCompanyName());
        companyInfo.setCompanyLicense(item.getCompanyLicense());
        companyInfo.setCompanyNo(item.getCompanyNo());
        companyInfo.setChainAddr(item.getChainAddr());
        companyInfo.setEmail(item.getEmail());
        companyInfo.setLinkMan(item.getLinkMan());
        companyInfo.setLinkPhone(item.getLinkPhone());
        companyInfo.setJoinType(item.getJoinType());
        companyInfo.setStatus(item.getStatus());
        companyInfo.setCompanyType(item.getCompanyType());
        companyInfo.setPkPeerSettingInfo(item.getPkPeerSettingInfo());



        int i=0;
        String id =save(companyInfo);
        if(StringUtils.isNotBlank(id)){
            i=1;
        }

        return i;
    }

    @Override
    public List<CompanyInfo> findAll(String pkCompanyInfo) {
        Query<CompanyInfo> query=datastore.find(CompanyInfo.class);
        return query.asList();
    }
}
