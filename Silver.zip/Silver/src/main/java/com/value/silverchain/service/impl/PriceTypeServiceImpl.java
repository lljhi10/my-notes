package com.value.silverchain.service.impl;


import com.value.silverchain.bo.PageBo;
import com.value.silverchain.common.Constants;
import com.value.silverchain.dto.ChainPriceTypeInfo;
import com.value.silverchain.dto.CompanyInfoDto;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.PriceTypeInfo;
import com.value.silverchain.service.IOrgInfoService;
import com.value.silverchain.service.IPriceTypeService;
import org.apache.commons.lang3.StringUtils;
import org.bson.types.ObjectId;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:01
 * DESC:
 */
@Service
public class PriceTypeServiceImpl implements IPriceTypeService {

    @Autowired
    private Datastore datastore;
    
    @Autowired
    private IOrgInfoService orgInfoService;


    @Override
    public String save(PriceTypeInfo apiTypeInfo) throws HorizonBizException {
        //查询接口类型名称是否已经被使用
        Query<PriceTypeInfo> query = datastore.find(PriceTypeInfo.class).filter("priceTypeName", apiTypeInfo.getPriceTypeName());
        PriceTypeInfo result  =query.get();
        if(null!=result){
            throw new HorizonBizException(Constants.Return.APITYPE_NAME_ALREADY_EXISTS);
        }
        Key<PriceTypeInfo> key = datastore.save(apiTypeInfo);
        return ((ObjectId) key.getId()).toHexString();
    }

    @Override
    public PriceTypeInfo getByKey(String pkPriceTypeInfo) {
        Query<PriceTypeInfo> query = datastore.find(PriceTypeInfo.class).filter("pkPriceTypeInfo", pkPriceTypeInfo);
        PriceTypeInfo apiTypeInfo =query.get();
        if (apiTypeInfo != null) {
            List<CompanyInfoDto> companyInfoList=orgInfoService.findAllByKeys(apiTypeInfo.getTargetCompany());
            apiTypeInfo.setCompanyInfoList(companyInfoList);
            apiTypeInfo.setTargetCompanyName(orgInfoService.getComapnyName(apiTypeInfo.getTargetCompany()));
        }
        return apiTypeInfo;
    }

    @Override
    public PageBo<PriceTypeInfo> findPage(PriceTypeInfo param) {
        Query<PriceTypeInfo> query = datastore.find(PriceTypeInfo.class);
        if(StringUtils.isNotBlank(param.getPriceTypeName())) {
            query.field("priceTypeName").contains(param.getPriceTypeName());
        }

        query.offset(param.getPageNo() * param.getPageSize() - param.getPageSize());
        query.limit(param.getPageSize());
        List<PriceTypeInfo> list =query.asList();
        if(list!=null&&list.size()>0){
           for (PriceTypeInfo item : list) {
               item.setCompanyInfoList(orgInfoService.findAllByKeys(item.getTargetCompany()));
               item.setTargetCompanyName(orgInfoService.getComapnyName(item.getTargetCompany()));
           }
        }
        return new PageBo(list,query.count());
    }

    @Override
    public List<PriceTypeInfo> findAll(String pkCompanyInfo) {
        Query<PriceTypeInfo> query = datastore.find(PriceTypeInfo.class);
        //公开的，或者指定商户中包含pkCompanyInfo的服务接口类型
        query.or(
                query.criteria("targetType").equal(PriceTypeInfo.TargetType.OPEN),
                query.and(
                        query.criteria("targetType").equal(PriceTypeInfo.TargetType.TARGET),
                        query.criteria("targetCompany").contains(pkCompanyInfo)
                )
        );
        return query.asList();
    }

    @Override
    public int updateFromChain(ChainPriceTypeInfo item) {

        //查找服务接口
        PriceTypeInfo apiTypeInfo = getByKey(item.getPkPriceTypeInfo());
        if (apiTypeInfo==null){
            apiTypeInfo=new PriceTypeInfo();
            apiTypeInfo.setPkPriceTypeInfo(item.getPkPriceTypeInfo());
        }

        apiTypeInfo.setPriceTypeName(item.getPriceTypeName());
        apiTypeInfo.setDescription(item.getDescription());
        apiTypeInfo.setTargetCompany(item.getTargetCompany());

        apiTypeInfo.setStatus(item.getStatus());
        apiTypeInfo.setTargetType(item.getTargetType());

        int i=0;
        try {
            String id =save(apiTypeInfo);
            if(StringUtils.isNotBlank(id)){
                i=1;
            }
        } catch (HorizonBizException e) {
            e.printStackTrace();

        }

        return i;
    }

}
