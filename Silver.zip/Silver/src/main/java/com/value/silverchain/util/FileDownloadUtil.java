package com.value.silverchain.util;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/8/1
 * DESC:文件下载工具
 * 
 */
public class FileDownloadUtil {
    /**
     *
     * 下载一个文件
     * @param pathUrl 需要下载的文件路径
     * @param name 下载后的文件名称
     * @return int 1：路径为空，2：文件不存在，0：下载成功
     * @throws IOException
     */
    public static int downloadFile(String pathUrl,String name)throws IOException{
        HttpServletResponse response = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getResponse();
        HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
        if (StringUtils.isBlank(pathUrl)) {
            //路径为空或空字符串
            return 1;
        }
        pathUrl=FilePathUtil.getRealFilePath(pathUrl);
        //获取项目部署路径 
        String projectPath = System.getProperty("user.dir");
        //下载文件的绝对路径
        String targetPath =projectPath+File.separator+pathUrl;
//        System.out.println("targetPath:"+targetPath);
        
        File file = new File(targetPath);
        if(!file.exists()){
            //文件不存在
            return 2;
        }
        if(StringUtils.isBlank(name)){
            name=pathUrl.substring(pathUrl.lastIndexOf(File.separator));
        }
        
        response.setContentType("text/html; charset=UTF-8"); //设置编码字符  
        response.setContentType("application/x-msdownload"); //设置内容类型为下载类型  
        response.setHeader("Content-disposition", "attachment;filename="+name);//设置下载的文件名称  
        BufferedOutputStream out = new BufferedOutputStream(response.getOutputStream());   //创建页面返回方式为输出流，会自动弹出下载框
        
        Date start = new Date();
        BufferedInputStream is = new BufferedInputStream(new FileInputStream(targetPath));  //创建文件输入流  
        byte[] Buffer = new byte[2048];  //设置每次读取数据大小，即缓存大小  
        int size = 0;  //用于计算缓存数据是否已经读取完毕，如果数据已经读取完了，则会返回-1  
        while((size=is.read(Buffer)) != -1){  //循环读取数据，如果数据读取完毕则返回-1  
            out.write(Buffer, 0, size); //将每次读取到的数据写入客户端  
        }
        //释放和关闭输入输出流  
        out.flush();  
        out.close();
        is.close(); 
        Date end = new Date();
//        System.out.println("文件大小："+file.length()/1024+"K，下载耗时："+DateHelper.formatMillisecondToString(end.getTime()-start.getTime(),0));
        return 0;
    }
}
