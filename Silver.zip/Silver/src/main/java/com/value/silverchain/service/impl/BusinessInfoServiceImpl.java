package com.value.silverchain.service.impl;


import com.value.silverchain.bo.PageBo;
import com.value.silverchain.dto.ChainAccountInfo;
import com.value.silverchain.model.AccountInfo;
import com.value.silverchain.model.CompanyInfo;
import com.value.silverchain.service.IBusinessInfoService;
import com.value.silverchain.service.IOrgInfoService;
import com.value.silverchain.util.DateHelper;
import org.apache.commons.lang3.StringUtils;
import org.bson.types.ObjectId;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.UpdateOperations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:01
 * DESC:
 */
@Service
public class BusinessInfoServiceImpl implements IBusinessInfoService {

    @Autowired
    private Datastore datastore;

    @Autowired
    private IOrgInfoService orgInfoService;

    @Override
    public String save(AccountInfo accountInfo) {
        Key<AccountInfo> key = datastore.save(accountInfo);
        return ((ObjectId) key.getId()).toHexString();
    }

    @Override
    public AccountInfo getAccountInfoByID(AccountInfo accountInfo) {
        Query<AccountInfo> query = datastore.find(AccountInfo.class).field("pkAccountInfo").equal(accountInfo.getPkAccountInfo()).filter("status !=",AccountInfo.Status.TERMINATION);;
        if (query.get().getPkCompanyInfo()!=null){
            query.get().setCompanyName(orgInfoService.getComapnyNameByKey(query.get().getPkCompanyInfo()));
        }
        return query.get();
    }

    @Override
    public PageBo<AccountInfo> findPage(AccountInfo accountInfo) {
        Query<AccountInfo> query = datastore.find(AccountInfo.class).filter("status !=",AccountInfo.Status.TERMINATION);

        //判断当前用户是否是UP
        CompanyInfo company = new CompanyInfo();
        company.setPkCompanyInfo(accountInfo.getPkCompanyInfo());
        company = orgInfoService.getCompanyInfoByID(company);
        if(company != null && !company.getCompanyType().equals(CompanyInfo.CompanyType.UP)) {
            query.field("pkCompanyInfo").equal(accountInfo.getPkCompanyInfo());
        }
        if(StringUtils.isNotBlank(accountInfo.getAccountName())) {
            query.field("accountName").contains(accountInfo.getAccountName());
        }
        query.order("-createDate");
        query.offset(accountInfo.getPageNo() * accountInfo.getPageSize() - accountInfo.getPageSize());
        query.limit(accountInfo.getPageSize());

        List<AccountInfo> list = query.asList();

        if(list!=null&&list.size()>0){
            list.forEach(item -> {
                if (item.getPkCompanyInfo()!=null){
                    item.setCompanyName(orgInfoService.getComapnyNameByKey(item.getPkCompanyInfo()));
                }
            });
        }
        return new PageBo(list,query.count());
    }

    @Override
    public int update(AccountInfo accountInfo) {
        UpdateOperations<AccountInfo> ops = datastore.createUpdateOperations(AccountInfo.class);

        if(accountInfo.getAccountName() != null){
            ops.set("accountName", accountInfo.getAccountName());
        }
        if(accountInfo.getSupportTradeType() != null){
            ops.set("supportTradeType", accountInfo.getSupportTradeType());
        }
//        if(StringUtils.isNotBlank(accountInfo.getOrgNo())){
//            ops.set("orgNo", accountInfo.getOrgNo());
//        }
        if(StringUtils.isNotBlank(accountInfo.getAccountNo())){
            ops.set("accountNo", accountInfo.getAccountNo());
        }
        if(accountInfo.getExpiryDate() != null){
            ops.set("expiryDate", accountInfo.getExpiryDate());
        }
        if(StringUtils.isNotBlank(accountInfo.getCardNo())){
            ops.set("cardNo", accountInfo.getCardNo());
        }
        if(StringUtils.isNotBlank(accountInfo.getCvn())){
            ops.set("cvn", accountInfo.getCvn());
        }
        ops.set("updateDate", accountInfo.getUpdateDate());
        ops.set("updateManager", accountInfo.getUpdateManager());

        int count = datastore.update(datastore.find(AccountInfo.class).field("pkAccountInfo").equal(accountInfo.getPkAccountInfo()),ops) .getUpdatedCount();

        return count;
    }

    @Override
    public AccountInfo getAccountInfoByName(AccountInfo accountInfo) {
        Query<AccountInfo> query = datastore.find(AccountInfo.class).field("accountName").equal(accountInfo.getAccountName()).filter("status !=",AccountInfo.Status.TERMINATION);;
        query.field("pkCompanyInfo").equal(accountInfo.getPkCompanyInfo());

        return query.get();
    }

    @Override
    public int updateFromChain(ChainAccountInfo item) {
        //查找本地这条数据,没有返回null
        AccountInfo accountInfo =  datastore.find(AccountInfo.class).filter("pkAccountInfo",item.getPkAccountInfo()).get();
        if (accountInfo==null){
            accountInfo=new AccountInfo();
            accountInfo.setPkAccountInfo(item.getPkAccountInfo());
        }

        accountInfo.setPkCompanyInfo( item.getPkCompanyInfo());
        accountInfo.setAccountName( item.getAccountName());
        accountInfo.setAccountNo( item.getAccountNo());
        accountInfo.setCardNo( item.getCardNo());
        accountInfo.setExpiryDate( item.getExpiryDate());
        accountInfo.setCvn( item.getCvn());
        accountInfo.setMobilePhone( item.getMobilePhone());
        accountInfo.setSupportTradeType( item.getSupportTradeType());
        accountInfo.setChainAddr( item.getChainAddr());
        accountInfo.setStatus( item.getStatus());



        int i=0;
        String id =save(accountInfo);
        if(StringUtils.isNotBlank(id)){
            i=1;
        }

        return i;
    }

    public AccountInfo uniqueCheck(AccountInfo accountInfo){
        AccountInfo account = new AccountInfo();

        Query<AccountInfo> query;

        if (StringUtils.isNotBlank(accountInfo.getAccountName())) {
            query = datastore.find(AccountInfo.class);
            query.field("accountName").equal(accountInfo.getAccountName());
            if(StringUtils.isNotBlank(accountInfo.getPkAccountInfo())) {
                query.field("pkAccountInfo").notEqual(accountInfo.getPkAccountInfo());
            }
            if (query.get() != null) {
                account.setAccountName(query.get().getAccountName());
                return account;
            }
        }

        if (StringUtils.isNotBlank(accountInfo.getChainAddr())) {
            query = datastore.find(AccountInfo.class);
            query.field("chainAddr").equal(accountInfo.getChainAddr());
            if(StringUtils.isNotBlank(accountInfo.getPkAccountInfo())) {
                query.field("pkAccountInfo").notEqual(accountInfo.getPkAccountInfo());
            }
            if (query.get() != null) {
                account.setChainAddr(query.get().getChainAddr());
                return account;
            }
        }

        if (StringUtils.isNotBlank(accountInfo.getAccountNo())) {
            query = datastore.find(AccountInfo.class);
            query.field("accountNo").equal(accountInfo.getAccountNo());
            if(StringUtils.isNotBlank(accountInfo.getPkAccountInfo())) {
                query.field("pkAccountInfo").notEqual(accountInfo.getPkAccountInfo());
            }
            if (query.get() != null) {
                account.setAccountNo(query.get().getAccountNo());
                return account;
            }
        }

        if (StringUtils.isNotBlank(accountInfo.getCardNo())) {
            query = datastore.find(AccountInfo.class);
            query.field("cardNo").equal(accountInfo.getCardNo());
            if(StringUtils.isNotBlank(accountInfo.getPkAccountInfo())) {
                query.field("pkAccountInfo").notEqual(accountInfo.getPkAccountInfo());
            }
            if (query.get() != null) {
                account.setCardNo(query.get().getCardNo());
                return account;
            }
        }
        return account;
    }

    @Override
    public AccountInfo getAccountInfoByCompany(String pkCompanyInfo, AccountInfo.SupportTradeType supportTradeType) {
        Query<AccountInfo> query = datastore.find(AccountInfo.class);
        query.field("pkCompanyInfo").equal(pkCompanyInfo)
                .field("supportTradeType").equal(supportTradeType)
                .field("status").equal(AccountInfo.Status.NORMAL)
                .field("expiryDate").greaterThanOrEq(DateHelper.getStartDate(new Date()));
        return query.get();
    }
}
