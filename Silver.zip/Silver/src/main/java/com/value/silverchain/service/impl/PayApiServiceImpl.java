package com.value.silverchain.service.impl;


import com.value.silverchain.bo.PageBo;
import com.value.silverchain.common.Constants;
import com.value.silverchain.dto.ChainPayApiInfo;
import com.value.silverchain.dto.CompanyInfoDto;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.ManagerInfo;
import com.value.silverchain.model.PayApiInfo;
import com.value.silverchain.service.IApiTypeService;
import com.value.silverchain.service.IOrgInfoService;
import com.value.silverchain.service.IPayApiService;
import com.value.silverchain.service.IPriceTypeService;
import org.apache.commons.lang3.StringUtils;
import org.bson.types.ObjectId;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:01
 * DESC:
 */
@Service
public class PayApiServiceImpl implements IPayApiService {

    @Autowired
    private Datastore datastore;
    
    @Autowired
    private IOrgInfoService orgInfoService;
    @Autowired
    private IApiTypeService apiTypeService;
    @Autowired
    private IPriceTypeService priceTypeService;


    @Override
    public String save(PayApiInfo payApiInfo) throws HorizonBizException {

        Key<PayApiInfo> key = datastore.save(payApiInfo);
        return ((ObjectId) key.getId()).toHexString();
    }

    @Override
    public PayApiInfo getByKey(String pkPayApiInfo) {
        Query<PayApiInfo> query = datastore.find(PayApiInfo.class).filter("pkPayApiInfo", pkPayApiInfo);
        PayApiInfo payApiInfo =query.get();
        if (payApiInfo != null) {
            List<CompanyInfoDto> companyInfoList=orgInfoService.findAllByKeys(payApiInfo.getTargetCompany());
            payApiInfo.setCompanyInfoList(companyInfoList);
            payApiInfo.setTargetCompanyName(orgInfoService.getComapnyName(payApiInfo.getTargetCompany()));
            payApiInfo.setApiTypeInfo(apiTypeService.getByKey(payApiInfo.getPkApiTypeInfo()));
            payApiInfo.setPriceTypeInfo(priceTypeService.getByKey(payApiInfo.getPkPriceTypeInfo()));
        }
        return payApiInfo;
    }

    @Override
    public PageBo<PayApiInfo> findPage(PayApiInfo param) {
        Query<PayApiInfo> query = datastore.find(PayApiInfo.class);
        if(StringUtils.isNotBlank(param.getApiName())) {
            query.field("apiName").contains(param.getApiName());
        }
        /*=========================================================*/

        if(param.getPkCompanyInfo()!=null) {
            //非UP管理员，只看有效的，公开的接口和目标商户包含登录者所在商户的接口
            Date date = new Date();
            query.field("startDate").lessThanOrEq(date).field("endDate").greaterThanOrEq(date);
            query.field("publish").equal(PayApiInfo.Publish.EFFICIENT).field("status").equal(PayApiInfo.Status.NORMAL);
            query.or(query.criteria("targetType").equal(PayApiInfo.TargetType.OPEN),//公开
                    query.criteria("targetCompany").contains(param.getPkCompanyInfo()));//目标商户包含登录者所在商户
        }
        /*=========================================================*/
        query.offset(param.getPageNo() * param.getPageSize() - param.getPageSize());
        query.limit(param.getPageSize());
        List<PayApiInfo> list =query.asList();
        if(list!=null&&list.size()>0){
           for (PayApiInfo item : list) {
               item.setCompanyInfoList(orgInfoService.findAllByKeys(item.getTargetCompany()));
               item.setApiTypeInfo(apiTypeService.getByKey(item.getPkApiTypeInfo()));
               item.setPriceTypeInfo(priceTypeService.getByKey(item.getPkPriceTypeInfo()));
           }
        }
        return new PageBo(list,query.count());
    }

    @Override
    public String delete(String pkPayApiInfo, ManagerInfo loginUser) throws HorizonBizException {
        PayApiInfo targetInfo = getByKey(pkPayApiInfo);
        if (targetInfo == null) {
            throw new HorizonBizException(Constants.Return.FIND_PAY_API_INFO_FALSE);
        }
        if (targetInfo.getStatus().equals(PayApiInfo.Status.TERMINATION)){
            //已经终止的服务接口不能删除
            throw new HorizonBizException(Constants.Return.PAY_API_INFO_TERMINATION);
        }
        if (!targetInfo.getPkCompanyInfo().equals(loginUser.getPkCompanyInfo())){
            //不是登录者所在商户的服务接口不能删除
            throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
        }
        targetInfo.setStatus(PayApiInfo.Status.TERMINATION);
        targetInfo.setUpdateDate(new Date());
        targetInfo.setUpdateManager(loginUser.getPkManagerInfo());
//        datastore.delete(datastore.find(PayApiInfo.class).field("pkPayApiInfo").equal(pkPayApiInfo));
        return save(targetInfo);
    }

    @Override
    public String update(PayApiInfo payApiInfo, ManagerInfo loginUser) throws HorizonBizException, ParseException {
        //查找服务接口
        PayApiInfo targetInfo = getByKey(payApiInfo.getPkPayApiInfo());
        if (targetInfo == null) {
            throw new HorizonBizException(Constants.Return.FIND_PAY_API_INFO_FALSE);
        }
        if (targetInfo.getStatus().equals(PayApiInfo.Status.TERMINATION)){
            //已经终止的服务接口不能修改
            throw new HorizonBizException(Constants.Return.PAY_API_INFO_TERMINATION);
        }
        if (!targetInfo.getPkCompanyInfo().equals(loginUser.getPkCompanyInfo())){
            //不是登录者所在商户的服务接口不能修改
            throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
        }
        Date date = new Date();
        if (payApiInfo.getPkApiTypeInfo()!=null) {
            targetInfo.setPkApiTypeInfo( payApiInfo.getPkApiTypeInfo());
        }
        if (payApiInfo.getApiName()!=null) {
            targetInfo.setApiName(payApiInfo.getApiName());
        }
        if (payApiInfo.getTargetCompany()!=null) {
            targetInfo.setTargetCompany(payApiInfo.getTargetCompany());
        }
        if (payApiInfo.getCostRate()!=null) {
            targetInfo.setCostRate(payApiInfo.getCostRate());
        }
        if (payApiInfo.getServicePay()!=null) {
            targetInfo.setServicePay( payApiInfo.getServicePay());
        }
        if (payApiInfo.getSmartPay()!=null) {
            targetInfo.setSmartPay(payApiInfo.getSmartPay());
        }

        if (payApiInfo.getApiDescription()!=null) {
            targetInfo.setApiDescription(payApiInfo.getApiDescription());
        }
        if (payApiInfo.getStartDate()!=null) {
            targetInfo.setStartDate(payApiInfo.getStartDate());
        }
        targetInfo.setEndDate(payApiInfo.getEndDate());
        targetInfo.setStatus(payApiInfo.getStatus());

            targetInfo.setUpdateDate( date);
        if (payApiInfo.getUpdateManager()!=null) {
            targetInfo.setUpdateManager(payApiInfo.getUpdateManager());
        }
        //如果选择发布则添加
        if(targetInfo.getPublish().equals(PayApiInfo.Publish.UNPUBLISH)&&payApiInfo.getPublish().equals(PayApiInfo.Publish.EFFICIENT)){
//            if(DateUtils.parseDate(DateFormatUtils.format(payApiInfo.getStartDate(),"yyyy-mm-dd")).before(DateUtils.parseDate(DateFormatUtils.format(new Date(),"yyyy-mm-dd")))){
//                //开始时间小于当前时间
//                throw new HorizonBizException(Constants.Return.START_DATE_LESS_THEM_CURRENT);
//            }
            if(payApiInfo.getEndDate().getTime() <= new Date().getTime()){
                //有效期结束时间小于当前时间
                throw new HorizonBizException(Constants.Return.END_DATE_LESS_THEM_CURRENT);
            }
            //做唯一性检查，保证同一接口类型，同一目标商户(公开看成是一种商户)，同一时间段内正常的生效的支付接口记录只有一条
            checkUniqueness(payApiInfo);
            targetInfo.setPublish(payApiInfo.getPublish());
            targetInfo.setPublishDate(date);
        }

        
        return save(targetInfo);
    }

    @Override
    public Float getRate(PayApiInfo param) throws HorizonBizException {
        Float costRate=0F;
        PayApiInfo payApiInfo=getPayApiInfo(param);

        if (param.getPayType().equals(PayApiInfo.PayType.SERVICE)){
            //查服务发布方支付费率
            if(payApiInfo.getServicePay().equals(PayApiInfo.Payer.CHECKED)){
                costRate=payApiInfo.getCostRate();
            }
        }else{
            //查智能应用发布方支付费率
            if (payApiInfo.getSmartPay().equals(PayApiInfo.Payer.CHECKED)){
                costRate=payApiInfo.getCostRate();
            }
        }
        return costRate;
    }

    @Override
    public int updateFromChain(ChainPayApiInfo item) {

        //查找服务接口
        PayApiInfo targetInfo = getByKey(item.getPkPayApiInfo());
        if (targetInfo==null){
            targetInfo=new PayApiInfo();
            targetInfo.setPkPayApiInfo(item.getPkPayApiInfo());
        }

        targetInfo.setPkApiTypeInfo( item.getPkApiTypeInfo());
        targetInfo.setApiName(item.getApiName());
        targetInfo.setTargetCompany(item.getTargetCompany());
        targetInfo.setCostRate(item.getCostRate());
        targetInfo.setServicePay( item.getServicePay());
        targetInfo.setSmartPay(item.getSmartPay());

        targetInfo.setApiDescription(item.getApiDescription());
        targetInfo.setStartDate(item.getStartDate());
        targetInfo.setEndDate(item.getEndDate());
        targetInfo.setStatus(item.getStatus());
        targetInfo.setPkCompanyInfo(item.getPkCompanyInfo());
        targetInfo.setPublishDate(item.getPublishDate());
        targetInfo.setTargetType(item.getTargetType());
        targetInfo.setPublish(item.getPublish());
        int i=0;
        try {
            String id =save(targetInfo);
            if(StringUtils.isNotBlank(id)){
                i=1;
            }
        } catch (HorizonBizException e) {
            e.printStackTrace();

        }

        return i;
    }

    @Override
    public PayApiInfo getPayApiInfo(PayApiInfo param) throws HorizonBizException {
        PayApiInfo payApiInfo;
        param.setStatus(PayApiInfo.Status.NORMAL);
        param.setPublish(PayApiInfo.Publish.EFFICIENT);
        Query<PayApiInfo> query = initQuery(param);
        //时间在有效期之内
        Date date = param.getStartDate()==null?new Date():param.getStartDate();
        query.field("startDate").lessThanOrEq(date).field("endDate").greaterThanOrEq(date);
        List<PayApiInfo> list =query.asList();
        if(list==null||list.size()==0){
            //如果没有找到记录，查询公开接口
            param.setTargetCompany(null);
            query = initQuery(param);
            query.field("startDate").lessThanOrEq(date).field("endDate").greaterThanOrEq(date);
            query.field("targetCompany").equal(null);
            list =query.asList();
        }

        if (list==null||list.size()<=0){
            //没找到记录
            throw new HorizonBizException(Constants.Return.COST_RATE_UNFIND);
        }else if(list.size()==1){
            payApiInfo=list.get(0);
        }else {
            //查到多条记录
            throw new HorizonBizException(Constants.Return.MULTI_COST_RATE_FIND);
        }
        return payApiInfo;
    }

    private Query<PayApiInfo> initQuery(PayApiInfo param) {
        Query<PayApiInfo> query = datastore.find(PayApiInfo.class);

        if(param.getPkApiTypeInfo()!=null){
            query.field("pkApiTypeInfo").equal(param.getPkApiTypeInfo());
        }
        if(StringUtils.isNotBlank(param.getApiName())){
            query.field("apiName").equal(param.getApiName());
        }
        if(param.getTargetCompany()!=null&&param.getTargetCompany().size()>0){
            query.field("targetCompany").contains(param.getTargetCompany().get(0));
        }
        if (param.getTargetType()!=null){
            query.field("targetType").equal(param.getTargetType());
        }
        if(param.getCostRate()!=null){
            query.field("costRate").equal(param.getCostRate());
        }
        if(param.getServicePay()!=null){
            query.field("servicePay").equal(param.getServicePay());
        }
        if(param.getSmartPay()!=null){
            query.field("smartPay").equal(param.getSmartPay());
        }
//        if(param.getStartDate() != null){
//            query.field("startDate").equal(param.getStartDate());
//        }
//        if(param.getEndDate() != null){
//            query.field("endDate").equal(param.getEndDate());
//        }
        if (StringUtils.isNotBlank(param.getApiDescription())){
            query.field("apiDescription").contains(param.getApiDescription());
        }
        if (param.getStatus()!=null){
            query.field("status").equal(param.getStatus());
        }
        if (param.getPublish()!=null){
            query.field("publish").equal(param.getPublish());
        }
        return  query;
    }


    @Override
    public void checkUniqueness(PayApiInfo param) throws HorizonBizException {
//        List<PayApiInfo> payApiInfoList=new ArrayList<>();
        Query<PayApiInfo> query = initQuery2(param);
        if (param.getTargetType().equals(PayApiInfo.TargetType.OPEN)) {
            //公开
            query.field("targetCompany").equal(null);
        }else{
            //指定
            query.field("targetCompany").hasAnyOf(param.getTargetCompany());
        }
//        payApiInfoList=query.asList();
//        throw new HorizonBizException(Constants.Return.PEER_UNFOUND_ERROR);
        if (query.count()>0) {
            throw new HorizonBizException(Constants.Return.PAY_API_INFO_HAS_EFFICIENT);
        }
    }
    private Query<PayApiInfo> initQuery2(PayApiInfo param) {
        Query<PayApiInfo> query = datastore.find(PayApiInfo.class);
        query.field("pkApiTypeInfo").equal(param.getPkApiTypeInfo());
        query.field("status").equal(PayApiInfo.Status.NORMAL);
        query.field("publish").equal(PayApiInfo.Publish.EFFICIENT);
        query.field("targetType").equal(param.getTargetType());
        query.or(query.and(query.criteria("startDate").lessThanOrEq(param.getStartDate()),query.criteria("endDate").greaterThanOrEq(param.getEndDate())),//startDate<=start and endDate>=end 新建有效期被已有包含
                query.and(query.criteria("startDate").greaterThanOrEq(param.getStartDate()),query.criteria("endDate").lessThanOrEq(param.getEndDate())),//startDate>=start and endDate<=end 新建有效期包含已有
                query.and(query.criteria("startDate").lessThan(param.getEndDate()),query.criteria("endDate").greaterThanOrEq(param.getEndDate())),//startDate<end and endDate>=end 新建的有效期结束时间在已有的期间
                query.and(query.criteria("startDate").lessThanOrEq(param.getStartDate()),query.criteria("endDate").greaterThan(param.getStartDate()))//startDate<=start and endDate>start 新建的有效期开始时间在已有的期间
        );
        
        return  query;
    }
}
