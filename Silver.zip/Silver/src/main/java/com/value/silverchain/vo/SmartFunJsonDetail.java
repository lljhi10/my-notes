package com.value.silverchain.vo;

import lombok.Data;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/6/11
 * DESC:智能合约-方法解释类
 */
@Data
public class SmartFunJsonDetail {
    public enum MethodTyep {
        GET("GET"), POST("POST"), POSTJSON("POSTJSON");
        private String name;

        MethodTyep(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    private String urlPath;//api路径
    private MethodTyep methodType;//调用方式：GET/POST/POSTJSON
    private List<String> params;//参数名称列表
    private String returnName;//方法返回值名称
}

