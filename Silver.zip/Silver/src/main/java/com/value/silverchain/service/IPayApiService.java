package com.value.silverchain.service;

import com.value.silverchain.bo.PageBo;
import com.value.silverchain.dto.ChainPayApiInfo;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.ManagerInfo;
import com.value.silverchain.model.PayApiInfo;

import java.text.ParseException;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:00
 * DESC:
 */
public interface IPayApiService {

    /**
     * 保存
     * @param payApiInfo
     * @return
     */
    String save(PayApiInfo payApiInfo) throws HorizonBizException;

    /**
     * 根据主键查询
     * @param pkPayApiInfo
     * @return
     */
    PayApiInfo getByKey(String pkPayApiInfo);

    /**
     * 分页查询
     * @param param
     * @return
     */
    PageBo<PayApiInfo> findPage(PayApiInfo param);

    /**
     * 根据主键删除
     * @param id
     * @param pkManagerInfo
     */
    String delete(String id, ManagerInfo pkManagerInfo) throws HorizonBizException;

    /**
     * 更新
     * @param param
     * @param loginUser
     * @return
     */
    String update(PayApiInfo param, ManagerInfo loginUser) throws HorizonBizException, ParseException;

    /**
     * 查费率
     * @param parma
     * @return
     */
    Float getRate(PayApiInfo parma) throws HorizonBizException;
    

    /**
     * 做唯一性检查，保证同一接口类型，同一目标商户(公开看成是一种商户)，同一时间段内正常的生效的支付接口记录只有一条
     * @param payApiInfo
     * @throws HorizonBizException
     */
    void checkUniqueness(PayApiInfo payApiInfo)throws HorizonBizException;

    /**
     * 根据条件，查询支付服务接口信息
     * @param payApiInfo
     * @return
     */
    PayApiInfo getPayApiInfo(PayApiInfo payApiInfo) throws HorizonBizException;

    int updateFromChain(ChainPayApiInfo item);
}
