package com.value.silverchain.service.impl;


import com.value.silverchain.bo.PageBo;
import com.value.silverchain.common.Constants;
import com.value.silverchain.dto.ChainApiTypeInfo;
import com.value.silverchain.dto.CompanyInfoDto;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.ApiTypeInfo;
import com.value.silverchain.service.IApiTypeService;
import com.value.silverchain.service.IOrgInfoService;
import org.apache.commons.lang3.StringUtils;
import org.bson.types.ObjectId;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:01
 * DESC:
 */
@Service
public class ApiTypeServiceImpl implements IApiTypeService {

    @Autowired
    private Datastore datastore;
    
    @Autowired
    private IOrgInfoService orgInfoService;


    @Override
    public String save(ApiTypeInfo apiTypeInfo) throws HorizonBizException {
        //查询接口类型名称是否已经被使用
        Query<ApiTypeInfo> query = datastore.find(ApiTypeInfo.class).filter("apiTypeName", apiTypeInfo.getApiTypeName());
        ApiTypeInfo result  =query.get();
        if(null!=result){
            throw new HorizonBizException(Constants.Return.APITYPE_NAME_ALREADY_EXISTS);
        }
        Key<ApiTypeInfo> key = datastore.save(apiTypeInfo);
        return ((ObjectId) key.getId()).toHexString();
    }

    @Override
    public ApiTypeInfo getByKey(String pkApiTypeInfo) {
        Query<ApiTypeInfo> query = datastore.find(ApiTypeInfo.class).filter("pkApiTypeInfo", pkApiTypeInfo);
        ApiTypeInfo apiTypeInfo =query.get();
        if (apiTypeInfo != null) {
            List<CompanyInfoDto> companyInfoList=orgInfoService.findAllByKeys(apiTypeInfo.getTargetCompany());
            apiTypeInfo.setCompanyInfoList(companyInfoList);
            apiTypeInfo.setTargetCompanyName(orgInfoService.getComapnyName(apiTypeInfo.getTargetCompany()));
        }
        return apiTypeInfo;
    }

    @Override
    public PageBo<ApiTypeInfo> findPage(ApiTypeInfo param) {
        Query<ApiTypeInfo> query = datastore.find(ApiTypeInfo.class);
        if(StringUtils.isNotBlank(param.getApiTypeName())) {
            query.field("apiTypeName").contains(param.getApiTypeName());
        }

        query.offset(param.getPageNo() * param.getPageSize() - param.getPageSize());
        query.limit(param.getPageSize());
        List<ApiTypeInfo> list =query.asList();
        if(list!=null&&list.size()>0){
           for (ApiTypeInfo item : list) {
               item.setCompanyInfoList(orgInfoService.findAllByKeys(item.getTargetCompany()));
               item.setTargetCompanyName(orgInfoService.getComapnyName(item.getTargetCompany()));
           }
        }
        return new PageBo(list,query.count());
    }

    @Override
    public List<ApiTypeInfo> findAll(String pkCompanyInfo) {
        Query<ApiTypeInfo> query = datastore.find(ApiTypeInfo.class);
        //公开的，或者指定商户中包含pkCompanyInfo的服务接口类型
        query.or(
                query.criteria("targetType").equal(ApiTypeInfo.TargetType.OPEN),
                query.and(
                        query.criteria("targetType").equal(ApiTypeInfo.TargetType.TARGET),
                        query.criteria("targetCompany").contains(pkCompanyInfo)
                )
        );
        return query.asList();
    }

    @Override
    public int updateFromChain(ChainApiTypeInfo item) {

        //查找服务接口
        ApiTypeInfo apiTypeInfo = getByKey(item.getPkApiTypeInfo());
        if (apiTypeInfo==null){
            apiTypeInfo=new ApiTypeInfo();
            apiTypeInfo.setPkApiTypeInfo(item.getPkApiTypeInfo());
        }

        apiTypeInfo.setApiTypeName(item.getApiTypeName());
        apiTypeInfo.setDescription(item.getDescription());
        apiTypeInfo.setTargetCompany(item.getTargetCompany());

        apiTypeInfo.setStatus(item.getStatus());
        apiTypeInfo.setTargetType(item.getTargetType());

        int i=0;
        try {
            String id =save(apiTypeInfo);
            if(StringUtils.isNotBlank(id)){
                i=1;
            }
        } catch (HorizonBizException e) {
            e.printStackTrace();

        }

        return i;
    }

}
