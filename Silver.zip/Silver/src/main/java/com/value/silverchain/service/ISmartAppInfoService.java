package com.value.silverchain.service;

import com.value.silverchain.bo.PageBo;
import com.value.silverchain.dto.ChainSmartAppInfo;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.SmartAppInfo;

/**
 * 智能应用
 */
public interface ISmartAppInfoService {

    /**
     * 保存
     * @param smartAppInfo
     * @return
     */
    String save(SmartAppInfo smartAppInfo);

    /**
     * 按主键取
     * @param smartAppInfo
     * @return
     */
    SmartAppInfo getSmartAppInfoByID(SmartAppInfo smartAppInfo);

    /**
     * 按名称取
     * @param smartAppInfo
     * @return
     */
    PageBo<SmartAppInfo> findPage(SmartAppInfo smartAppInfo);

    /**
     * 逻辑删除
     * @param smartAppInfo
     * @return
     */
    int delete(SmartAppInfo smartAppInfo);

    /**
     * 审核智能应用
     * @param smartAppInfo
     * @return
     */
    int verify(SmartAppInfo smartAppInfo);

    /**
     * 按名称查找智能应用
     * @param smartAppInfo
     * @return
     */
    SmartAppInfo getSmartAppInfoByName(SmartAppInfo smartAppInfo);

    /**
     * 更新
     * @param smartAppInfo
     * @return
     */
    int update(SmartAppInfo smartAppInfo);

    /**
     * 检查名称是否已经被使用
     *
     * @param smartAppName
     * @param pkSmartAppInfo
     * @return
     */
    boolean checkSmartAppNameRepeat(String smartAppName, String pkSmartAppInfo);

    /**
     * 根据AID查询智能合约
     * @param aid
     * @param apiType
     * @return
     */
    SmartAppInfo getSmartAppInfoByAid(String aid,  String apiType) throws HorizonBizException;

    /**
     * 查询AID是否被其他商户使用
     * @param aid
     * @param pkCompanyInfo
     * @return
     */
    boolean checkAidUsed(String aid, String pkCompanyInfo);

    /**
     * 检查唯一性，保证同一个aid，
     * @param smartAppInfo
     */
    void checkUniqueness(SmartAppInfo smartAppInfo) throws HorizonBizException;

    int updateFromChain(ChainSmartAppInfo item);
}
