package com.value.silverchain.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Id;
import org.mongodb.morphia.annotations.Indexed;
import org.mongodb.morphia.annotations.Transient;
import org.mongodb.morphia.utils.IndexDirection;

import java.util.Date;

/**
 * 商户信息
 */
@Entity("company_info")
@Data
public class CompanyInfo extends BasePage{
    public enum Status {
        NORMAL("正常"), PAUSE("暂停"), TERMINATION("终止");
        private String name;
        Status(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum JoinType {
        NORMAL("银联节点"), PAUSE("自建节点");
        private String name;
        JoinType(String name){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum CompanyType {
        UP("银联"), OTHER("其他商户");
        private String name;
        CompanyType(String name){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum FindType {
        ALL("查找所有");
        private String name;
        FindType(String name){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    @Id
    @JsonIgnore
    private ObjectId id;
    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_pkCompanyInfo",dropDups = true)
    private String pkCompanyInfo;//商户主键
    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_companyName",dropDups = true)
    private String companyName;//商户名称
//    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_companyLicense",dropDups = true)
    private String companyLicense;//商户营业执照号码
    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_companyNo",dropDups = true)
    private String companyNo;//商户号
//    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_companyChainAddr",dropDups = true)
    private String chainAddr;//商户区域链地址

    private String linkMan;//联系人

    private String linkPhone;//联系电话

    private String email;//联系邮箱

    private JoinType joinType;//入网方式：银联节点，自建节点

    private Status status;//商户状态：正常，暂停， 终止
    
    private CompanyType companyType;//商户类型：UP/其他商户

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createDate;//创建时间

    private String createManager;//创建人

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateDate;//最后更新时间

    private String updateManager;//最后更新人
    
    private String pkPeerSettingInfo;//商户注册节点主键
    @Transient
    private FindType findType;

   public void setSid(String sid) {
       this.pkCompanyInfo = sid;
   }
}