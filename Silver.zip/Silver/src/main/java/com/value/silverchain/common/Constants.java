package com.value.silverchain.common;

/**
 * Created by za-xiezhigang on 2017/5/9.
 */
public class Constants {

    public static final String ZHONGAN_ROOT_ACCOUNT = "ZHONGAN_ROOT_ACCOUNT";

    public static final String NONCE_TOO_LOW = "Nonce too low";

    public static final String GENERAL_PWD = "123456";

    public static final String MOCK_SECRET = "4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b";

    public static final String ROOT_ACCOUNT = "ROOT_ACCOUNT";

    public static final String FINISH_ACCOUNT = "FINISH_ACCOUNT";

    public static final String DEFAULT_PACKAGE = "com.value.silverchain.model";

    public static final String DUFAULT_DB_NAME = "value-silverchain";

//    /**上链成功code*/
//    public static final String CHAIN_INVOKE_SUCCESS="130000";
//    /**下链成功code*/
//    public static final String CHAIN_QUERY_SUCCESS="000000";
    /**
     * 商户在银链上的KEY
     */
    /**
     * UP商户信息专用key
     */
    public static final String CHAIN_KEY_UP_COMPANY_INFO = "silverchain_up_company_info";
    public static final String CHAIN_UPDATE_INFO_SUFFIX = "update_time";
    public static final String CHAIN_KEY_COMPANY_INFO = "silverchain_company_info";

    public static final String CHAIN_KEY_ACCOUNT_INFO = "silverchain_account_info";

    public static final String CHAIN_KEY_PEERSETTING_INFO = "silverchain_peersetting_info";
    public static final String CHAIN_KEY_SERVICEAPI_INFO = "silverchain_serviceapi_info";
    public static final String CHAIN_KEY_API_TYPE_INFO = "silverchain_api_type_info";
    public static final String CHAIN_KEY_PRICE_TYPE_INFO = "silverchain_price_type_info";
    public static final String CHAIN_KEY_PAYAPI_INFO = "silverchain_payapi_info";
    public static final String CHAIN_KEY_SMARTAPI_INFO = "silverchain_smartapi_info";
    public static final String REGULAR_EMAIL = "^[a-zA-Z0-9_\\.-]+@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*\\.[a-zA-Z0-9]{2,6}$";

    public static final String REGULAR_IP = "^((25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d)))\\.){3}(25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d)))$";

//	/*
//     * 通信码枚举
//     */
//    public enum Response {
//        SUCCESS("0", "请求成功"),
//        PARAM_ERR("1", "参数不正确"),
//        EXCEPTION("2", "系统异常"),
//        SERVICE_NOT_FOUND("3", "服务不存在"),
//        ANN_COIN_FATAL_ERROR("4", "安链异常")
//        ;
//
//        private String code;
//        private String msg;
//
//        Response(String code, String msg) {
//            this.code = code;
//            this.msg = msg;
//        }
//
//        public String getMsg() {
//            return msg;
//        }
//
//
//        public Integer getCode() {
//            return Integer.parseInt(code) ;
//        }
//    }


    /**
     * 返回码枚举
     * 00开头是通用信息
     * 01开头是登录模块
     * 10开头是商户信息管理模块
     * 11开头是业务账号管理模块
     * 12开头是节点管理模块
     * 13开头是支付服务接口管理
     * 14开头是服务接口管理
     * 15开头是智能应用管理
     * 16开头是交易流水
     * 17开头是用户管理
     * 18开头是角色管理
     * 19开头是智能应用调用
     * 20开头是系统初始化
     * 21开头是区块链调用模块
     * 22开头是数据库模块
     * 23开头是银联中间件节点
     * 24开头是文件下载
     * 25开头是远程访问测试
     * 26开头，是服务接口类型返回
     * 27开头，是价格类型返回
     */
    public enum Return {

        SUCCESS("000000", "操作成功"),
        UNSUCCESS("000001", "操作失败"),
        QUEYR_EXCEPTION("000002", "查询异常"),
        UPDATE_EXCEPTION("000003", "更新异常"),
        START_DATE_GREATER_THEM_END_DATE("000004", "开始时间大于结束时间"),
        TIGTH_LESS_THAN("000005", "权限不足"),
        END_DATE_LESS_THEM_CURRENT("000006", "结束时间小于当前时间"),
        SYSTEM_ERR("000007", "系统错误!"),
        PARAM_ERR("000008", "参数错误!"),
        RAS_ERR("000009", "远程访问服务失败!"),





        USER_LOGIN_FAIL("010001", "登录失败"),
        PASSWORD_NOTTRUE("010002", "重置密码错误：原密码错误!"),
        USER_NOT_LOGIN("010003", "用户未登录"),
        PASSWORD_ERR("010004", "密码必须在6-18位字符之间,不能为空"),

        COMPNAY_UNFOUND_ERROR("100001", "查询商户信息失败"),
        COMPANY_NAME_NULL("100002", "参数错误:商户名称不能为空"),
        COMPANYLICENSE_NULL("100003", "参数错误:商户营业执照不能为空"),
        COMPANYNO_NULL("100004", "参数错误:商户号不能为空"),
        LINKMAN_NULL("100005", "参数错误:联系人不能为空"),
        LINKPHONE_NULL("100006", "参数错误:联系电话不能为空"),
        EMAIL_ERR("100007", "参数错误:邮箱地址不合法"),
        COMPANYNAME_EXISTS("100008", "参数错误:该商户名已经存在"),
        COMPANYLICENSE_EXISTS("100009", "参数错误:该商户营业执照号码已经存在"),
        COMPANYNO_EXISTS("100010", "参数错误:该商户号已经存在"),
        CHAINADDR_EXISTS("100011", "参数错误:该区块链地址已经存在"),


        CREATE_BUSINESS_INFO_FALSE("110001", "创建业务账号失败"),
        EDIT_BUSINESS_INFO_FALSE("110002", "更新业务账号失败"),
        ACCOUNTNAME_NULL("110003", "参数错误: 业务账户名称不能为空"),
        SUPPORTTRADETYPE_NULL("110004", "参数错误: 业务账户类型不能为空"),
        CHAINADDR_NULL("110005", "参数错误: 区块链地址不能为空"),
        ACCOUNTNO_NULL("110006", "参数错误: 银行账号为空"),
        EXPIRYDATE_NULL("110007", "参数错误: 有效期不能为空"),
        CARDNO_NULL("110008", "参数错误: 卡号不能为空"),
        CVN_NULL("110009", "参数错误: cvn不能为空"),
        PKACCONTINFO_NULL("110010", "参数错误: 业务账户主键不能为空"),
        ACCOUNTNAME_EXISTS("110011", "参数错误: 业务账户名称重复"),
        ACCOUNTNO_EXISTS("110012", "参数错误: 银行账号重复"),
        CARDNO_EXISTS("110013", "参数错误: 银行卡号名称重复"),
        EXPIRYDATE_ERR("110014", "参数错误: 有效期不能小于当前系统日期"),
        PKCOMPANY_OUTOFRANGE("110015", "参数错误: 管理员只能修改所属商户下的信息"),
        ACCOUNT_NULL("110016", "参数错误: 该业务账号不存在"),


        LOCAL_PREE_NOT_EXISTS("120001", "未创建本地节点"),
        MULTI_LOCAL_PREE_EXISTS("120002", "存在多个本地节点"),
        PEER_UNFOUND_ERROR("120003", "查询节点信息失败"),
        PEERSETTINGNAME_NULL("120004", "参数错误:节点名称不能为空"),
        IP_NULL("120005", "参数错误:节点ip地址不能为空"),
        PKCOMPANYINFO_NULL("120006", "参数错误:商户主键不能为空"),
        PUBLISHED_INTERFACE_AUTH_NULL("120007", "参数错误:服务接口发布权限不能为空"),
        SMARTAPPAUTH_NULL("120008", "参数错误:智能应用管理权限不能为空"),
        AGREEMENTNO_NULL("120009", "参数错误:协议编码不能为空"),
        PEERTYPE_NULL("120010", "参数错误:节点类型不能为空"),
        PKPEERSETTINGINFO_NULL("120012", "参数错误:节点主键不能为空"),
        PEERSETTINGNAME_EXISTS("120013", "参数错误:节点名称重复"),
        IP_EXISTS("120014", "参数错误:该ip已经被使用"),
        LOCALPEER_EXISTS("120015", "本地节点已经存在"),


        CREATE_PAY_API_INFO_FALSE("130001", "创建支付服务接口失败"),
        EDIT_PAY_API_INFO_FALSE("130002", "更新支付服务接口失败"),
        FIND_PAY_API_INFO_FALSE("130003", "查找支付服务接口失败"),
        PAY_API_INFO_TERMINATION("130004", "支付服务接口已终止"),
        DELETE_PAY_API_INFO_FALSE("130005", "删除支付服务接口失败"),
        COST_RATE_UNFIND("130006", "没找到可用的费率"),
        MULTI_COST_RATE_FIND("130007", "找到多条可用的费率"),
        PAY_API_INFO_HAS_EFFICIENT("130008", "与已生效支付服务接口的有效期冲突"),
        APITYPE_NULL("130009", "参数错误: 服务接口类型不能为空!"),
        APINAME_NULL("130010", "参数错误: 服务接口名不能为空!"),
        COSTRATE_NULL("130011", "参数错误: 费率不能为空!"),
        SERVICEPAY_NULL("130012", "参数错误: 服务接口发布方不能为空!"),
        SMARTPAY_NULL("130013", "参数错误: 智能应用发布方不能为空!"),
        STARTDATE_NULL("130014", "参数错误: 有效期起始日期不能为空!"),
        ENDDATE_NULL("130015", "参数错误: 有效期结束日期不能为空!"),
        API_NULL("130016", "参数错误: API接口不能为空!"),
        TARGETTYPE_NULL("130017", "参数错误: 目标商户类型为空 或 选择了指定商户时没有商户数据 或 选择了公开时商户有数据!"),
        STATUS_NULL("130018", "参数错误: 接口状态不能为空!"),
        PUBLISH_NULL("130019", "参数错误: 发布状态不能为空!"),
        API_ERROR("130020", "参数错误: api接口描述不合法!"),
        PKPAYAPIINFO_ERROR("130021", "参数错误: 支付服务主键不能为空!"),
        PKSERVICEAPIINFO_ERROR("130022", "参数错误: 服务主键不能为空!"),//
        TARGETCOMPANY_NULL("130023", "参数错误: 目标商户为空"),
        PAYTYPE_NULL("130024", "参数错误: 支付类型不能为空"),
        DESCRIPTION_NULL("130025", "参数错误: 服务接口描述不能为空!"),
        PATH_NULL("130026", "参数错误: 调用地址不能为空!"),
        METHOD_NULL("130027", "参数错误: 请求方式不能为空!"),
        CONTENT_TYPE_NULL("130028", "参数错误: 返回类型不能为空!"),
        PARAM_EXPLAIN_NULL("130029", "参数错误: 参数说明不能为空!"),
        REQUEST_MESSAGE_FORMAT_NULL("130030", "参数错误: 请求报文格式不能为空!"),
        RESPONSE_MESSAGE_FORMAT_NULL("130031", "参数错误: 返回报文格式不能为空!"),
        ERROR_CODE_DEFINITION_NULL("130032", "参数错误: 错误码定义不能为空!"),
        REPORT_DEFINITION_NULL("130033", "参数错误: 订单报表定义不能为空!"),

        CREATE_SERVICE_API_INFO_FALSE("140001", "创建服务接口失败"),
        EDIT_SERVICE_API_INFO_FALSE("140002", "更新服务接口失败"),
        FIND_SERVICE_API_INFO_FALSE("140003", "查找服务接口失败"),
        DELETE_SERVICE_API_INFO_FALSE("140004", "删除服务接口失败"),
        SERVICE_API_INFO_PUBLISHED("140005", "服务接口已发布"),
        PRICE_NULL("140006", "参数错误:销售价格不能为空"),
        AMOUNT_NULL("140007", "参数错误:销售额度不能为空"),
        FINDTYPE_NULL("140008", "参数错误:查找的商户类型不能为空" ),

        SERVICE_API_INFO_TERMINATION("140009", "服务接口已终止"),
        MULTI_SERVICE_API_FIND("140010", "找到多条可用的服务"),


        SMARTAPPNAME_NULL("150001", "参数错误:智能应用名称不能为空"),               
        COOPERATE_COMPANY_NULL("150002", "参数错误:合作方不能为空!"),                
        TASKNUM_NULL("150003", "参数错误:任务数量不能为空!"),               
        TASKCONTENT_NULL("150004", "参数错误:任务内容不能为空!"),               
        APIDESCRIPTION_NULL("150005", "参数错误:应用描述不能为空!"),                
        PKSMARTAPPINFO_NULL("150006", "参数错误:智能应用主键不能为空!"),             
        COOPERATECOMPANY_SIZE_BIGGER("150007", "目前版本智能应用的协作用户只能添加一个,很抱歉!!"),                
        SMART_APP_TASK_FORMAT_FALSE("150008", "任务格式不正确"),
        CREATE_SMART_APP_INFO_FALSE("150009", "创建智能合约失败"),
        FIND_SMART_APP_INFO_FALSE("150010", "查找智能合约失败"),
        EDIT_SMART_APP_INFO_FALSE("150011", "更新智能合约失败"),
        SMART_APP_PUBLISHED("150012", "智能合约不能重复发布"),
        SMART_APP_NAME_REPEAT("150013", "智能合约名称已经被占用"),
        SMART_AID_USED("150014", "AID被其他商户使用"),
        SMART_APP_TERMINATION("150015", "智能合约已经终止"),
        SMART_APP_INFO_OVERDUE("150016", "智能合约已经过期"),
        AID_IS_NULL("150017", "智能合约AID不能为空"),
        FUN_PARAMS_UNFOUND_ERROR("150018", "合约任务方法的参数匹配失败"),
        SMART_INFO_HAS_APROVERED("150019", "与已生效智能合约的有效期冲突"),
        SMART_APP_FUN_URL_UNFIND("150020", "url为空"),
        SMART_APP_METHOD_UNFIND("150021", "调用方式为空"),
        SMART_APP_PARAMS_FORMAT_ERROR("150022", "参数前缀命名错误，请以S_或I_开头"),
        SMART_TASK_NUM_ERROR("150023", "任务数量错误"),
        SMART_TASK_CONTENT_IS_NULL("150024", "任务内容不能为空"),
        SMART_TASK_NUM_CONTENT_COMPARE_ERROR("150025", "任务数量与任务内容数量不相等"),
        ENDDATE_SMALL("150026", "参数错误: 修改结束日期必须大于原来的结束日期!"),
        FIND_MULTI_SMART_APP_INFO("150027", "查找到多条可用的智能合约"),


        CHECK_DEAL_INFO_FALSE("160001", "核对交易失败"),
        CREATE_DEAL_INFO_FALSE("160002", "保存交易数据失败"),
        DEAL_INFO_UNFOUND("160004", "查找交易信息失败"),
        TASK_NUMBER_ERROR("160005", "任务数量异常"),
        MERID_NULL("160006", "参数错误:商户号不能为空"),
        ORDERID_NULL("160007", "参数错误:交易流水号不能为空"),
        TXNAMT_NULL("160008", "参数错误:交易金额不能为空"),
        ACCNO_NULL("160009", "参数错误:银行卡号不能为空"),
        TXNTIME_NULL("160010", "参数错误:交易时间不能为空"),
        LOG_NULL("160011", "链上日志为空"),

        MANAGERNUMBER_NULL("170001", "参数错误:管理员账号不能为空"),
        PKROLES_NULL("170002", "参数错误:角色主键列表不能为空"),
        MANAGERNAME_NULL("170003", "参数错误:管理员名称不能为空"),
        PHONE_NULL("170004", "参数错误:联系电话不能为空"),
        EMAIL_NULL("170005", "参数错误:邮箱不能为空"),
        MANAGER_NULL("170006", "参数错误:找不到该管理员或者该管理员已经失效"),

        ROLE_NAME_EXISTS("180001", "角色名称重复"),
        ROLENAME_NULL("180002", "参数错误:角色名称为空"),
        MENULIST_NULL("180003", "参数错误:资源权限列表为空"),

        TASK_INDEX_ERROR("190001", "任务下标错误"),
        COMPANY_NAME_NOT_EXISTS_FALSE("190002", "任务的商户不在合作商户列表中"),
        LOG_INDEX_NOT_FOUND("190003", "日志下标丢失"),
        SMART_SNAPSHOT_INFO_ERROR("190004", "获取智能应用快照信息失败"),
        LOG_KEY_HEAD_NOT_FOUND("190005", "智能应用日志头丢失"),
        DEAL_INFO_TOKEN_NOT_FOUND("190006", "交易信息Token丢失"),
        DEAL_NO_HAS_BEEN_REGISTED("190007", "交易流水号已经备案，不能重复交易"),
        DEAL_NO_CHECK_REGISTED_RAS_ERR("190008", "远程访问交易流水号是否备案服务失败!"),
        DEAL_REGISTED_RAS_ERR("190009", "远程访问交易备案服务失败!"),
        COOP_COMPANY_UNFOUND("190010", "查询协作商户信息失败!"),
        SMART_COMPANY_UNFOUND("190011", "查询应用发布商户信息失败!"),
        PRIVKEY_NULL("190012", "私钥为空!"),
        PRIVKEY_CHECK_ERROR("190013", "身份验证失败!"),


        INIT_COMPANY_ERROR("200001", "初始化银联商户信息失败"),
        INIT_ROLE_ERROR("200002", "初始化角色信息失败"),
        INIT_MANAGER_ERROR("200003", "初始化管理员信息失败"),
//        PAGE_NOT_FOUND("200200", "页面不存在"),

        ACCT_ID_REPEAT("220001", "数据重复"),
        
        UPCONSUME_CANT("230002", "受理失败"),
        OPEN_CANT("230001", "开通无跳转支付失败"),
        CALL_CONSUME_ERROR("230003", "调用支付服务失败"),
        UPPAY_CANT("230004", "受理成功,扣费失败"),

        
        
        FILE_PATH_NULL("240001", "下载路径不能为空"),
        FILE_NOT_FOUND("240002", "找不到文件"),
        FILE_IO_ERROR("240003", "读写文件失败"),
        
        URL_IS_NULL("250001","URL不能为空"),
        HOST_PARSE_ERROR("250002", "未知的主机地址"),
        READ_TIMED_OUT("250003", "连接超时"),
        HOST_CONNECT_ERROR("250004", "主机连接失败"),

        CREATE_API_TYPE_INFO_FALSE("260001", "创建服务接口类型失败"),
        APITYPE_NAME_NULL("260002", "参数错误: 服务接口类型名称不能为空!"),
        APITYPE_NAME_ALREADY_EXISTS("260003", "服务接口类型名称已经被使用"),
        PKAPITYPENFO_NULL("260004", "参数错误:主键不能为空!"),

        CREATE_PRICE_TYPE_INFO_FALSE("270001", "创建价格类型失败"),
        PRICETYPE_NAME_NULL("270002", "参数错误: 价格类型名称不能为空!"),
        PRICETYPE_NAME_ALREADY_EXISTS("270003", "价格类型名称已经被使用"),
        PKPRICETYPENFO_NULL("270004", "参数错误:主键不能为空!"),
        
        ;




        private String code;
        private String msg;

        Return(String code, String msg) {
            this.code = code;
            this.msg = msg;
        }

        public String getMsg() {
            return msg;
        }

        public String  getCode() {

            return code;
        }
        

//        public Integer getCode() {
//
//            return Integer.parseInt(code);
//        }
    }
    public static Return getReturnByCode(String code){
        Return result=null;
        for(Constants.Return r:Constants.Return.values()){
            if(r.getCode().equals(code)){
                result=r;break;
            }
        }
        return result;
    }
    /**
     * 服务接口类型枚举码
     */
    public enum ApiType {
        POINT("积分兑换");
        private String name;

        ApiType(String name) {
            this.name = name;
        }

        public String getName() {
            return this.name;
        }
    }

}
