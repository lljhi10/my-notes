package com.value.silverchain.controller;

import com.mongodb.DuplicateKeyException;
import com.value.silverchain.bo.PageBo;
import com.value.silverchain.common.Constants;
import com.value.silverchain.model.BaseRole;
import com.value.silverchain.model.ManagerInfo;
import com.value.silverchain.service.IBaseRoleService;
import com.value.silverchain.service.exception.MyException;
import com.value.silverchain.vo.LoginManager;
import com.value.silverchain.vo.Result;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: ${date}
 * DESC:角色管理
 */
@RestController
@RequestMapping("/role/v1")
public class OrgRoleController {
    private Logger logger = LoggerFactory.getLogger(OrgRoleController.class);
    @Autowired
    private IBaseRoleService baseRoleService;
    
    @RequestMapping("/create")
    public String create(@RequestBody BaseRole baseRole,HttpServletRequest requst){
        Result result = new Result();


        if(StringUtils.isBlank(baseRole.getRoleName())){
            logger.info("------------------------参数错误:角色名称为空---------------");
            result.setState(Constants.Return.ROLENAME_NULL);
        } else if (baseRole.getMenuList()==null||
                baseRole.getMenuList().size()==0) {
            logger.info("------------------------参数错误:资源权限列表为空---------------");
            result.setState(Constants.Return.MENULIST_NULL);
        } else {

            try {

                ManagerInfo loginUser = (ManagerInfo) requst.getSession().getAttribute("loginUser");
                if (null == loginUser) {
                    throw new MyException(Constants.Return.USER_NOT_LOGIN);
                }
                //查看角色名称是否重复
                baseRole.setPkCompany(loginUser.getPkCompanyInfo());
                if (baseRoleService.getByName(baseRole) != null) {
                    //角色名已存在
                    result.setState(Constants.Return.ROLE_NAME_EXISTS);
                    return result.toJson();
                }
                baseRole.setPkRole(UUID.randomUUID().toString());
                baseRole.setPkCompany(loginUser.getPkCompanyInfo());
                baseRole.setCreateManager(loginUser.getPkManagerInfo());
                baseRole.setStatus(BaseRole.Status.VALID);
                baseRole.setCreateDate(new Date());
                String id = baseRoleService.save(baseRole);
            } catch (DuplicateKeyException e) {
                result.setState(Constants.Return.ACCT_ID_REPEAT);
            } catch (MyException e) {
//              e.printStackTrace();
                result.setState(e.getError());
            }
            result.getData().put("baseRole", baseRole);
        }
        return result.toJson();
    }


    /**
     * 查询角色信息列表
     * @param param
     * @return
     */
    @RequestMapping("/findByPage")
    @ResponseBody
    public String page(@RequestBody BaseRole param,HttpServletRequest request) {
        Result result = new Result();
        try {
            LoginManager loginUser = (LoginManager)request.getSession().getAttribute("loginManager");
            if(null==loginUser){
                throw new  MyException(Constants.Return.USER_NOT_LOGIN);
            }

            param.setPkCompany(loginUser.getLoginUser().getPkCompanyInfo());
            
            result.getData().put("list", baseRoleService.findPage(param));
        } catch (DuplicateKeyException e) {
            //throw new HorizonBizException(USEID_REPEAT);
            result.setState(Constants.Return.QUEYR_EXCEPTION);

        } catch (MyException e) {
            result.setState(e.getError());
        }
        return result.toJson();
    }

    /**
     * 删除角色信息：注意，这里的删除是软删除，只把角色状态一更改为无效
     * @param role
     * @return
     */
    @RequestMapping("/delete")
    @ResponseBody
    public String delete(@RequestBody BaseRole role, HttpSession session){
        Result result = new Result();
        try {
            LoginManager loginUser = (LoginManager)session.getAttribute("loginManager");

            //只能修改自己的角色
            BaseRole br = baseRoleService.getByPkRole(role.getPkRole());
            if(br != null) {
                if(!loginUser.getLoginUser().getPkCompanyInfo().equals(br.getPkCompany())){
                    result.setState(Constants.Return.TIGTH_LESS_THAN);
                    return result.toJson();
                }
            }           
            
            //商户的默认管理员不能被修改       
            br = baseRoleService.getByPkRole(role.getPkRole());
            if("超级管理员".equals(br.getRoleName())){
                result.setState(Constants.Return.TIGTH_LESS_THAN);
                return result.toJson();
            }
            
            BaseRole baseRole = baseRoleService.getByPkRole(role.getPkRole());
            baseRole.setStatus(BaseRole.Status.INVALID);
            baseRoleService.save(baseRole);
            result.getData().put("baseRole", baseRole);
        } catch (Exception e) {
            //throw new HorizonBizException(USEID_REPEAT);
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        }
        return result.toJson();
    }

    /**
     * 更新角色账号
     * @param baseRole
     * @return
     */
    @PostMapping("/edit")
    @ResponseBody
    public String editBaseRole(@RequestBody BaseRole baseRole, HttpSession session){
        Result result = new Result();
        try {

            LoginManager loginUser = (LoginManager)session.getAttribute("loginManager");

            //UP管理员能够查看但是只能修改自己的角色
            BaseRole br = baseRoleService.getByPkRole(baseRole.getPkRole());
            if(br != null) {
                if(!loginUser.getLoginUser().getPkCompanyInfo().equals(br.getPkCompany())){
                    result.setState(Constants.Return.TIGTH_LESS_THAN);
                    return result.toJson();
                }
            }

            //商户的默认管理员不能被修改       
            if("超级管理员".equals(br.getRoleName())){
                result.setState(Constants.Return.TIGTH_LESS_THAN);
                return result.toJson();
            }

            baseRole.setUpdateDate(new Date());
            baseRole.setUpdateManager(loginUser.getLoginUser().getPkManagerInfo());

            int updCount = baseRoleService.update(baseRole);

            if(updCount > 0) {
                result.getData().put("baseRole", baseRole);
            }else{
                result.setState(Constants.Return.UPDATE_EXCEPTION);
            }


        } catch (Exception e) {
            e.printStackTrace();
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        }

        return result.toJson();
    }

    /**
     * 更新角色账号
     * @param baseRole
     * @return
     */
    @PostMapping("/findById")
    @ResponseBody
    public String findById(@RequestBody BaseRole baseRole){
        Result result = new Result();
        try {

            baseRole = baseRoleService.getByPkRole(baseRole.getPkRole());
            result.getData().put("baseRole", baseRole);
        } catch (Exception e) {
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        }

        return result.toJson();
    }

    /**
     * 查找属于当前商户的所有角色
     * @param
     * @return
     */
    @RequestMapping("/findRoleAll")
    @ResponseBody
    public String findRoleAll(HttpSession session){
        Result result = new Result();
        BaseRole baseRole = new BaseRole();
        try {
            LoginManager loginUser = (LoginManager)session.getAttribute("loginManager");
            baseRole.setPkCompany(loginUser.getLoginUser().getPkCompanyInfo());
            baseRole.setPageNo(1);
            baseRole.setPageSize(1000);
            PageBo<BaseRole> pages = baseRoleService.findPage(baseRole);
            List<BaseRole>  roles = pages.getRows();
            for (int i = 0; roles.size() > i; i++) {
                if ("超级管理员".equals(roles.get(i).getRoleName())) {
                    roles.remove(i);
                }
            }
            pages.setRows(roles);
            result.getData().put("list", pages);

        } catch (Exception e) {
            e.printStackTrace();
            result.setState(Constants.Return.UPDATE_EXCEPTION);
        }

        return result.toJson();
    }
}



