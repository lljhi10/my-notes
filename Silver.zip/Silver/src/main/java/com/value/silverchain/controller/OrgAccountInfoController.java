package com.value.silverchain.controller;

import com.mongodb.DuplicateKeyException;
import com.value.silverchain.bo.PageBo;
import com.value.silverchain.common.Constants;
import com.value.silverchain.model.AccountInfo;

import com.value.silverchain.service.IBusinessInfoService;



import com.value.silverchain.model.CompanyInfo;

import com.value.silverchain.vo.Result;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.UUID;


/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: ${date}
 * DESC:商户管理
 */
@Controller
@RequestMapping("/accountInfo/v1")
public class OrgAccountInfoController {


}
