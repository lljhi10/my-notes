package com.value.silverchain.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Map;
import java.util.UUID;

/**
 * Created by za-xiezhigang on 2017/5/9.
 */
public class JsonUtil {
    private static Logger LOGGER = LoggerFactory.getLogger(JsonUtil.class);
    public static ObjectMapper mapper = new ObjectMapper();

    public static String writeJson(Object obj) {
        String json = "";
        try {
            json = mapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            LOGGER.error("对象转换成json失败：{}", e.getMessage(), e);
        }
        return json;
    }

    public static Map<String, Object> jsonToMap(String json) {
        Map<String, Object> map = null;
        try {
            map = mapper.readValue(json, Map.class);
        } catch (IOException e) {
            LOGGER.error("json转换成对象失败：{}", e.getMessage(), e);
        }
        return map;
    }

    public static <T> T jsonToObject(String json, Class<T> tClass) {
        T o = null;
        try {
            o = mapper.readValue(json, tClass);
        } catch (IOException e) {
            LOGGER.error("json转换成对象失败：{}", e.getMessage(), e);
        }
        return o;
    }

    public static JsonNode readTree(String str) {
        try {
            return mapper.readTree(str);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getUUID() {
        return UUID.randomUUID().toString().replaceAll("-", "");
    }

}
