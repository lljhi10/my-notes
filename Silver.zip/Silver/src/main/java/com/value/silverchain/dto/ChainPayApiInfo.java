package com.value.silverchain.dto;

import com.value.silverchain.model.BasePage;
import com.value.silverchain.model.PayApiInfo;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 *  支付接口信息上链下链类
 */
@Data
public class ChainPayApiInfo extends BasePage{

    private String pkPayApiInfo;//接口主键
    private String pkCompanyInfo;//商户主键
    private String pkApiTypeInfo;//服务接口类型主键
    private String pkPriceTypeInfo;//价格类型主键
    private String apiName;//服务接口名称
    private List<String> targetCompany;//目标商户：接收前台传来的数据
    private Float costRate;//费率
    private PayApiInfo.Payer servicePay;//服务接口发布方付费
    private PayApiInfo.Payer smartPay;//智能发布方付费
    private Date publishDate;//发布日期
    private Date startDate;//有效期-开始时间
    private Date endDate;//有效期-结束时间
    private PayApiInfo.TargetType targetType;//目标类型：公开/指定商户
    private String apiDescription;//API接口描述
    private PayApiInfo.Publish publish;//发布状态：未发布/生效中
    private PayApiInfo.Status status;//接口状态：正常， 暂停， 终止
    public ChainPayApiInfo (PayApiInfo payApiInfo) {
        this.setPkPayApiInfo(payApiInfo.getPkPayApiInfo());
        this.setPkCompanyInfo(payApiInfo.getPkCompanyInfo());
        this.setPkApiTypeInfo(payApiInfo.getPkApiTypeInfo());
        this.setPkPriceTypeInfo(payApiInfo.getPkPriceTypeInfo());
        this.setApiName(payApiInfo.getApiName());
        this.setTargetCompany(payApiInfo.getTargetCompany());
        this.setCostRate(payApiInfo.getCostRate());
        this.setServicePay(payApiInfo.getServicePay());
        this.setSmartPay(payApiInfo.getSmartPay());
        this.setPublishDate(payApiInfo.getPublishDate());
        this.setEndDate(payApiInfo.getEndDate());
        this.setTargetType(payApiInfo.getTargetType());
        this.setApiDescription(payApiInfo.getApiDescription());
        this.setPublish(payApiInfo.getPublish());
        this.setStatus(payApiInfo.getStatus());
        this.setStartDate(payApiInfo.getStartDate());
    }

    public  ChainPayApiInfo(){

    }
}