package com.value.silverchain.service.impl;


import com.mongodb.operation.UpdateOperation;
import com.value.silverchain.bo.PageBo;
import com.value.silverchain.model.AccountInfo;
import com.value.silverchain.model.BaseRole;
import com.value.silverchain.model.CompanyInfo;
import com.value.silverchain.model.ManagerInfo;
import com.value.silverchain.service.IBaseRoleService;
import com.value.silverchain.service.IOrgInfoService;
import com.value.silverchain.service.IUserAccountService;
import com.value.silverchain.util.MD5;
import org.apache.commons.lang3.StringUtils;
import org.bson.types.ObjectId;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.UpdateOperations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:01
 * DESC:
 */
@Service
public class UserAccountServiceImpl implements IUserAccountService {

    @Autowired
    private Datastore datastore;
    @Autowired
    private IOrgInfoService orgInfoService;
    @Autowired
    private IBaseRoleService baseRoleService;

    @Override
    public String save(ManagerInfo userAccount) {
        Key<ManagerInfo> key = datastore.save(userAccount);
        return ((ObjectId) key.getId()).toHexString();
    }

    @Override
    public ManagerInfo getByUserID(ManagerInfo userAccount) {
        Query<ManagerInfo> query = datastore.find(ManagerInfo.class).field("pkManagerInfo").equal(userAccount.getPkManagerInfo()).filter("status !=",ManagerInfo.Status.INVALID);
        return query.get();
    }

    @Override
    public PageBo<ManagerInfo> findPage(ManagerInfo param) {
        Query<ManagerInfo> query = datastore.find(ManagerInfo.class);
        query.field("status").notEqual(ManagerInfo.Status.INVALID);
        //判断当前用户是否是UP
        CompanyInfo company = new CompanyInfo();
        company.setPkCompanyInfo(param.getPkCompanyInfo());
        company = orgInfoService.getCompanyInfoByID(company);
        
        query.field("pkCompanyInfo").equal(param.getPkCompanyInfo());
        query.field("pkManagerInfo").notEqual(param.getPkManagerInfo());

        if(StringUtils.isNotBlank(param.getManagerNumber())) {
            query.field("managerNumber").contains(param.getManagerNumber());
        }


        query.order("-createDate");
        query.offset(param.getPageNo() * param.getPageSize() - param.getPageSize());
        query.limit(param.getPageSize());

        List<ManagerInfo> manags = query.asList();

        for (ManagerInfo item : manags) {
            if(company != null) {
                company.setPkCompanyInfo(item.getPkCompanyInfo());
                company = orgInfoService.getCompanyInfoByID(company);
                item.setCompanyName(company.getCompanyName());
            }
        }

        for (ManagerInfo item : manags) {
            String roleName = "";
            for (String str:item.getPkRoles()) {
                BaseRole roles = baseRoleService.getByPkRole(str);
                if(roles != null) {
                    roleName += roles.getRoleName()+",";
                }

            }
            item.setRolesNameList(roleName);

        }


        return new PageBo(manags,query.count());
    }

    @Override
    public String delete(ManagerInfo param) {
        UpdateOperations<ManagerInfo> ops = datastore.createUpdateOperations(ManagerInfo.class);
        if(StringUtils.isNotBlank(param.getStatus().getName())){
            ops.set("status",param.getStatus());
        }

        return datastore.update(datastore.find(ManagerInfo.class).field("pkManagerInfo").equal(param.getPkManagerInfo()),ops).getUpdatedCount()+"";
    }


    @Override
    public int update(ManagerInfo param) {

        UpdateOperations<ManagerInfo> ops = datastore.createUpdateOperations(ManagerInfo.class);
        if(param.getStatus() != null){
            ops.set("status",param.getStatus());
        }
        if(param.getPkRoles() != null){
            ops.set("pkRoles",param.getPkRoles());
        }
        if(StringUtils.isNotBlank(param.getManagerName())){
            ops.set("managerName",param.getManagerName());
        }
        if(StringUtils.isNotBlank(param.getPassword())){
            ops.set("password",param.getPassword());
            ops.set("defaultKey",ManagerInfo.DefaultKey.NO);
        }
        if(StringUtils.isNotBlank(param.getPkCompanyInfo())){
            ops.set("pkCompanyInfo",param.getPkCompanyInfo());
        }
        if(StringUtils.isNotBlank(param.getPhone())){
            ops.set("phone",param.getPhone());
        }
        if(StringUtils.isNotBlank(param.getEmail())){
            ops.set("email",param.getEmail());
        }
        ops.set("updateDate",param.getUpdateDate());
        ops.set("updateManager",param.getUpdateManager());

        return datastore.update(datastore.find(ManagerInfo.class).field("pkManagerInfo").equal(param.getPkManagerInfo()),ops).getUpdatedCount();
    }

    @Override
    public void realDelete(String pkManagerInfo) {
        datastore.delete(datastore.createQuery(ManagerInfo.class).filter("pkManagerInfo",pkManagerInfo));
    }

    @Override
    public ManagerInfo getByUserNumber(ManagerInfo param) {
        Query<ManagerInfo> query = datastore.find(ManagerInfo.class).filter("status !=",ManagerInfo.Status.INVALID);
        query.field("managerNumber").equal(param.getManagerNumber());

        if(param.getPkCompanyInfo() != null) {
            query.field("pkCompanyInfo").equal(param.getPkCompanyInfo());
        }

        return query.get();
    }

    @Override
    public int updatePassword(ManagerInfo managerInfo) {
        UpdateOperations<ManagerInfo> ops = datastore.createUpdateOperations(ManagerInfo.class);

        if(managerInfo.getDefaultKey() != null){
            ops.set("defaultKey",managerInfo.getDefaultKey());
        }

        if(managerInfo.getPassword() != null){
            ops.set("password",managerInfo.getPassword());
        }

        int count = datastore.update(datastore.find(ManagerInfo.class).field("pkManagerInfo").equal(managerInfo.getPkManagerInfo()),ops) .getUpdatedCount();

        return count;
    }

    public static void main(String[] args) {
        System.out.println(MD5.strMD5("银联"+123456));
        System.out.println(UUID.randomUUID().toString());
    }
}
