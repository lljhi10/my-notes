package com.value.silverchain.service;

import com.value.silverchain.bo.PageBo;
import com.value.silverchain.dto.ChainAccountInfo;
import com.value.silverchain.model.AccountInfo;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:00
 * DESC:业务账号管理
 */
public interface IBusinessInfoService {

    /**
     * 保存业务账号
     * @param accountInfo
     * @return
     */
    String save(AccountInfo accountInfo);

    /**
     * 按主键取的业务账号
     * @param accountInfo
     * @return
     */
    AccountInfo getAccountInfoByID(AccountInfo accountInfo);

    /**
     * 按名称取的业务账号
     * @param accountInfo
     * @return
     */
    AccountInfo getAccountInfoByName(AccountInfo accountInfo);

    /**
     * 分页查询
     * @param accountInfo
     * @return
     */
    PageBo<AccountInfo> findPage(AccountInfo accountInfo);

    /**
     * 更新业务账号
     * @param accountInfo
     * @return
     */
    int update(AccountInfo accountInfo);

    /**
     * 验证字段唯一性
     * @param accountInfo
     * @return
     */
    AccountInfo uniqueCheck(AccountInfo accountInfo);

    int updateFromChain(ChainAccountInfo item);

    /**
     * 查询商户的业务账户
     * @param pkCompanyInfo
     * @param supportTradeType
     * @return
     */
    AccountInfo getAccountInfoByCompany(String pkCompanyInfo, AccountInfo.SupportTradeType supportTradeType);
}
