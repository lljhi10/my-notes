package com.value.silverchain.dto;

import com.value.silverchain.model.DealInfo;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/7/20
 * DESC:智能应用调用规则明细，当交易发起时，把智能应用的所有规则快照，创建本类对象保存下来
 */
@Data
public class SmartAppSnapshotInfo {
    private Date date;//智能应用调用时间
    private String aid;//智能应用aid
    private String pkCompanyInfo;//发布智能应用的商户主键
    private String pkPeerSettingInfo;//智能应用发布商户注册节点
    private String cooperateCompany;//合作方商户
    private String cooperatePeer;//合作方商户注册节点
    private DealInfo dealInfo;//交易信息
    private List<String> taskContent;//智能应用任务内容
    private Integer smartappIndex=0;//任务执行下标，从0开始
    private Integer logIndex;//日志下标
    private String failueApi;//失败回调API接口
    private String serviceApi;//服务接口业务
}
