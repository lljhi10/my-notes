package com.value.silverchain.vo;

import lombok.Data;

@Data
public class Password {
    private String oldPwd;
    private String newPwdLast;
}
