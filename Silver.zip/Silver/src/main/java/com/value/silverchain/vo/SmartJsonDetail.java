package com.value.silverchain.vo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.value.silverchain.util.JsonUtil;
import lombok.Data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/6/11
 * DESC:智能合约解释类
 */
@Data
public class SmartJsonDetail {
    private  String aid;//唯一标识ID，后台生成
    private String smartAppName;//智能应用名称
    private String description;//智能合约描述
    private Date startDate;//有效期-开始时间
    private Date endDate;//有效期-结束时间
    private int smartappIndex;//任务执行坐标，根据这个坐标执行任务列表中坐标与它相等的任务，从0开始
    private List<String> cooperateCompany;//合作商户列表
    private List<String> paramsValue;//参数列表
    private List<SmartTaskJsonDetail> smartapp;//任务列表

    @JsonIgnore
    public List<String> getTaskContent() {
        List<String> taskContent=new ArrayList<>();
        for (SmartTaskJsonDetail detail:smartapp){
            taskContent.add(JsonUtil.writeJson(detail));
        }
        return taskContent;
    }
}
