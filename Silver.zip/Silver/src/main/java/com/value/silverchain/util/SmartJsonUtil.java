package com.value.silverchain.util;

import com.value.silverchain.common.Constants;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.CompanyInfo;
import com.value.silverchain.model.SmartAppInfo;
import com.value.silverchain.service.ISmartAppInfoService;
import com.value.silverchain.vo.SmartAppInfoVo;
import com.value.silverchain.vo.SmartFunJsonDetail;
import com.value.silverchain.vo.SmartJsonDetail;
import com.value.silverchain.vo.SmartTaskJsonDetail;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/6/11
 * DESC:智能合约对象与json转换工具
 */
public class SmartJsonUtil {
    @Autowired
    private ISmartAppInfoService smartAppInfoService;
    /**
     * 拼装智能合约json字符串
     * @param vo
     * @param companyInfoList
     * @return
     */
    public static String createSmartJson(SmartAppInfoVo vo, List<CompanyInfo> companyInfoList) throws HorizonBizException{
        SmartJsonDetail detail=new SmartJsonDetail();
        detail.setAid(vo.getAid());//aid
        detail.setSmartAppName(vo.getSmartAppName());//合约名称
        detail.setStartDate(vo.getStartDate());//开始日期
        detail.setEndDate(vo.getEndDate());//结束日期
        detail.setSmartappIndex(0);//任务执行坐标，根据这个坐标执行任务列表中坐标与它相等的任务，从0开始
        detail.setCooperateCompany(vo.getCooperateCompany());//协作公司列表
        
        List<String> paramsValue= new ArrayList<>();//参数列表
        Map<String,String> paramsMap= new HashMap<String,String>();//参数MAP
        List<SmartTaskJsonDetail> smartapp= new ArrayList<SmartTaskJsonDetail>();//任务列表
        Map<String,String> companyNameMap= new HashMap<String,String>();//合作商户MAP
        for (CompanyInfo c:companyInfoList){
            companyNameMap.put(c.getCompanyName(),c.getCompanyName());
        }
        List<String> taskContent=vo.getTaskContent();
        if(taskContent.size()!=vo.getTaskNum()){
            //任务数量对不上
            throw new HorizonBizException(Constants.Return.TASK_NUMBER_ERROR);
        }
        try {
            for (String content:taskContent){//遍历任务
                System.out.println(content);
                SmartTaskJsonDetail t = JsonUtil.jsonToObject(content, SmartTaskJsonDetail.class);
                //检查任务数据合法性
                if(StringUtils.isBlank(t.getTaskName())||
                           StringUtils.isBlank(t.getCompanyName())||
                        t.getFuns()==null||
                        t.getFuns().size()<=0){
                    throw new HorizonBizException(Constants.Return.SMART_APP_TASK_FORMAT_FALSE);
                }
                if(StringUtils.isBlank(companyNameMap.get(t.getCompanyName()))//公司名不在合作商户列表中
                           ){
                    throw new HorizonBizException(Constants.Return.COMPANY_NAME_NOT_EXISTS_FALSE);
                }
                
                t.setTaskMark(JsonUtil.getUUID());
                smartapp.add(t);
                
                List<SmartFunJsonDetail> funs = t.getFuns();
                for (SmartFunJsonDetail fun:funs){//遍历方法
                    //检查方法数据合法性
                    if (StringUtils.isBlank(fun.getUrlPath())||
                                fun.getMethodType()==null
                            ) {
                        throw new HorizonBizException(Constants.Return.SMART_APP_TASK_FORMAT_FALSE);
                    }
                    List<String> params= fun.getParams();
                    if (params!=null&&params.size()>0){//遍历参数，添加到参数MAP中
                        params.forEach(param->{
                            String value = paramsMap.get(param);
                            if (value == null) {
                                paramsMap.put(param,param);
                            }
                        });
                    }
                }
            }
            for (String key :paramsMap.keySet()){
                paramsValue.add(key);
            }
            detail.setParamsValue(paramsValue);
            detail.setSmartapp(smartapp);
        }catch (HorizonBizException e){
            e.printStackTrace();
            throw e;
        }
        
        return JsonUtil.writeJson(detail);
    }

    /**
     * 组装展示类
     * @param smartAppInfo
     * @return
     */
    public static SmartAppInfoVo joToVo(SmartAppInfo smartAppInfo) {
        SmartAppInfoVo vo = new SmartAppInfoVo(smartAppInfo);
//        SmartJsonDetail detail=JsonUtil.jsonToObject(smartAppInfo.getSmartJsonContant(),SmartJsonDetail.class);
//        vo.setTaskContent(detail.getTaskContent());
        return vo;
    }

    /**
     * 检查api文档的写法是否合法
     * @param apiDescription
     * @throws HorizonBizException
     */
    public static void  checkApi(String apiDescription)throws HorizonBizException{
        SmartFunJsonDetail fun = JsonUtil.jsonToObject(apiDescription,SmartFunJsonDetail.class);
        if (StringUtils.isBlank(fun.getUrlPath())) {
            throw new HorizonBizException(Constants.Return.SMART_APP_FUN_URL_UNFIND);
        }
        if(fun.getMethodType()==null){
            throw new HorizonBizException(Constants.Return.SMART_APP_METHOD_UNFIND);
        }
        if (fun.getParams()!=null&&fun.getParams().size()>=0){
            for (String key:fun.getParams()){
                if (!key.startsWith("S_")&&!key.startsWith("I_")){
                    throw new HorizonBizException(Constants.Return.SMART_APP_PARAMS_FORMAT_ERROR);
                }
            }
        }
        if (StringUtils.isNotBlank(fun.getReturnName())){
            if (!fun.getReturnName().startsWith("S_")&&!fun.getReturnName().startsWith("I_")){
                throw new HorizonBizException(Constants.Return.SMART_APP_PARAMS_FORMAT_ERROR);
            }
        }
    }
            
}
