package com.value.silverchain.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.value.silverchain.dto.CompanyInfoDto;
import com.value.silverchain.model.BasePage;
import com.value.silverchain.model.SmartAppInfo;
import lombok.Data;
import org.bson.types.ObjectId;

import java.util.Date;
import java.util.List;

/**
 *  智能应用展示类
 */
@Data
public class SmartAppInfoVo extends BasePage{
    
    private ObjectId id;
    
    private String pkSmartAppInfo;//接口主键

    private String pkCompanyInfo;//发布智能应用商户主键

    private String companyName;//发布智能应用商户名称
    
    private String smartAppName;//智能应用名称
    
    private String aid;//唯一标识ID，后台生成

    //    private Constants.ApiType apiType;//服务接口类型
    private String pkApiTypeInfo;//服务接口类型主键

    private List<String> cooperateCompany;//合作方列表
    
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date startDate;//有效期-开始时间
    
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date endDate;//有效期-结束时间

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date publishDate;//发布日期
    
    private Integer taskNum;//任务数量
    
    private List<String> taskContent;//任务列表

    private String apiDescription;//回调API接口描述

    private String failueApi;//失败回调API接口
    
    private SmartAppInfo.Status status;//应用状态：正常， 暂停， 终止
    
    private SmartAppInfo.Aprover aprover;//审核状态：待审核，已审核

    private String cooperateCompanyName;//合作方商户名称
    
    private List<CompanyInfoDto> cooperateCompanyInfoList;//合作方商户列表
    
    private boolean isPublish;//操作类型：true发布，false保存，默认为false

    private Float costRate;//费率

    private String apiName;//服务接口名称
    
    private Integer findType;//查询类型：1合约发布方查询，2合约审核方查询(即服务发布方)
    
    public boolean getIsPublish(){return this.isPublish;}
    
    public void setIsPublish(boolean isPublish){this.isPublish=isPublish;}

    public SmartAppInfoVo(){}

    public void setSid(String sid) {
        this.pkSmartAppInfo = sid;
    }
    /**
     * 组装展示数据
     * @param smartAppInfo
     */
    public SmartAppInfoVo(SmartAppInfo smartAppInfo) {
        this.setId(smartAppInfo.getId());
        this.setPkSmartAppInfo(smartAppInfo.getPkSmartAppInfo());
        this.setPkCompanyInfo(smartAppInfo.getPkCompanyInfo());
        this.setCompanyName(smartAppInfo.getCompanyName());
        this.setSmartAppName(smartAppInfo.getSmartAppName());
        this.setAid(smartAppInfo.getAid());
        this.setCooperateCompany(smartAppInfo.getCooperateCompany());
        this.setStartDate(smartAppInfo.getStartDate());
        this.setEndDate(smartAppInfo.getEndDate());
        this.setStatus(smartAppInfo.getStatus());
        this.setAprover(smartAppInfo.getAprover());
        this.setTaskNum(smartAppInfo.getTaskNum());
        this.setTaskContent(smartAppInfo.getTaskContent());
        this.setCooperateCompanyInfoList(smartAppInfo.getCooperateCompanyInfoList());
        this.setCooperateCompanyName(smartAppInfo.getCooperateCompanyName());
//        this.setApiType(smartAppInfo.getApiType());
        this.setPkApiTypeInfo(smartAppInfo.getPkApiTypeInfo());
        this.setPublishDate(smartAppInfo.getPublishDate());
        this.setFailueApi(smartAppInfo.getFailueApi());
    }
}