package com.value.silverchain.bo;

import java.io.Serializable;
import java.util.List;

/**
 * Created by za-xiezhigang on 2017/6/28.
 */
public class PageBo<T> implements Serializable{

    private List<T> rows;
    private long total;

    public PageBo(List<T> rows, long total) {
        this.rows = rows;
        this.total = total;
    }

    public List<T> getRows() {
        return rows;
    }

    public void setRows(List<T> rows) {
        this.rows = rows;
    }

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }
}
