package com.value.silverchain.service;

import com.value.silverchain.bo.PageBo;
import com.value.silverchain.model.ManagerInfo;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:00
 * DESC:
 */
public interface IAccountInfoService {

    String save(ManagerInfo userAccount);
    ManagerInfo getByUserID(String userID);
    PageBo<ManagerInfo> findPage(ManagerInfo param);
    String delete(String userId);
    List<ManagerInfo> getUserListByPhone(String phone);
    int update(ManagerInfo param);

}
