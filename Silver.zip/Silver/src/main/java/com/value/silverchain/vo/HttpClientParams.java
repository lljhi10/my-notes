package com.value.silverchain.vo;

import lombok.Data;

import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/8/7
 * DESC:远程访问参数类
 */
@Data
public class HttpClientParams {
    private String url;//访问路径
    private String type;//访问类型：GET /POST
    private Map<String,String> params;//参数
}
