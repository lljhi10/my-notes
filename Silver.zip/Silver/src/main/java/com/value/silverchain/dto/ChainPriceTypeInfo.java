package com.value.silverchain.dto;

import com.value.silverchain.model.BasePage;
import com.value.silverchain.model.PriceTypeInfo;
import lombok.Data;

import java.util.List;

/**
 *  价格类型信息上链下链类
 */
@Data
public class ChainPriceTypeInfo extends BasePage{
    private String pkPriceTypeInfo;//价格类型主键

    private String priceTypeName;//价格类型名称

    private String description;//描述

    private List<String> targetCompany;//目标商户：接收前台传来的数据

    private PriceTypeInfo.TargetType targetType;//目标类型：公开/指定商户

    private PriceTypeInfo.Status status;//接口状态：正常， 暂停， 终止
    public ChainPriceTypeInfo(PriceTypeInfo priceTypeInfo) {
        this.setPkPriceTypeInfo(priceTypeInfo.getPkPriceTypeInfo());
        this.setPriceTypeName(priceTypeInfo.getPriceTypeName());
        this.setDescription(priceTypeInfo.getDescription());
        this.setTargetCompany(priceTypeInfo.getTargetCompany());
        this.setTargetType(priceTypeInfo.getTargetType());
        this.setStatus(priceTypeInfo.getStatus());
    }

    public ChainPriceTypeInfo(){

    }
}