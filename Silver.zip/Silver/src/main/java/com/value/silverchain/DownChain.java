package com.value.silverchain;


import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.service.IBaseRoleService;
import com.value.silverchain.service.IChainService;
import com.value.silverchain.service.IOrgInfoService;
import com.value.silverchain.service.IUserAccountService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * 初始化线程
 */
@Component
@Scope("prototype")
public class DownChain extends Thread {

    final static Logger logger = LoggerFactory.getLogger(DownChain.class);
    @Autowired
    private IOrgInfoService orgInfoService;

    @Autowired
    private IBaseRoleService baseRoleService;
    @Autowired
    private IUserAccountService userAccountService;
    @Autowired
    private IChainService chainService;

    @Override
    public void run() {
        while (true) {
            try {
                Date start = new Date();
                logger.info("---------------------------下链开始,开始时间："+start.toLocaleString()+"-------------------");
                chainService.queryAccountInfo();
                chainService.queryCompanyInfo();
                chainService.queryPeerSettingInfo();
                chainService.querySmartAppInfo();
                chainService.queryPayApiInfo();
                chainService.queryApiTypeInfo();
                chainService.queryPriceTypeInfo();
                chainService.queryServiceApiInfo();
                Date end = new Date();
                logger.info("---------------------------下链完成,完成时间："+end.toLocaleString()+"-------------------");
//                logger.info("--------------------耗时："+ DateHelper.getDifferenceNum(start,end,0)+"---------------------------");
                logger.info("--------------------耗时："+ (end.getTime()-start.getTime())+"毫秒---------------------------");
                Thread.sleep(10000);
            } catch (HorizonBizException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }catch (Exception e){
                e.printStackTrace();
            }
        }

    }
}



