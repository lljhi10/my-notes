package com.value.silverchain.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.value.silverchain.dto.CompanyInfoDto;
import lombok.Data;
import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Id;
import org.mongodb.morphia.annotations.Indexed;
import org.mongodb.morphia.annotations.Transient;
import org.mongodb.morphia.utils.IndexDirection;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *  支付接口信息
 */
@Entity("pay_api_info")
@Data
public class PayApiInfo extends BasePage{

    public enum Status {
        NORMAL("正常"), PAUSE("暂停"), TERMINATION("终止");
        private String name;

        Status(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum Payer {
        CHECKED("选中"),UNCHECKED("未选中");
        private String name;

        Payer(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum Publish {
        UNPUBLISH("未发布"),EFFICIENT("生效中");
        private String name;

        Publish(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }
    public enum PayType {
        SERVICE("服务接口发布方"),SMART("智能应用发布方");
        private String name;

        PayType(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }

    public enum TargetType {
        OPEN("公开"),TARGET("指定商户");
        private String name;

        TargetType(String name ){
            this.name=name;
        }
        public String getName() {
            return this.name;
        }
    }

    @Id
    @JsonIgnore
    private ObjectId id;
    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_pkPayApiInfo",dropDups = true)
    private String pkPayApiInfo;//接口主键

    private String pkCompanyInfo;//商户主键

//    private Constants.ApiType apiType;//服务接口类型
    private String pkApiTypeInfo;//服务接口类型主键

    private String pkPriceTypeInfo;//价格类型主键

    @Indexed(unique = true, value = IndexDirection.ASC, name = "idx_payApiName",dropDups = true)
    private String apiName;//服务接口名称
    
    private List<String> targetCompany;//目标商户：接收前台传来的数据

    private Float costRate;//费率

    private Payer servicePay;//服务接口发布方付费
    private Payer smartPay;//智能发布方付费

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date publishDate;//发布日期

    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date startDate;//有效期-开始时间

    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date endDate;//有效期-结束时间

    private TargetType targetType;//目标类型：公开/指定商户

    private String apiDescription;//API接口描述
    
    private Publish publish;//发布状态：未发布/生效中

    private Status status;//接口状态：正常， 暂停， 终止

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createDate;//创建时间

    private String createManager;//创建人

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateDate;//最后更新时间

    private String updateManager;//最后更新人

    @Transient
    private String targetCompanyName;//目标商户名称
    @Transient
    private List<CompanyInfoDto> companyInfoList;//目标商户列表
    @Transient
    private PayType payType;//付费类型：1服务接口付费，2智能应用付费

    @Transient
    private ApiTypeInfo apiTypeInfo;//服务接口类型

    @Transient
    private PriceTypeInfo priceTypeInfo;//价格类型
//    public Map getApiTypeObject() {
//        Map map = new HashMap();
//        if(apiType != null) {
//            map.put("name",this.apiType.getName());
//            map.put("value",this.apiType);
//        }
//
//        return map;
//    }

    public Map getStatusObject() {
        Map map = new HashMap();
        if(status != null) {
            map.put("name", this.status.getName());
            map.put("value", this.status);
        }
        return map;
    }

    public Map getServicePayObject() {
        Map map = new HashMap();
        if(servicePay != null) {
            map.put("name", this.servicePay.getName());
            map.put("value", this.servicePay);
        }
        return map;
    }
    public Map getSmartPayObject() {
        Map map = new HashMap();
        if(smartPay != null) {
            map.put("name", this.smartPay.getName());
            map.put("value", this.smartPay);
        }
        return map;
    }

    public Map getPublishObject() {
        Map map = new HashMap();
        if(publish != null) {
            map.put("name", this.publish.getName());
            map.put("value", this.publish);
        }
        return map;
    }

    public Map getTargetTypeObject() {
        Map map = new HashMap();
        if(this.targetType != null) {
            map.put("name", this.targetType.getName());
            map.put("value", this.targetType);
        }
        return map;
    }
}