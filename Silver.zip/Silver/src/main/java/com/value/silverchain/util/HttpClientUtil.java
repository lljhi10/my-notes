package com.value.silverchain.util;

import com.alibaba.fastjson.JSON;
import com.value.silverchain.common.Constants;
import com.value.silverchain.exception.HorizonBizException;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.Header;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

@Slf4j
public final class HttpClientUtil {

    private static PoolingHttpClientConnectionManager poolingHttpClientConnectionManager;

    private static final Integer CON_MAX_TOTAL = 200;

    private static final Integer CON_MAX_PERROUTE = 50;

    private static class PoolSingle {
        private static PoolingHttpClientConnectionManager pool = new PoolingHttpClientConnectionManager();
        private PoolSingle(){}
    }

    private static PoolingHttpClientConnectionManager getInstance() {
        poolingHttpClientConnectionManager = PoolSingle.pool;
        if (null != poolingHttpClientConnectionManager) {
            poolingHttpClientConnectionManager.setMaxTotal(CON_MAX_TOTAL);// 整个连接池最大连接数
            poolingHttpClientConnectionManager.setDefaultMaxPerRoute(CON_MAX_PERROUTE);// 每路由最大连接数，默认值是2
        }
        return poolingHttpClientConnectionManager;
    }

    private static CloseableHttpClient getCloseableHttpClient() {
        getInstance();
        return HttpClients.custom().setConnectionManager(poolingHttpClientConnectionManager).build();
    }
    private static CloseableHttpClient getCloseableHttpClient(RequestConfig config) {
        getInstance();
        return HttpClients.custom()
                       .setConnectionManager(poolingHttpClientConnectionManager)
                       .setDefaultRequestConfig(config)
                       .build();
    }
    
    public static String doGet(String url, Map<String, String> param) throws HorizonBizException {

        // 创建Httpclient对象
        CloseableHttpClient httpclient = getCloseableHttpClient();

        String resultString = null;
        List<Header> resultHeader=new ArrayList<>();
        CloseableHttpResponse response = null;
        URI uri = null;
        try {
            // 创建uri
            URIBuilder uriBuilder = new URIBuilder(url);
            if (param != null) {
                for (Entry<String, String> entry : param.entrySet()) {
                	String key = entry.getKey();
                    uriBuilder.addParameter(key, param.get(key));
                }
            }
            uri = uriBuilder.build();

            // 创建http GET请求
            HttpGet httpGet = new HttpGet(uri);

            // 执行请求
            response = httpclient.execute(httpGet);
            log.info("[ httpClient ] GET url : {}", uri.toURL());
            String jsonString = JSON.toJSONString(response == null ? "{}" : response);
//			log.info("[ httpClient ] GET response : {}", jsonString);

            // 判断返回状态是否为200
            if (null != response && response.getStatusLine().getStatusCode() == 200) {
                resultString = EntityUtils.toString(response.getEntity(), "UTF-8");
                Header[] headers =response.getAllHeaders();
                for (Header h:headers){
//                    log.info("cookis:"+h.getName()+"  value:"+h.getValue());
                    if(h.getValue().indexOf("remeberMe")>=0){
                        resultHeader.add(h);
                    }
                }
            }
        } catch (UnknownHostException e) {
            log.error("[ httpClient ] GET failed : {}" + url, e);
            throw new HorizonBizException(Constants.Return.HOST_PARSE_ERROR,e.getMessage());
        } catch (HttpHostConnectException e) {
            log.error("[ httpClient ] GET failed : {}" + url, e);
            throw new HorizonBizException(Constants.Return.HOST_CONNECT_ERROR,e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            log.error("[ httpClient ] GET failed : {}" + uri, e);
            throw new HorizonBizException(Constants.Return.RAS_ERR,e.getMessage());
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error("[ httpClient ] Release resources failed : {}", uri, e);
            }
        }
        return resultString;
    }

    public static String doGetTest(String url, Map<String, String> param) throws UnknownHostException,SocketTimeoutException {

        // 创建Httpclient对象
        RequestConfig defaultRequestConfig = RequestConfig.custom()
                                                     .setSocketTimeout(3000)
                                                     .setConnectTimeout(3000)
                                                     .setConnectionRequestTimeout(3000)
                                                     .setStaleConnectionCheckEnabled(true)
                                                     .build();
        CloseableHttpClient httpclient = HttpClients.custom()
                                                 .setDefaultRequestConfig(defaultRequestConfig)
                                                 .build();

//        String resultString = "url:"+url;
        String resultString =null;
        List<Header> resultHeader=new ArrayList<>();
        CloseableHttpResponse response = null;
        URI uri = null;
        List<String> resultList = new ArrayList<>();
        try {
            // 创建uri
            URIBuilder uriBuilder = new URIBuilder(url);
            if (param != null) {
                for (Entry<String, String> entry : param.entrySet()) {
                    String key = entry.getKey();
                    uriBuilder.addParameter(key, param.get(key));
                }
            }
            uri = uriBuilder.build();

            // 创建http GET请求
            HttpGet httpGet = new HttpGet(uri);

            // 执行请求
            response = httpclient.execute(httpGet);
//            log.info("[ httpClient ] GET url : {}", uri.toURL());
            String jsonString = JSON.toJSONString(response == null ? "{}" : response);
            resultList.add(jsonString);
//			log.info("[ httpClient ] GET response : {}", jsonString);
//            resultString=resultString+"   responsejson:"+jsonString;
//            resultString=jsonString;
            String resultEntity = EntityUtils.toString(response.getEntity(), "utf-8");

            resultList.add(resultEntity);
            // 判断返回状态是否为200
            if (null != response && response.getStatusLine().getStatusCode() == 200) {
//                resultString = resultString+"  responseEntity:"+EntityUtils.toString(response.getEntity(), "utf-8");
//                entity = EntityUtils.toString(response.getEntity(), "utf-8");
                Header[] headers =response.getAllHeaders();
                for (Header h:headers){
                    log.info("cookis:"+h.getName()+"  value:"+h.getValue());
                    if(h.getValue().indexOf("remeberMe")>=0){
                        resultHeader.add(h);
                    }
                }
            }
            resultString=JsonUtil.writeJson(resultList);
        } catch (UnknownHostException e) {
            log.error("[ httpClient ] GET failed : {}" + uri, e);
            throw e;
        } catch (SocketTimeoutException e) {
            log.error("[ httpClient ] GET failed : {}" + url, e);
            throw e;
        } catch (Exception e) {
            log.error("[ httpClient ] GET failed : {}" + uri, e);
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error("[ httpClient ] Release resources failed : {}", uri, e);
            }
        }
        return resultString;
    }
//    public static List<Header> doLogin(String url, Map<String, String> param) {
    public static String doLogin(String url, Map<String, String> param) {
        // 创建Httpclient对象
        CloseableHttpClient httpclient = getCloseableHttpClient();

//        List<Header> resultHeader=new ArrayList<>();
        String result=null;
        CloseableHttpResponse response = null;
        URI uri = null;
        try {
            // 创建uri
            URIBuilder uriBuilder = new URIBuilder(url);
            if (param != null) {
                for (Entry<String, String> entry : param.entrySet()) {
                    String key = entry.getKey();
                    uriBuilder.addParameter(key, param.get(key));
                }
            }
            uri = uriBuilder.build();

            // 创建http GET请求
            HttpGet httpGet = new HttpGet(uri);

            // 执行请求
            response = httpclient.execute(httpGet);
            log.info("[ httpClient ] GET url : {}", uri.toURL());
//            String jsonString = JSON.toJSONString(response == null ? "{}" : response);
//            log.info("[ httpClient ] GET response : {}", jsonString);

            // 判断返回状态是否为200
            if (null != response && response.getStatusLine().getStatusCode() == 200) {
                Header[] headers =response.getAllHeaders();
                for (Header h:headers){
                    if(h.getName().indexOf("vtoken")>=0){
                        log.info("vtoken:"+h.getName()+"  value:"+h.getValue());
//                        resultHeader.add(h);
//                        String[] str = h.getValue().split(";");
//                        for(int i=0;i<str.length;i++){
//                            if(str[i].indexOf("JSESSIONID")>=0){
//                                result=str[i].replaceAll("JSESSIONID=","");
//                                break;
//                            }
//                        }
                        result=h.getValue();
                        break;
                    }
                }
            }
        } catch (Exception e) {
            log.error("[ httpClient ] GET failed : {}" + uri, e);
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error("[ httpClient ] Release resources failed : {}", uri, e);
            }
        }
//        return resultHeader;
        return result;
    }
    public static String doGet(String url) throws HorizonBizException {
        return doGet(url, null);
    }

    public static String doPost(String url, Map<String, String> param) {
        // 创建Httpclient对象
        CloseableHttpClient httpClient = getCloseableHttpClient();
        CloseableHttpResponse response = null;
        String resultString = null;
        try {
            // 创建Http Post请求
            HttpPost httpPost = new HttpPost(url);

            // 创建参数列表
            if (param != null) {
                List<NameValuePair> paramList = new ArrayList<>();
                for (Entry<String, String> engty : param.entrySet()) {
                	String key = engty.getKey();
                    paramList.add(new BasicNameValuePair(key, param.get(key)));
                }
                // 模拟表单
                UrlEncodedFormEntity entity = new UrlEncodedFormEntity(paramList);
                httpPost.setEntity(entity);
            }
            // 执行http请求
            response = httpClient.execute(httpPost);
            log.info("[ httpClient ] POST url : {}", url);
            String jsonString = JSON.toJSONString(response == null ? "{}" : response);
//			log.info("[ httpClient ] POST response : {}", jsonString);

            if (null != response && response.getStatusLine().getStatusCode() == 200) {
                resultString = EntityUtils.toString(response.getEntity(), "utf-8");
            }
        } catch (Exception e) {
            log.error("[ httpClient ] POST failed : " + url, e);
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error("[ httpClient ] Release resources failed : " + url, e);
            }
        }
        return resultString;
    }

    public static String doPost(String url) {
        return doPost(url, null);
    }

    public static String doPostJsonTest(String url, String json) throws UnknownHostException,SocketTimeoutException {
        // 创建Httpclient对象
        RequestConfig defaultRequestConfig = RequestConfig.custom()
                                                     .setSocketTimeout(3000)
                                                     .setConnectTimeout(3000)
                                                     .setConnectionRequestTimeout(3000)
                                                     .setStaleConnectionCheckEnabled(true)
                                                     .build();
        CloseableHttpClient httpClient = HttpClients.custom()
                                                 .setDefaultRequestConfig(defaultRequestConfig)
                                                 .build();

        CloseableHttpResponse response = null;
//        String resultString = "url:"+url;
        String resultString =null;
        List<String> resultList = new ArrayList<>();
        try {
            // 创建Http Post请求
            HttpPost httpPost = new HttpPost(url);
            // 创建请求内容
            StringEntity entity = new StringEntity(json, ContentType.APPLICATION_JSON);
            httpPost.setEntity(entity);
//            httpPost.addHeader("token","token");
            // 执行http请求
            response = httpClient.execute(httpPost);
            log.info("[ httpClient ] POST url : {}", url);
            String jsonString = JSON.toJSONString(response == null ? "{}" : response);
            log.info("[ httpClient ] POST response : {}", jsonString);
//			resultString=resultString+"   responsejson:"+jsonString;
//            resultString=jsonString;
            resultList.add(jsonString);
            String resultEntity = EntityUtils.toString(response.getEntity(), "utf-8");
            resultList.add(resultEntity);
            if (null != response && response.getStatusLine().getStatusCode() == 200) {
//                resultString = resultString+"  responseEntity:"+EntityUtils.toString(response.getEntity(), "utf-8");
//                String s =EntityUtils.toString(response.getEntity(), "utf-8");

            }
            resultString=JsonUtil.writeJson(resultList);
        } catch (UnknownHostException e) {
            log.error("[ httpClient ] GET failed : {}" + url, e);
            throw e;
        } catch (SocketTimeoutException e) {
            log.error("[ httpClient ] GET failed : {}" + url, e);
            throw e;
        } catch (Exception e) {
            log.error("[ httpClient ] POST failed : {}", url, e);
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error("[ httpClient ] Release resources failed : {}", url, e);
            }
        }
        return resultString;
    }
    public static String doPostJson(String url, String json) {
        // 创建Httpclient对象
        CloseableHttpClient httpClient = getCloseableHttpClient();

        CloseableHttpResponse response = null;
        String resultString = null;
        try {
            // 创建Http Post请求
            HttpPost httpPost = new HttpPost(url);
            // 创建请求内容
            StringEntity entity = new StringEntity(json, ContentType.APPLICATION_JSON);
            httpPost.setEntity(entity);
//            httpPost.addHeader("token","token");
            // 执行http请求
            response = httpClient.execute(httpPost);
            log.info("[ httpClient ] POST url : {}", url);
            String jsonString = JSON.toJSONString(response == null ? "{}" : response);
//			log.info("[ httpClient ] POST response : {}", jsonString);

            if (null != response && response.getStatusLine().getStatusCode() == 200) {
                resultString = EntityUtils.toString(response.getEntity(), "utf-8");
            }
        } catch (Exception e) {
            log.error("[ httpClient ] POST failed : {}", url, e);
            e.printStackTrace();
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error("[ httpClient ] Release resources failed : {}", url, e);
            }
        }
        return resultString;
    }
    public static String  doPostJsonWithToken(String url, String json,String token) throws HorizonBizException {
        // 创建Httpclient对象
        CloseableHttpClient httpClient = getCloseableHttpClient();

        CloseableHttpResponse response = null;
        String resultString = null;
        try {
            // 创建Http Post请求
            HttpPost httpPost = new HttpPost(url);
            // 创建请求内容
            StringEntity entity = new StringEntity(json, ContentType.APPLICATION_JSON);
            httpPost.setEntity(entity);
            httpPost.addHeader("token",token);
            // 执行http请求
            response = httpClient.execute(httpPost);
            log.info("[ httpClient ] POST url : {}", url);
//            String jsonString = JSON.toJSONString(response == null ? "{}" : response);
//            log.info("[ httpClient ] POST response : {}", jsonString);

            if (null != response && response.getStatusLine().getStatusCode() == 200) {
                resultString = EntityUtils.toString(response.getEntity(), "utf-8");
            }
        } catch (UnknownHostException e) {
            log.error("[ httpClient ] GET failed : {}" + url, e);
            throw new HorizonBizException(Constants.Return.HOST_PARSE_ERROR,e.getMessage());
        } catch (HttpHostConnectException e) {
            log.error("[ httpClient ] GET failed : {}" + url, e);
            throw new HorizonBizException(Constants.Return.HOST_CONNECT_ERROR,e.getMessage());
        } catch (Exception e) {
            log.error("[ httpClient ] POST failed : {}", url, e);
            e.printStackTrace();
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error("[ httpClient ] Release resources failed : {}", url, e);
            }
        }
        return resultString;
    }
    public static String doPostJsonTimeout(String url, String json,String token) {
        // 创建Httpclient对象
        RequestConfig defaultRequestConfig = RequestConfig.custom()
                                                     .setSocketTimeout(2000)//socket读数据超时时间：从服务器获取响应数据的超时时间
                                                     .setConnectTimeout(2000)//与服务器连接超时时间：httpclient会创建一个异步线程用以创建socket连接，此处设置该socket的连接超时时间  
                                                     .setConnectionRequestTimeout(1000)//从连接池中获取连接的超时时间 
                                                     .setStaleConnectionCheckEnabled(true)
                                                     .build();
        CloseableHttpClient httpClient = getCloseableHttpClient(defaultRequestConfig);
        CloseableHttpResponse response = null;
        String resultString = null;
        try {
            // 创建Http Post请求
            HttpPost httpPost = new HttpPost(url);
            // 创建请求内容
            StringEntity entity = new StringEntity(json, ContentType.APPLICATION_JSON);
            httpPost.setEntity(entity);
            httpPost.addHeader("token",token);
            // 执行http请求
            response = httpClient.execute(httpPost);
            log.info("[ httpClient ] POST url : {}", url);
            String jsonString = JSON.toJSONString(response == null ? "{}" : response);
//            log.info("[ httpClient ] POST response : {}", jsonString);

            if (null != response && response.getStatusLine().getStatusCode() == 200) {
                resultString = EntityUtils.toString(response.getEntity(), "utf-8");
            }
        } catch (Exception e) {
            log.error("[ httpClient ] POST failed : {}", url, e);
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error("[ httpClient ] Release resources failed : {}", url, e);
            }
        }
        return resultString;
    }
    
}