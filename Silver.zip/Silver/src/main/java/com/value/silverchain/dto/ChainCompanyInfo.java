package com.value.silverchain.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.value.silverchain.model.BasePage;
import com.value.silverchain.model.CompanyInfo;
import lombok.Data;
import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Id;
import org.mongodb.morphia.annotations.Indexed;
import org.mongodb.morphia.utils.IndexDirection;

import java.util.Date;

/**
 * 商户信息上链下链类
 */
@Data
public class ChainCompanyInfo extends BasePage{

    private String pkCompanyInfo;//商户主键
    private String companyName;//商户名称
    private String companyLicense;//商户营业执照号码
    private String companyNo;//商户号
    private String chainAddr;//商户区域链地址
    private String email;//联系邮箱
    private String linkMan;//联系人
    private String linkPhone;//联系电话
    private CompanyInfo.JoinType joinType;//入网方式：银联节点，自建节点
    private CompanyInfo.Status status;//商户状态：正常，暂停， 终止
    private CompanyInfo.CompanyType companyType;//商户类型：UP/其他商户
    private String pkPeerSettingInfo;//商户注册节点主键

    public ChainCompanyInfo(CompanyInfo companyInfo){
        this.setPkCompanyInfo(companyInfo.getPkCompanyInfo());
        this.setCompanyName(companyInfo.getCompanyName());
        this.setCompanyLicense(companyInfo.getCompanyLicense());
        this.setEmail(companyInfo.getEmail());
        this.setCompanyNo(companyInfo.getCompanyNo());
        this.setChainAddr(companyInfo.getChainAddr());
        this.setLinkMan(companyInfo.getLinkMan());
        this.setLinkPhone(companyInfo.getLinkPhone());
        this.setJoinType(companyInfo.getJoinType());
        this.setStatus(companyInfo.getStatus());
        this.setCompanyType(companyInfo.getCompanyType());
        this.setPkPeerSettingInfo(companyInfo.getPkPeerSettingInfo());
    }

    public ChainCompanyInfo() {

    }
}