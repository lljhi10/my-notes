package com.value.silverchain;

import com.mongodb.DuplicateKeyException;
import com.value.silverchain.common.Constants;
import com.value.silverchain.dto.ChainCompanyInfo;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.*;
import com.value.silverchain.service.IBaseRoleService;
import com.value.silverchain.service.IChainService;
import com.value.silverchain.service.IOrgInfoService;
import com.value.silverchain.service.IUserAccountService;
import com.value.silverchain.service.exception.MyException;
import com.value.silverchain.util.MD5;
import com.value.silverchain.vo.Result;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;

/**
 * 初始化线程
 */
@Component("initTask")
@Scope("prototype")
public class InitializeTask extends Thread {

    final static Logger logger = LoggerFactory.getLogger(InitializeTask.class);
    @Autowired
    private IOrgInfoService orgInfoService;

    @Autowired
    private IBaseRoleService baseRoleService;
    @Autowired
    private IUserAccountService userAccountService;

    @Autowired
    private IChainService chainService;
    
    @Override
    public void run() {
        String pkCompanyInfo=null;
        String pkRole=null;
        String pkManagerInfo=null;
        boolean isException=false;
            try {
                logger.info("--------------------initTask start-------------------------------------");
                Properties prop = new Properties();
                InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("init.properties");
                prop.load(new InputStreamReader(is,"UTF-8")); /// 加载属性列表
                CompanyInfo param = new CompanyInfo();
                param.setCompanyName(prop.getProperty("up.companyName"));
                param.setCompanyType(CompanyInfo.CompanyType.valueOf(prop.getProperty("up.companyType")));
                //检查是否已经创建了银联商户
                CompanyInfo companyInfo = orgInfoService.getCompanyInfo(param);
                if (companyInfo == null) {
                    //上链查询UP信息
                    Result result = chainService.queryUPInfo();
                    if(result.verify()){
                        //成功从链上取值
                        if(result.getData().get("upInfo")!=null){
                            logger.info("--------------------同步UP商户-------------------------------------");
                            //有UP商户信息，使用UP商户信息同步本地
                            ChainCompanyInfo chainCompanyInfo = (ChainCompanyInfo)result.getData().get("upInfo");
                            int i =orgInfoService.updateFromChain(chainCompanyInfo);
                            if(i!=1){
                                throw new HorizonBizException(Constants.Return.INIT_COMPANY_ERROR);
                            }
                            param.setPkCompanyInfo(chainCompanyInfo.getPkCompanyInfo());
                            companyInfo=orgInfoService.getCompanyInfoByID(param);
                            if(null==companyInfo){
                                throw new HorizonBizException(Constants.Return.INIT_COMPANY_ERROR);
                            }
                            pkCompanyInfo = chainCompanyInfo.getPkCompanyInfo();
                        }else{
                            //没UP商户信息，开始初始化UP信息
                            //UP商户初始化
                            logger.info("--------------------初始化UP商户-------------------------------------");
                            //如果没有创建，初始化
                            companyInfo= new CompanyInfo();
                            companyInfo.setPkCompanyInfo(UUID.randomUUID().toString());
                            companyInfo.setCompanyName(prop.getProperty("up.companyName"));
                            companyInfo.setCompanyLicense(prop.getProperty("up.companyLicense"));
                            companyInfo.setCompanyNo(prop.getProperty("up.companyNo"));
                            companyInfo.setChainAddr(prop.getProperty("up.chainAddr"));
                            companyInfo.setLinkMan(prop.getProperty("up.linkMan"));
                            companyInfo.setLinkPhone(prop.getProperty("up.linkPhone"));
                            companyInfo.setEmail(prop.getProperty("up.email"));
                            companyInfo.setJoinType(CompanyInfo.JoinType.valueOf(prop.getProperty("up.joinType")));
                            companyInfo.setCompanyType(CompanyInfo.CompanyType.valueOf(prop.getProperty("up.companyType")));
                            companyInfo.setCreateDate(new Date());
                            companyInfo.setStatus(CompanyInfo.Status.NORMAL);
                            String id =orgInfoService.save(companyInfo);
                            if(StringUtils.isBlank(id)){
                                isException=true;
                                throw  new MyException(Constants.Return.INIT_COMPANY_ERROR);
                            }
                            //上链
                            ChainCompanyInfo chainCompanyInfo=new ChainCompanyInfo(companyInfo);
                            pkCompanyInfo=companyInfo.getPkCompanyInfo();
                            chainService.invokeUpInfo(chainCompanyInfo);
                            logger.info("--------------------上链UP商户信息-------------------------------------");
                        }

                        logger.info("--------------------初始化角色-------------------------------------");
                        //如果没有创建，初始化
                        BaseRole baseRole=new BaseRole();
                        baseRole.setPkRole(UUID.randomUUID().toString());
                        baseRole.setRoleName(prop.getProperty("up.role.roleName"));
                        baseRole.setPkCompany(companyInfo.getPkCompanyInfo());
                        baseRole.setStatus(BaseRole.Status.VALID);

                        List<MenuSource> menuList = new ArrayList<>();//菜单权限列表

                        MenuSource menuSource=new MenuSource();
                        menuSource.setMenuName(prop.getProperty("up.role.menuName.company"));
                        List<BaseRight> baseRightList = new ArrayList<>();
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.company.view.name"))));
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.company.edit.name"))));

                        menuSource.setRightList(baseRightList);
                        menuList.add(menuSource);

                        menuSource=new MenuSource();
                        menuSource.setMenuName(prop.getProperty("up.role.menuName.account"));
                        baseRightList = new ArrayList<>();
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.account.view.name"))));
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.account.edit.name"))));

                        menuSource.setRightList(baseRightList);
                        menuList.add(menuSource);

                        menuSource=new MenuSource();
                        menuSource.setMenuName(prop.getProperty("up.role.menuName.peer"));
                        baseRightList = new ArrayList<>();
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.peer.view.name"))));
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.peer.edit.name"))));

                        menuSource.setRightList(baseRightList);
                        menuList.add(menuSource);

                        menuSource=new MenuSource();
                        menuSource.setMenuName(prop.getProperty("up.role.menuName.payService"));
                        baseRightList = new ArrayList<>();
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.payService.view.name"))));
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.payService.edit.name"))));
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.payService.publish.name"))));

                        menuSource.setRightList(baseRightList);
                        menuList.add(menuSource);

                        menuSource=new MenuSource();
                        menuSource.setMenuName(prop.getProperty("up.role.menuName.publishService"));
                        baseRightList = new ArrayList<>();
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.publishService.view.name"))));
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.publishService.edit.name"))));
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.publishService.publish.name"))));


                        menuSource.setRightList(baseRightList);
                        menuList.add(menuSource);

                        menuSource=new MenuSource();
                        menuSource.setMenuName(prop.getProperty("up.role.menuName.viewService"));
                        baseRightList = new ArrayList<>();
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.viewService.view.name"))));

                        menuSource.setRightList(baseRightList);
                        menuList.add(menuSource);

                        menuSource=new MenuSource();
                        menuSource.setMenuName(prop.getProperty("up.role.menuName.publishSmart"));
                        baseRightList = new ArrayList<>();
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.publishSmart.view.name"))));
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.publishSmart.edit.name"))));
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.publishSmart.publish.name"))));

                        menuSource.setRightList(baseRightList);
                        menuList.add(menuSource);

                        menuSource=new MenuSource();
                        menuSource.setMenuName(prop.getProperty("up.role.menuName.aproverSmart"));
                        baseRightList = new ArrayList<>();
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.aproverSmart.view.name"))));
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.aproverSmart.approver.name"))));

                        menuSource.setRightList(baseRightList);
                        menuList.add(menuSource);

                        menuSource=new MenuSource();
                        menuSource.setMenuName(prop.getProperty("up.role.menuName.dealTotal"));
                        baseRightList = new ArrayList<>();
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.dealTotal.view.name"))));

                        menuSource.setRightList(baseRightList);
                        menuList.add(menuSource);

                        menuSource=new MenuSource();
                        menuSource.setMenuName(prop.getProperty("up.role.menuName.role"));
                        baseRightList = new ArrayList<>();
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.role.view.name"))));
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.role.edit.name"))));

                        menuSource.setRightList(baseRightList);
                        menuList.add(menuSource);

                        menuSource=new MenuSource();
                        menuSource.setMenuName(prop.getProperty("up.role.menuName.manager"));
                        baseRightList = new ArrayList<>();
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.manager.view.name"))));
                        baseRightList.add(new BaseRight(BaseRight.RightName.valueOf(prop.getProperty("up.role.menuName.manager.edit.name"))));

                        menuSource.setRightList(baseRightList);
                        menuList.add(menuSource);

                        baseRole.setMenuList(menuList);
                        baseRole.setCreateDate(new Date());
                        String id2 =baseRoleService.save(baseRole);
                        if(StringUtils.isBlank(id2)){
                            isException=true;
                            throw  new MyException(Constants.Return.INIT_COMPANY_ERROR);
                        }

                        pkRole=baseRole.getPkRole();
                        logger.info("--------------------初始化管理员-------------------------------------");
                        //如果没有创建,初始化
                        ManagerInfo managerInfo=new ManagerInfo();
                        managerInfo.setPkManagerInfo(UUID.randomUUID().toString());
                        managerInfo.setCompanyName(prop.getProperty("up.companyName"));
                        managerInfo.setManagerName(prop.getProperty("up.manager.managerName"));
                        managerInfo.setManagerNumber(prop.getProperty("up.manager.managerNumber"));
                        managerInfo.setPassword(MD5.strMD5(companyInfo.getCompanyName()+prop.getProperty("up.manager.password")));
                        managerInfo.setStatus(ManagerInfo.Status.VALID);
                        managerInfo.setPkCompanyInfo(companyInfo.getPkCompanyInfo());
                        List<String> pkRoles = new ArrayList<>();
                        pkRoles.add(baseRole.getPkRole());
                        managerInfo.setPkRoles(pkRoles);
                        managerInfo.setCreateDate(new Date());
                        String id3 =userAccountService.save(managerInfo);
                        pkManagerInfo=managerInfo.getPkManagerInfo();
                        if(StringUtils.isBlank(id3)){
                            isException=true;
                            throw  new MyException(Constants.Return.INIT_COMPANY_ERROR);
                        }
                    }else{
                        //连接银链失败，不做初始化
                    }

                }
                logger.info("--------------------initTask end-------------------------------------");
//            } catch (InterruptedException e) {
//                e.printStackTrace();
            }catch (DuplicateKeyException e) {
                e.printStackTrace();
                isException=true;
            } catch (IOException e) {
                e.printStackTrace();
                isException=true;
            } catch (MyException e) {
                e.printStackTrace();
                isException=true;
            } catch (HorizonBizException e) {
                e.printStackTrace();
                isException=true;
            }catch (Exception e) {
                e.printStackTrace();
                isException=true;
            } finally {
                if(isException){
                    logger.info("--------------------初始化失败回滚-------------------------------------");
                    if (pkCompanyInfo != null) {
                        orgInfoService.realDelete(pkCompanyInfo);
                    }
                    if (pkRole != null) {
                        baseRoleService.realDelete(pkRole);
                    }
                    if (pkManagerInfo != null) {
                        userAccountService.realDelete(pkManagerInfo);
                    }
                }
            }
    }



}
