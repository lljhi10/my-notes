package com.value.silverchain.service;

import com.value.silverchain.bo.PageBo;
import com.value.silverchain.model.ManagerInfo;
import org.mongodb.morphia.query.UpdateResults;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: za-lvjian
 * Date: 2017/7/28 17:00
 * DESC:
 */
public interface IUserAccountService {

    String save(ManagerInfo userAccount);
    ManagerInfo getByUserID(ManagerInfo param);
    ManagerInfo getByUserNumber(ManagerInfo param);
    PageBo<ManagerInfo> findPage(ManagerInfo param);
    String delete(ManagerInfo param);
    int update(ManagerInfo param);

    void realDelete(String pkManagerInfo);

    /**
     * 修改密码
     * @param managerInfo
     * @return
     */
    int updatePassword(ManagerInfo managerInfo);
}
