package com.value.silverchain.vo;

import com.value.silverchain.model.CompanyInfo;
import lombok.Data;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: 2018/7/27
 * DESC:传递给页面的客户信息类
 */
@Data
public class CompanyInfoPage {
    private String pkCompanyInfo;//商户主键
    private String companyName;//商户名称

    public CompanyInfoPage(CompanyInfo companyInfo) {
        this.pkCompanyInfo=companyInfo.getPkCompanyInfo();
        this.companyName=companyInfo.getCompanyName();
    }
}
