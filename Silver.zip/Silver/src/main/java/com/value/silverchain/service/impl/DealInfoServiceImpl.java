package com.value.silverchain.service.impl;

import com.value.silverchain.bo.PageBo;
import com.value.silverchain.model.CompanyInfo;
import com.value.silverchain.model.DealInfo;
import com.value.silverchain.model.ManagerInfo;
import com.value.silverchain.service.IDealInfoService;
import com.value.silverchain.service.IOrgInfoService;
import org.apache.commons.lang3.StringUtils;
import org.bson.types.ObjectId;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.query.CriteriaContainerImpl;
import org.mongodb.morphia.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class DealInfoServiceImpl implements IDealInfoService {

    @Autowired
    private Datastore datastore;
    @Autowired
    private IOrgInfoService orgInfoService;
    @Override
    public PageBo<DealInfo> findPage(DealInfo param,ManagerInfo managerInfo) {
        Query<DealInfo> query = datastore.find(DealInfo.class);

        //判断当前用户是否是UP
        CompanyInfo company = new CompanyInfo();
        company.setPkCompanyInfo(managerInfo.getPkCompanyInfo());
        company = orgInfoService.getCompanyInfoByID(company);
        if(company != null && !company.getCompanyType().equals(CompanyInfo.CompanyType.UP)) {
            CriteriaContainerImpl receiptPkCompanyInfoQuery = query.criteria("receiptPkCompanyInfo").equal(company.getPkCompanyInfo());
            CriteriaContainerImpl payPkCompanyInfoQuery = query.criteria("payPkCompanyInfo").equal(company.getPkCompanyInfo());
            query.or(receiptPkCompanyInfoQuery,payPkCompanyInfoQuery);
        }


        if(StringUtils.isNotBlank(param.getDealNo())) {
            query.field("dealNo").contains(param.getDealNo());
        }
        if(StringUtils.isNotBlank(param.getPayPkCompanyInfo())){
            query.field("payPkCompanyInfo").in(Arrays.asList(param.getPayPkCompanyInfo().split(",")));
        }
        query.offset(param.getPageNo() * param.getPageSize() - param.getPageSize());
        query.limit(param.getPageSize());
        query.order("-dealDate,merId,-dealNo");

        List<DealInfo> dealInfoList = query.asList();
        for (DealInfo item : dealInfoList){
            CompanyInfo companyInfo = new CompanyInfo();

            companyInfo.setPkCompanyInfo(item.getPayPkCompanyInfo());
            companyInfo = orgInfoService.getCompanyInfoByID(companyInfo);
            if (companyInfo != null) {
                item.setPayCompany(companyInfo.getCompanyName());
            }
            companyInfo.setPkCompanyInfo(item.getReceiptPkCompanyInfo());
            companyInfo = orgInfoService.getCompanyInfoByID(companyInfo);
            if (companyInfo != null) {
                item.setReceiptCompany(companyInfo.getCompanyName());
            }

        }

        return new PageBo(dealInfoList,query.count());
    }

    @Override
    public String save(DealInfo dealInfo) {
        Key<DealInfo> key = datastore.save(dealInfo);
        return ((ObjectId) key.getId()).toHexString();
    }

    @Override
    public DealInfo getDealByToken(String dealToken) {
        Query<DealInfo> query = datastore.find(DealInfo.class).field("dealToken").equal(dealToken);
        if (query.count()==1){
            return query.get();
        }
        return null;
    }

    @Override
    public DealInfo getDealByDealNo(String dealNo) {
        Query<DealInfo> query = datastore.find(DealInfo.class).field("dealNo").equal(dealNo);
        if (query.count()==1){
            return query.get();
        }
        return null;
    }
}
