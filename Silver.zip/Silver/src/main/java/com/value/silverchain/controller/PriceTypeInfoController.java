package com.value.silverchain.controller;

import com.mongodb.DuplicateKeyException;
import com.value.silverchain.bo.PageBo;
import com.value.silverchain.common.Constants;
import com.value.silverchain.exception.HorizonBizException;
import com.value.silverchain.model.ManagerInfo;
import com.value.silverchain.model.PriceTypeInfo;
import com.value.silverchain.service.IChainService;
import com.value.silverchain.service.IPriceTypeService;
import com.value.silverchain.vo.LoginManager;
import com.value.silverchain.vo.PriceTypeRequest;
import com.value.silverchain.vo.Result;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: lilai chenlin
 * Date: ${date}
 * DESC:智能APP
 */
@Controller
@RequestMapping("/pricetype/v1")
public class PriceTypeInfoController {

    private Logger logger = LoggerFactory.getLogger(PriceTypeInfoController.class);
    @Autowired
    private IPriceTypeService priceTypeService;

    @Autowired
    private IChainService chainService;

    /**
     * 创建价格类型
     * @param priceTypeInfo
     * @param session
     * @return
     */
    @RequestMapping("/create")
    @ResponseBody
    public String create(@RequestBody PriceTypeInfo priceTypeInfo, HttpSession session){

        Result result = checkNull(priceTypeInfo);//参数非空验证
        if (!result.verify()){
            return result.toJson();
        }else{
            try {

                //检查权限
                LoginManager loginManager = (LoginManager)session.getAttribute("loginManager");
                if(null==loginManager){
                    throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
                }
                if(!loginManager.isUp()){//不是UP商户的管理员，没有创建权限
                    throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
                }
                Date date = new Date();
                ManagerInfo loginUser = loginManager.getLoginUser();
                priceTypeInfo.setPkPriceTypeInfo(UUID.randomUUID().toString());
                priceTypeInfo.setCreateManager(loginUser.getPkManagerInfo());
                priceTypeInfo.setCreateDate(date);
                priceTypeInfo.setStatus(PriceTypeInfo.Status.NORMAL);
                
                String id =priceTypeService.save(priceTypeInfo);
                if(StringUtils.isBlank(id)){
                    throw new HorizonBizException(Constants.Return.CREATE_PRICE_TYPE_INFO_FALSE);
                }
                //上链
//                chainService.invokePriceTypeInfo();
            } catch (DuplicateKeyException e) {
                result.setState(Constants.Return.ACCT_ID_REPEAT);
            } catch (HorizonBizException e) {
                result.setState(e.getError());
            }catch (Exception e) {
                result.setState(Constants.Return.CREATE_PRICE_TYPE_INFO_FALSE);
            }
        }
        return result.toJson();
    }


    /*参数非空验证
    * */
    private Result checkNull(PriceTypeInfo priceTypeInfo) {
            Result result = new Result();
        if (StringUtils.isBlank(priceTypeInfo.getPriceTypeName())){
            logger.info("--------------------新建价格类型错误:价格类型名称不能为空！-------------------------------------");
            result.setState(Constants.Return.PRICETYPE_NAME_NULL);
        } else if (priceTypeInfo.getTargetType() == null
                           ||(priceTypeInfo.getTargetType().equals(PriceTypeInfo.TargetType.TARGET)&&(priceTypeInfo.getTargetCompany()==null||priceTypeInfo.getTargetCompany().size()<=0))//指定商户时，没有商户数据
                           ||(priceTypeInfo.getTargetType().equals(PriceTypeInfo.TargetType.OPEN)&&priceTypeInfo.getTargetCompany()!=null&&priceTypeInfo.getTargetCompany().size()>0)//公开时，商户有数据
                       ) {
            logger.info("--------------------新建价格类型错误: 目标商户类型为空 或 指定商户时没有商户数据 或 公开时商户有数据！-------------------------------------");
            result.setState(Constants.Return.TARGETTYPE_NULL);
        } 

            return result;

    }

   


    /**
     * 查询明细
     * @param param
     * @param session
     * @return
     */
    @RequestMapping("/findById")
    @ResponseBody
    public String findbyId(@RequestBody PriceTypeRequest param, HttpSession session){
        Result result = new Result();
        if(StringUtils.isBlank(param.getPkPriceTypeInfo())) {
            result.setState(Constants.Return.PKPRICETYPENFO_NULL);
            return result.toJson();
        }
        try {
            //检查权限
            LoginManager loginManager = (LoginManager)session.getAttribute("loginManager");
            if(null==loginManager){
                throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
            }
            if(!loginManager.isUp()){//不是UP商户的管理员，没有查看权限
                throw new HorizonBizException(Constants.Return.TIGTH_LESS_THAN);
            }

            PriceTypeInfo priceTypeInfo =priceTypeService.getByKey(param.getPkPriceTypeInfo());
            
            result.getData().put("priceTypeInfo",priceTypeInfo);
        } catch (DuplicateKeyException e) {
            e.printStackTrace();
            result.setState(Constants.Return.ACCT_ID_REPEAT);
        } catch (HorizonBizException e) {
            result.setState(e.getError());
        }catch (Exception e) {
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }


    /**
     * 分页查找
     * @param priceTypeInfo
     * @param requst
     * @return
     */
    @RequestMapping("/findByPage")
    @ResponseBody
    public String findByPage(@RequestBody PriceTypeInfo priceTypeInfo,HttpServletRequest requst){
        Result result = new Result();
        
        try {
            LoginManager loginUser = (LoginManager)requst.getSession().getAttribute("loginManager");
            if(null==loginUser){
                throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
            }
            PageBo<PriceTypeInfo> smartAppInfos = priceTypeService.findPage(priceTypeInfo);
            result.getData().put("list",smartAppInfos);
        } catch (DuplicateKeyException e) {
            e.printStackTrace();
            result.setState(Constants.Return.ACCT_ID_REPEAT);
        } catch (HorizonBizException e) {
//            e.printStackTrace();
            result.setState(e.getError());
        }catch (Exception e) {
            e.printStackTrace();
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }

    /**
     * 分页查找
     * @param requst
     * @return
     */
    @RequestMapping("/findAll")
    @ResponseBody
    public String findAll(HttpServletRequest requst){
        Result result = new Result();

        try {
            LoginManager loginUser = (LoginManager)requst.getSession().getAttribute("loginManager");
            if(null==loginUser){
                throw new HorizonBizException(Constants.Return.USER_NOT_LOGIN);
            }
            List<PriceTypeInfo> List = priceTypeService.findAll(loginUser.getCompanyInfo().getPkCompanyInfo());
            result.getData().put("list",List);
        } catch (DuplicateKeyException e) {
            e.printStackTrace();
            result.setState(Constants.Return.ACCT_ID_REPEAT);
        } catch (HorizonBizException e) {
//            e.printStackTrace();
            result.setState(e.getError());
        }catch (Exception e) {
            e.printStackTrace();
            result.setState(Constants.Return.SYSTEM_ERR);
        }
        return result.toJson();
    }

}
