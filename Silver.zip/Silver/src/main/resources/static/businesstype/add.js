$(function () {
    var page = function () {
        var v = new Vue({
            el: ".content-body",
            data: {
                "companyName": userInfo.companyInfo.companyName,
                "apiTypeName": "",
                "description": "",
                "targetType": "OPEN",
                "company": [],
            },
            methods: {
                Delete: function (index) {
                    console.log("jinlaile");
                    var item = this.company.splice(index, 1)[0];
                    var data = vModal.list;
                    for (var i = 0; i < data.length; i++) {
                        if (data[i].pkCompanyInfo == item.id) {
                            data[i].checked = false;
                            break;
                        }
                    }
                },
                hello:function () {
                    alert("hello")
                }
            }
        });

        var vModal = new Vue({
            el: "#modal-smartapp-company",
            data: {
                key: "",
                list: [],
                total: 30,
                index: 1,
                size: 10
            },
            computed: {
                count: function () {
                    return Math.ceil(this.total / this.size);
                },
                pagination: pagination
            },
            methods: {
                find: findCompany,
                confirm: function () {
                    for (var i = 0; i < this.list.length; i++) {
                        if (this.list[i].checked) {
                            var exists = false;
                            for (var j = 0; j < v.company.length; j++) {
                                if (v.company[j].id == this.list[i].pkCompanyInfo) {
                                    exists = true;
                                    break;
                                }
                            }

                            if (!exists) {
                                v.company.push({
                                    id: this.list[i].pkCompanyInfo,
                                    name: this.list[i].companyName
                                });
                            }

                        }
                    }

                    $("#modal-smartapp-company").modal("hide");
                }
            }
        });

        $(".btn-search").click(function () {
            findCompany(1);
        });

        $(".btn-add-company").click(function () {
            console.log(111111);
            $("#modal-smartapp-company").modal("show");
        });

        function findCompany(index, e) {
            e && e.preventDefault();

            modal.loading();
            vModal.list = [];
            api.allCompany(index, vModal.key,null,null).done(function (res) {
                console.log(res);
                if (res.code == 0) {
                    if (res.data.list == null) {
                        modal.alert("提示", "权限不足", function () {
                            load("./businesstype/index");
                        });
                        return;
                    }
                    var data = res.data.list.rows;
                    for (var i = 0; i < data.length; i++) {

                        data[i].checked = false;
                        for (var j = 0; j < v.company.length; j++) {
                            if (v.company[j].id == data[i].pkCompanyInfo) {
                                data[i].checked = true;
                                break;
                            }
                        }
                    }
                    vModal.list = data;
                    vModal.index = index;
                    vModal.total = res.data.list.total;
                    console.log("data", vModal.$data);
                }
                else {
                    console.info(res);
                }
            }).fail(function (res) {
                modal.alert("提示", "网络超时");
            }).always(function () {
                modal.loading(false);
            });

        }

        findCompany(1);

        $(".content-body").show().bootstrapValidator({
            message: 'This value is not valid',
            live: 'enabled',
            //submitButtons: '.btn-save',
            feedbackIcons: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            }
        });

        $(".btn-save").click(function (e) {
            e.preventDefault();
            if (v.targetType == "TARGET" && v.company.length == 0) {
                modal.alert("提示", "请选择指定商户");
                return;
            }

            //获取表单对象
            var bootstrapValidator = $(".content-body").data('bootstrapValidator');
            //手动触发验证
            bootstrapValidator.validate();
            if (bootstrapValidator.isValid()) {
                v.$data.targetCompany = [];
                for (var i = 0; i < v.company.length; i++) {
                    v.$data.targetCompany.push(v.company[i].id);
                }

                modal.loading(true);
                api.addApiType(v.$data).done(function (res) {
                    modal.loading(false);
                    if (res.code == 0) {
                        modal.alert("提示", "保存成功", function () {
                            load("./businesstype/index");
                        });
                    }
                    else {
                        modal.alert("提示", res.msg);
                    }
                }).fail(function (res) {
                    modal.loading(false);
                    modal.alert("错误", "网络超时");
                });
                return false;
            }
        });





        this.unload = function () {
            console.log("unload add");
        }
    }

    pages.push(new page());
})
