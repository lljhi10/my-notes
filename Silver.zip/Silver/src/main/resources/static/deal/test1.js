$(function () {
    var page = function () {
        var chart = null; // 定义全局变量
        $(document).ready(function() {
            chart = Highcharts.chart('container', {
                chart: {
                    type: 'spline',
                    events: {
                        load: requestData // 图表加载完毕后执行的回调函数
                    }
                },
                title: {
                    text: 'Live random data'
                },
                xAxis: {
                    type: 'datetime',
                    tickPixelInterval: 150,
                    maxZoom: 20 * 1000
                },
                yAxis: {
                    minPadding: 0.2,
                    maxPadding: 0.2,
                    title: {
                        text: 'Value',
                        margin: 80
                    }
                },
                series: [{
                    name: '随机数据',
                    data: []
                }]
            });
        });
        $(".content-body").show();

    }



    pages.push(new page());
})
