$(function () {
    var page = function () {
        var data = {}
        console.log("load company");
        var v = new Vue({
            el: ".content-body",
            data: {
                key: "",
                list: [],
                total: 1,
                index: 1,
                size: 10,
                logList:[],
                items:[],
                payPkCompanyInfo:""
            },
            computed: {
                count: function () {
                    return Math.ceil(this.total / this.size);
                },
                pagination: pagination
            },
            methods: {
                find: find,
                showLog:showLog,
                queryCompanyList:queryCompanyList
            }
        });
        $(".selectpicker").selectpicker({
            noneSelectedText : '请选择'//默认显示内容
        });

        //查找商户列表
        function queryCompanyList() {
            api.queryCompanyList().done(function (res) {
                if (res.code == 0) {
                    v.items = res.data.list;
                    var select = $("#slpk");
                    for(var i=0;i<v.items.length;i++){
                        select.append("<option value='"+v.items[i].pkCompanyInfo+"'>"
                            + v.items[i].companyName + "</option>");
                    }
                    $('.selectpicker').selectpicker('refresh');
                }
            }).fail(function (res) {
                console.error(res);
            });
        }
        v.queryCompanyList();
        v.find(1);
        $(".content-body").show();

        function find(index, e) {
            e && e.preventDefault();

            modal.loading();
            v.list = [];
            v.payPkCompanyInfo=$("#slpk").selectpicker('val').join(",");
            
            //data.pageNo = v.index;
            //data.pageSize = v.size;
            //data.dealNo = v.key;
            api.findDeal(index,v).done(function (res) {
                console.log(res);
                if (res.code == 0) {
                    v.list = res.data.list.rows;
                    v.index = index;
                    v.total = res.data.list.total;
                }
                else {
                    console.info(res);
                }
            }).fail(function (res) {
                console.error(res);
            }).always(function () {
                modal.loading(false);
            });
        }

        function showLog(item) {
            modal.loading();
            v.logList = [];
            api.findLog(item).done(function (res) {
                if (res.code == 0) {
                    //不全?
                    v.logList = res.data.logList;
                    v.total = res.data.total;
                } else {
                    console.info(res);
                }
            }).fail(function (res) {
                console.error(res);
            }).always(function () {
                // console.log(0)
                modal.loading(false);
            });

        }

        $(".btn-search").click(function () {
            data.pageNo = v.index;
            data.pageSize = v.size;
            data.dealNo = v.key;
            v.find(1);
        });
        

        this.unload = function () {
            v = null;
        }
    }



    pages.push(new page());
})
