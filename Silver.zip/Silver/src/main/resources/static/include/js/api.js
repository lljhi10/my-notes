"use strict";
var root = "";//"http://192.168.3.61:8075"    http://192.168.3.254:8075
var api = {};

api.post = function (url, data) {
    if (typeof (data) == "object") {
        data = JSON.stringify(data);
    }
    return $.ajax({
        url: url,
        data: data,
        dataType: "json",
        method: "post",
        processData: false,
        contentType: "application/json"
    });
}
//登录
api.login = function (data) {
    var url = root + "/login/v1/login";
    return api.post(url, data);
}
//查询商户列表
api.listCompany = function (index, key, size) {
    var url = root + "/orginfo/v1/findByPage?test=test";
    var data = {
        pageNum: index || 1,
        pageSize: size || 10,
        companyName: key
    }
    return api.post(url, data);
}
//查询商户列表
api.allCompany = function (index, key, size, type) {
    var url = root + "/orginfo/v1/findAllByPage?test=test";
    var data = {
        pageNum: index || 1,
        pageSize: size || 10,
        companyName: key,
        findType: type
    }
    return api.post(url, data);
}
//查询商户列表
api.listCompanyByServices = function (index, key, size) {
    var url = root + "/orginfo/v1/findAllByServicePage?test=test";
    var data = {
        pageNum: index || 1,
        pageSize: size || 10,
        companyName: key
    }
    return api.post(url, data);
}
//查询所有商户
api.queryCompanyList = function () {
    var url = root + "/orginfo/v1/findAll?test=test";
    return api.post(url);
}
//增加商户
api.addCompany = function (data) {
    var url = root + "/orginfo/v1/create?test=test";
    return api.post(url, data);
}
//根据id查询商户
api.selectCompany = function (id) {
    var url = root + "/orginfo/v1/findById?test=test";
    var data = {
        sid: id
    }
    return api.post(url, data);
}
//修改商户
api.updateCompany = function (data) {
    var url = root + "/orginfo/v1/edit?test=test";
    return api.post(url, data);
}
//查询业务账户列表
api.listAccount = function (index, key) {
    var url = root + "/business/v1/findByPage?test=test";
    var data = {
        pageNum: index || 1,
        pageSize: 10,
        accountName: key
    }
    return api.post(url, data);
}
//增加业务账户
api.addAccount = function (data) {
    var url = root + "/business/v1/create?test=test";
    return api.post(url, data);
}
//根据id查询业务账户
api.selectAccount = function (id) {
    var url = root + "/business/v1/findById?test=test";
    var data = {
        sid: id
    }
    return api.post(url, data);
}
//修改业务账户
api.updateAccount = function (data) {
    var url = root + "/business/v1/edit?test=test";
    return api.post(url, data);
}
//查询节点列表
api.listPeersetting = function (index, key) {
    var url = root + "/peersetting/v1/findByPage?test=test";
    var data = {
        pageNum: index || 1,
        pageSize: 10,
        peerSettingName: key
    }
    return api.post(url, data);
}
//添加节点
api.addPeersetting = function (data) {
    var url = root + "/peersetting/v1/create?test=test";
    return api.post(url, data);
}
//修改节点
api.updatePeersetting = function (data) {
    var url = root + "/peersetting/v1/edit?test=test";
    return api.post(url, data);
}
//根据id查询节点
api.selectPeersetting = function (id) {
    var url = root + "/peersetting/v1/findById?test=test";
    var data = {
        sid: id
    }
    return api.post(url, data);
}
//查询智能应用列表
api.listSmartapp = function (index, key, type) {
    var url = root + "/smartapp/v1/findByPage?test=test";
    var data = {
        pageNum: index || 1,
        pageSize: 10,
        smartAppName: key,
        findType: type
    }
    return api.post(url, data);
}
//增加智能应用
api.addSmartapp = function (data) {
    var url = root + "/smartapp/v1/create?test=test";
    return api.post(url, data);
}
//从后台自动生成aid
api.getAID = function (data) {
    var url = root + "/smartapp/v1/getAID?test=test";
    return api.post(url, data);
}
//修改智能应用(未发布的)
api.updateSmartapp = function (data) {
    var url;
    if (data.aprover == "UNAPROVER") {
        url = root + "/smartapp/v1/publish?test=test";
    } else {
        url = root + "/smartapp/v1/edit?test=test";
    }

    return api.post(url, data);
}
//修改智能应用(已经发布的)
api.updateSmartapp2 = function (data) {
    var url = root + "/smartapp/v1/edit2?test=test";
    return api.post(url, data);
}
//删除智能应用
api.deleteSmartapp = function (id) {
    var url = root + "/smartapp/v1/delete?test=test";
    var data = {
        sid: id
    }
    return api.post(url, data);
}
api.verifySmartapp = function (id) {
    var url = root + "/smartapp/v1/verify?test=test";
    var data = {
        sid: id
    }
    return api.post(url, data);
}
//根据id查询智能应用
api.selectSmartapp = function (id) {
    var url = root + "/smartapp/v1/findById?test=test";
    var data = {
        sid: id,
        findType: 1
    }
    return api.post(url, data);
}

//查询支付接口列表
api.listPayapi = function (index, key, size) {
    var url = root + "/service/v1/pay/page?test=test";
    var data = {
        pageNum: index || 1,
        pageSize: size || 10,
        apiName: key
    }
    return api.post(url, data);
}
//增加支付接口
api.addPayapi = function (data) {
    var url = root + "/service/v1/pay/create?test=test";
    return api.post(url, data);
}
//修改未发布 的支付接口
api.updatePayapi = function (data) {
    var url = root + "/service/v1/pay/edit?test=test";
    return api.post(url, data);
}
//修改已发布 的支付接口2
api.updatePayapi2 = function (data) {
    var url = root + "/service/v1/pay/edit2?test=test";
    return api.post(url, data);
}
//根据id查询支付接口
api.selectPayapi = function (id) {
    var url = root + "/service/v1/pay/find?test=test";
    return api.post(url, id);
}

//根据id查询支付接口
api.selectRate = function (t1, t2, target) {
    var url = root + "/service/v1/pay/rate?test=test";
    if (target == null || target.length == 0) target = [""];
    var data = {
        "targetCompany": target,
        "apiType": t1,
        "payType": t2
    }
    return api.post(url, data);
}

//查询服务接口列表
api.listServicesapi = function (index, key, type) {
    var url = root + "/service/v1/service/page?test=test";
    var data = {
        pageNum: index || 1,
        pageSize: 10,
        apiName: key,
        findType: type
    }
    return api.post(url, data);
}
//增加服务接口
api.addServicesapi = function (data) {
    var url = root + "/service/v1/service/create?test=test";
    return api.post(url, data);
}
//更新未发布的服务接口
api.updateServicesapi = function (data) {
    var url;
    /*if (data.publish == "EFFICIENT") {
        url = root + "/service/v1/service/publish?test=test";
    } else {
        url = root + "/service/v1/service/edit?test=test";
    }*/
    url = root + "/service/v1/service/edit?test=test";
    return api.post(url, data);
}
//更新已发布的服务接口
api.updateServicesapi2 = function (data) {
    var url;

    url = root + "/service/v1/service/edit2?test=test";
    return api.post(url, data);
}
//根据id查询服务接口
api.selectServicesapi = function (id) {
    var url = root + "/service/v1/service/find?test=test";
    return api.post(url, id);
}
//账号管理相关接口
api.addManager = function (data) {
    var url = root + "/orguser/v1/register?test=test";
    return api.post(url, data);
}
//删除用户
api.deleteManager = function (id) {
    var url = root + "/orguser/v1/delete?test=test";
    var data = {
        sid: id
    }
    return api.post(url, data);
}
//管理员重置用户密码
api.managerResetPassword = function (id) {
    var url = root + "/login/v1/resetPassword?test=test";
    var data = {
        sid: id
    }
    return api.post(url, data);
}

//用户修改密码
api.managerEditPassword = function (data) {
    var url = root + "/login/v1/editPassword?test=test";
    return api.post(url, data);
}
//修改用户
api.updateManager = function (data) {
    var url = root + "/orguser/v1/edit?test=test";
    return api.post(url, data);
}
//修改用户
api.findByManagerId = function (id) {
    var url = root + "/orguser/v1/findById?test=test";
    var data = {
        sid: id
    }
    return api.post(url, data);
}
//分页查询用户
api.fundByManagerPage = function (index, key) {
    var url = root + "/orguser/v1/findByPage?test=test";
    var data = {
        pageNum: index,
        pageSize: 10,
        managerNumber: key
    }
    return api.post(url, data);
}
//角色管理相关接口
api.fundByRoleId = function (id) {
    var url = root + "/role/v1/findById?test=test";
    var data = {
        sid: id
    }
    return api.post(url, data);
}

//分页查询角色
api.fundByRolePage = function (index, key) {
    var url = root + "/role/v1/findByPage?test=test";
    var data = {
        pageNum: index,
        pageSize: 10,
        roleName: key
    }
    return api.post(url, data);
}
//添加角色
api.addRole = function (data) {
    var url = root + "/role/v1/create?test=test";
    return api.post(url, data);
}

api.updateRole = function (data) {
    var url = root + "/role/v1/edit?test=test";
    return api.post(url, data);
}
//按id查找角色
api.findByRoleId = function (id) {
    var url = root + "/role/v1/findById?test=test";
    var data = {
        sid: id
    }
    return api.post(url, data);
}
//删除角色
api.deleteRole = function (id) {
    var url = root + "/role/v1/delete?test=test";
    var data = {
        sid: id
    }
    return api.post(url, data);
}
//查找属于当前的商户的角色
api.findRoleAll = function () {
    var url = root + "/role/v1/findRoleAll?test=test";
    return api.post(url);
}
//列出交易流水
api.findDeal = function (index, v) {
    var url = root + "/txreport/v1/findByPage?test=test";
    var data = {
        pageNum: index,
        pageSize: 10,
        dealNo: v.key,
        payPkCompanyInfo: v.payPkCompanyInfo
    }
    return api.post(url, data);
}
//查询流水上链日志
api.findLog = function (item, index) {
    var url = root + "/txreport/v1/queryLog?test=test";
    var data = {
        pageNum: index,
        pageSize: 10,
        aid: item.aid,
        dealNo: item.dealNo,
        merId: item.merId
    }
    return api.post(url, data);
}
//注销登录
api.logout = function () {
    var url = root + "/login/v1/logout?test=test";
    return api.post(url);
}
//查询业务类型
api.findApiType = function (index, v) {
    var url = root + "/apitype/v1/findByPage?test=test";
    var data = {
        pageNum: index,
        pageSize: 10,
        apiTypeName: v.key,
    }
    return api.post(url, data);
}
//添加业务类型
api.addApiType = function (data) {
    var url = root + "/apitype/v1/create?test=test";
    return api.post(url, data);
}
//根据id查业务类型
api.selectApiTypeById = function (id) {
    var url = root + "/apitype/v1/findById?test=test";
    var data={
        pkApiTypeInfo:id
    }
    return api.post(url, data);
}
//获取当前用户信息
api.getUserInfo = function () {
    var url = root + "/login/v1/right?test=test";
    return api.post(url, {});
}
//修改未发布 的支付接口
api.updateApiType = function (data) {
    var url = root + "/apitype/v1/findById?test=test";
    return api.post(url, data);
}

//查询所有价格类型
api.findPriceType = function (index, v) {
    var url = root + "/pricetype/v1/findByPage?test=test";
    var data = {
        pageNum: index,
        pageSize: 10,
        priceTypeName: v.key,
    }
    return api.post(url, data);
}
//添加价格类型
api.addPriceType = function (data) {
    var url = root + "/pricetype/v1/create?test=test";
    return api.post(url, data);
}
//根据id查价格类型
api.selectPriceTypeById = function (id) {
    var url = root + "/pricetype/v1/findById?test=test";
    var data={
        pkPriceTypeInfo:id
    }
    return api.post(url, data);
}
//生成私钥
api.getPrivkey = function () {
    var url = root + "/blockChain/v1/account/create?test=test";
    return api.post(url, {});
}

$.ajaxSetup({
    beforeSend: function (xhr) {
        xhr.setRequestHeader('token', sessionStorage.getItem("token"))
    }
});
