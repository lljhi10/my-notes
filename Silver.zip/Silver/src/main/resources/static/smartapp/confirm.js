$(function () {
    var page = function () {
        var v;
        var previousPage = cache.get("previousPage",true);
        modal.loading();
        api.selectSmartapp(cache.get("smartapp-id")).done(function (res) {
            if (res.code == 0) {
                init(res.data.smartAppInfoVo);
            }
            else {
                modal.alert("提示", res.msg, function () {
                    load("./smartapp/"+previousPage);
                })
            }
        }).fail(function () {
            modal.alert("错误", "网络超时", function () {
                load("./smartapp/"+previousPage);
            })
        }).always(function () {
            modal.loading(false);
        });

        function init(data) {
            data.previousPage = '';
            v = new Vue({
                el: ".content-body",
                data: data,
                methods: {
                    verify: function (index) {
                        modal.loading();
                        api.verifySmartapp(v.pkSmartAppInfo).done(function (res) {
                            if (res.code == 0) {
                                modal.alert("提示", "操作成功", function () {
                                    load("./smartapp/"+previousPage);
                                })
                            }
                            else {
                                modal.alert("提示", res.msg)
                            }
                        }).fail(function () {
                            modal.alert("错误", "网络超时", function () {
                                load("./smartapp/"+previousPage);
                            })
                        }).always(function () {
                            modal.loading(false);
                        });
                    }
                }
            });

            $(".content-body").show();
            v.previousPage = previousPage;
            $("#return").attr("data-path","./smartapp/"+previousPage)
        }



        this.unload = function () {
            console.log("unload ./smartapp/add");
            vModal = null;
            v = null;
        }
    }

    pages.push(new page());
})
