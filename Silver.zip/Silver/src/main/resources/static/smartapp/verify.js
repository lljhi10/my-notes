$(function () {
    var page = function () {
        console.log("load company");
        var v = new Vue({
            el: ".content-body",
            data: {
                key: "",
                list: [],
                total: 1,
                index: 1,
                size: 10
            },
            computed: {
                count: function () {
                    return Math.ceil(this.total / this.size);
                },
                pagination: pagination
            },
            methods: {
                verify: function (id) {
                    cache.set("smartapp-id", id);
                    cache.set("previousPage","verify");
                    load("./smartapp/confirm");
                    console.log(id);                                  
                },
                find: find
            }
        });

        v.find(1);
        $(".content-body").show();

        function find(index, e) {
            e && e.preventDefault();

            modal.loading();
            v.list = [];
            api.listSmartapp(index, v.key,"APROVER").done(function (res) {
                console.log(res);
                if (res.code == 0) {
                    var list = res.data.list.rows;
                    for (var i = 0; i < list.length; i++) {
                        switch (list[i].status) {
                            case "NORMAL":
                                list[i].status = "正常";
                                break;
                            case "PAUSE":
                                list[i].status = "暂停";
                                break;
                            case "TERMINATION":
                                list[i].status = "终止";
                                break;
                        }
                        v.list.push(list[i]);
                    }

                    v.index = index;
                    v.total = res.data.list.total;
                }
                else {
                    modal.alert("提示",res.msg);
                }
            }).fail(function (res) {
                modal.alert("错误","网络超时");
            }).always(function () {
                modal.loading(false);
            });
        }




        $(".btn-search").click(function () {
            v.find(1);
        });

        this.unload = function () {
            v = null;
        }


    }

    pages.push(new page());
})


