$(function () {
    var page = function () {


        var v = new Vue({
            el: ".content-body",
            data: {
                "apiType": "POINT",
                "smartAppName": "",
                "aid": "",
                "apiDescription": "",
                "failueApi":"",
                "status":"NORMAL",
                "startDate": util.formatDate(new Date()),
                "endDate": util.formatDate(new Date().add("year", 1)),
                task: [{ id: 1, content: "" }],
                company: []
            },
            computed: {
                taskCount: {
                    get: function () {
                        return this.task.length;
                    },
                    set: function (value) {
                        console.log(value);
                        if (!util.isNumber(value)) {
                            value = 1;
                        }

                        if (value < this.task.length) {
                            while (value < this.task.length) {
                                if (this.task[this.task.length - 1].content) {
                                    if (!confirm("该任务有填写内容,确定要删除吗?")) {
                                        return;
                                    }
                                }
                                this.task.pop();
                            }
                        }
                        else {
                            while (value > this.task.length) {
                                this.task.push({
                                    id: this.task.length,
                                    content: ""
                                });
                            }
                        }
                    }
                }
            },
            methods: {
                Delete: function (index) {
                    var item = this.company.splice(index, 1)[0];
                    var data = vModal.list;
                    for (var i = 0; i < data.length; i++) {
                        if (data[i].pkCompanyInfo == item.id) {
                            data[i].checked = false;
                            break;
                        }
                    }
                }
            }
        });

        //获得Aid(生成器生成aid)
        getAid();
        function getAid () {
            api.getAID().done(function (res) {
                modal.loading(false);
                v.aid=res.data.AID;

            }).fail(function (res) {
                modal.loading(false);
                modal.alert("错误", "网络超时");
            });
        };
        $('.form-datetime').datetimepicker({
            showTodayButton: true,
            minDate: new Date(),
            viewMode: "days",
            keepInvalid: true,
            ignoreReadonly: true,
            format: "YYYY-MM-DD"
        }).on("dp.change", function (e) {
            v[this.name] = util.formatDate(e.date._d);
        });

        $(".content-body").show();

        //$("#modal-smartapp-company").modal("show");

        var vModal = new Vue({
            el: "#modal-smartapp-company",
            data: {
                key: "",
                list: [],
                total: 1,
                index: 1,
                size: 10,
                selectedValue:""
            },
            computed: {
                count: function () {
                    return Math.ceil(this.total / this.size);
                },
                pagination: pagination
            },
            methods: {
                find: findCompany,
                confirm: function () {
                    for (var i = 0; i < this.list.length; i++) {
                        if (this.list[i].pkCompanyInfo==this.selectedValue) {
                            v.company=[{
                                id:this.list[i].pkCompanyInfo,
                                name:this.list[i].companyName
                            }];
                            break;
                        }
                        /* if (this.list[i].checked) {
                            var exists = false;
                            for (var j = 0; j < v.company.length; j++) {
                                if (v.company[j].id == this.list[i].pkCompanyInfo) {
                                    exists = true;
                                    break;
                                }
                            }

                            if (!exists) {
                                v.company.push({
                                    id: this.list[i].pkCompanyInfo,
                                    name: this.list[i].companyName
                                });
                            }
                        } */
                    }

                    $("#modal-smartapp-company").modal("hide");
                }
            }
        });

        $(".btn-search").click(function () {
            findCompany(1);
        });

        $(".btn-add-company").click(function () {
            $("#modal-smartapp-company").modal("show");
        });


        function findCompany(index, e) {
            e && e.preventDefault();

            modal.loading();
            vModal.list = [];
            api.listCompanyByServices(index, vModal.key).done(function (res) {
                console.log(res);
                if (res.code == 0) {
                    var data = res.data.list.rows;
                    for (var i = 0; i < data.length; i++) {

                        data[i].checked = false;
                        for (var j = 0; j < v.company.length; j++) {
                            if (v.company[j].id == data[i].pkCompanyInfo) {
                                data[i].checked = true;
                                break;
                            }
                        }
                    }
                    vModal.list = data;
                    vModal.index = index;
                    vModal.total = res.data.list.total;
                    console.log("data", vModal.$data);
                }
                else {
                    console.info(res);
                }
            }).fail(function (res) {
                modal.alert("提示", "网络超时");
            }).always(function () {
                modal.loading(false);
            });

        }

        findCompany(1);

        $('.content-body').bootstrapValidator({
            message: 'This value is not valid',
            live: 'enabled',
            //submitButtons: '.btn-save',
            feedbackIcons: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            }
        });

        var isPublish = false;
        $(".btn-publish").click(function (e) {
            modal.alert("提示", "发布后将无法再次修改,确定要发布吗?", function () {
                isPublish = true;
                $(".btn-save").click();
            });
        });
        $(".btn-save").click(function () {
            if (v.task.length == 0) {
                modal.alert("提示", "请添先加任务");
                return;
            }
            if (v.company.length == 0) {
                modal.alert("提示", "请添先加合作方");
                return;
            }

            //获取表单对象
            var bootstrapValidator = $(".content-body").data('bootstrapValidator');
            //手动触发验证
            bootstrapValidator.validate();
            if (bootstrapValidator.isValid()) {
                var data = {
                    "apiType": v.apiType,
                    "smartAppName": v.smartAppName,
                    "aid": v.aid,
                    "cooperateCompany": [],
                    "startDate": util.formatDateTime(v.startDate),
                    "endDate": util.formatDateTime(v.endDate),
                    "taskNum": v.taskCount,
                    "taskContent": [],
                    "status":v.status,
                    "apiDescription": v.apiDescription,
                    "failueApi":v.failueApi,
                    "isPublish":isPublish
                }

                isPublish = false;

                for (var i = 0; i < v.company.length; i++) {
                    data.cooperateCompany.push(v.company[i].id);
                }

                for (var i = 0; i < v.task.length; i++) {
                    data.taskContent.push(v.task[i].content);
                }

                modal.loading(true);
                console.log("data", data, v.$data);
                //return;
                api.addSmartapp(data).done(function (res) {
                    modal.loading(false);
                    if (res.code == 0) {
                        modal.alert("提示", "保存成功", function () {
                            load("./smartapp/index");
                        });
                    }
                    else {
                        modal.alert("提示", res.msg);
                    }
                }).fail(function (res) {
                    modal.loading(false);
                    modal.alert("错误", "网络超时");
                });
                return false;
            }
        });

        this.unload = function () {
            console.log("unload smartapp/add");
            vModal = null;
            v = null;
        }
    }

    pages.push(new page());
})
