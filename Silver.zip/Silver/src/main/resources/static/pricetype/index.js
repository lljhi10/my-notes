$(function () {
    var page = function () {
        var data = {}
        console.log("load company");
        var v = new Vue({
            el: ".content-body",
            data: {
                key: "",
                list: [],
                total: 1,
                index: 1,
                size: 10,
                logList: [],
                items: [],
                payPkCompanyInfo: ""
            },
            computed: {
                count: function () {
                    return Math.ceil(this.total / this.size);
                },
                pagination: pagination
            },
            methods: {
                find: find,
                edit:function (pkPriceTypeInfo) {
                    cache.set("pkPriceTypeInfo", pkPriceTypeInfo);
                    load("./pricetype/edit");
                }
            }
        });
        $(".selectpicker").selectpicker({
            noneSelectedText: '请选择'//默认显示内容
        });


        v.find(1);
        $(".content-body").show();

        function find(index, e) {
            e && e.preventDefault();

            modal.loading();
            v.list = [];

            api.findPriceType(index, v).done(function (res) {
                console.log(res);
                if (res.code == 0) {
                    v.list = res.data.list.rows;
                    v.index = index;
                    v.total = res.data.list.total;
                }
                else {
                    console.info(res);
                }
            }).fail(function (res) {
                console.error(res);
            }).always(function () {
                modal.loading(false);
            });
        }


        $(".btn-search").click(function () {
            data.pageNo = v.index;
            data.pageSize = v.size;
            data.dealNo = v.key;
            v.find(1);
        });


        this.unload = function () {
            v = null;
        }
    }


    pages.push(new page());
})
