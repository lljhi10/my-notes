$(function () {
    var page = function () {
        var v;
        modal.loading();
        api.selectPeersetting(cache.get("peersetting-id", true)).done(function (res) {
            if (res.code == 0) {
                v = new Vue({
                    el: ".content-body",
                    data: res.data.PeerSettingInfo
                });

                init();

            }
            else {
                modal.alert("提示", res.msg);
            }
        }).fail(function () {
            modal.alert("错误", "网络超时", function () {
                load("./peersetting/index");
            });
        });

        function init() {
            var vModal = new Vue({
                el: "#modal-smartapp-company",
                data: {
                    key: "",
                    list: [],
                    total: 30,
                    index: 1,
                    size: 10,
                    selectedValue:v.pkCompanyInfo
                },
                computed: {
                    count: function () {
                        return Math.ceil(this.total / this.size);
                    },
                    pagination: pagination
                },
                methods: {
                    find: findCompany,
                    confirm: function () {
                        for (var i = 0; i < this.list.length; i++) {
                            if (this.list[i].pkCompanyInfo==this.selectedValue) {
                                v.pkCompanyInfo = this.list[i].pkCompanyInfo;
                                v.companyName = this.list[i].companyName;
                            }
                        }
    
                        $("#modal-smartapp-company").modal("hide");
                    }
                }
            });
    
            $(".btn-search").click(function () {
                findCompany(1);
            });
    
            $(".btn-add-company").click(function () {
                $("#modal-smartapp-company").modal("show");
            });
    
            function findCompany(index, e) {
                e && e.preventDefault();

                vModal.list = [];
                api.allCompany(index, vModal.key,null,"ALL").done(function (res) {
                    console.log(res);
                    if (res.code == 0) {
                        if (res.data.list == null) {
                            modal.alert("提示", "权限不足",function(){
                                load("./peersetting/index");
                            });
                            return;
                        }
                        var data = res.data.list.rows;
    
                        vModal.list = data;
                        vModal.index = index;
                        vModal.total = res.data.list.total;
                    }
                    else {
                        console.info(res);
                    }
                }).fail(function (res) {
                    modal.alert("提示", "网络超时");
                }).always(function () {
                    modal.loading(false);
                });
    
            }
    
            findCompany(1);

            $(".content-body").show().bootstrapValidator({
                message: 'This value is not valid',
                live: 'enabled',
                //submitButtons: 'button[type="button"]',
                feedbackIcons: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                }
            });

            $(".btn-save").click(function () {
                //获取表单对象
                var bootstrapValidator = $(".content-body").data('bootstrapValidator');
                //手动触发验证
                bootstrapValidator.validate();
                if (bootstrapValidator.isValid()) {
                    console.log(v.$data);
                    modal.loading(true);
                    api.updatePeersetting(v.$data).done(function (res) {
                        modal.loading(false);
                        if (res.code == 0) {
                            modal.alert("提示", "保存成功", function () {
                                load("./peersetting/index");
                            });
                        }
                        else {
                            modal.alert("提示", res.msg);
                        }
                    }).fail(function (res) {
                        modal.loading(false);
                        modal.alert("错误", "网络超时");
                    });
                    return false;
                }
            });
        }




        this.unload = function () {
            console.log("unload add");
        }
    }

    pages.push(new page());
})
