$(function () {
    var page = function () {

        console.log("load company");
        var v = new Vue({
            el: ".content-body",
            data: {
                key: "",
                list: [],
                total: 1,
                index: 1,
                size: 10
            },
            computed: {
                count: function () {
                    return Math.ceil(this.total / this.size);
                },
                pagination: pagination
            },
            methods: {
                edit: function (id) {
                    cache.set("payapi-id", id);
                    load("./payapi/edit");
                },
                view: function (id) {
                    cache.set("payApi-id", id);
                    load("./payapi/confirm");
                    console.log(id);
                },
                find: find,
                edit2:function (id) {
                    cache.set("payapi-id", id);
                    load("./payapi/edit2");
                }
            }
        });

        v.find(1);
        $(".content-body").show();

        function find(index, e) {
            e && e.preventDefault();

            modal.loading();
            v.list = [];
            api.listPayapi(index, v.key).done(function (res) {

                console.log(res);
                if (res.code == 0) {
                    var list = res.data.list.rows;                    
                    for (var i = 0; i < list.length; i++) {
                        v.list.push(list[i]);
                    }

                    v.index = index;
                    v.total = res.data.list.total;
                }
                else {
                    modal.alert("提示",res.msg);
                }
            }).fail(function (res) {
                modal.alert("错误","网络超时");
            }).always(function () {
                modal.loading(false);
            });
        }


        $(".btn-search").click(function () {
            v.find(1);
        });

        this.unload = function () {
            v = null;
        }
    }

    pages.push(new page());
})
