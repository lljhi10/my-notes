$(function () {
    var page = function () {
        var v;

        modal.loading();
        api.selectPayapi(cache.get("payApi-id")).done(function (res) {
            if (res.code == 0) {
                init(res.data.payApiInfo);
            }
            else {
                modal.alert("提示", res.msg, function () {
                    load("./payapi/index");
                })
            }
        }).fail(function () {
            modal.alert("错误", "网络超时", function () {
                load("./payapi/index");
            })
        }).always(function () {
            modal.loading(false);
        });

        function init(data) {
            v = new Vue({
                el: ".content-body",
                data: data
            });

            $(".content-body").show();
        }



        this.unload = function () {
            console.log("unload ./payapi/confirm");
            vModal = null;
            v = null;
        }
    }

    pages.push(new page());
})
