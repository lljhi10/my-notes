$(function () {
    var page = function () {

        var v = new Vue({
            el: ".content-body",
            data: {
                privkey:"",
                pubkey:"",
                address:"",
                res:''
            },
            methods:{
                create: function () {
                    api.getPrivkey().done(function (res) {
                        console.log(res.data);
                        if (res.code == "000000") {
                            v.privkey=res.data.privateKey;
                            v.pubkey=res.data.publicKey;
                            v.address=res.data.address;
                            v.res=res.data;
                        }
                        else {
                            console.info(res);
                        }
                    }).fail(function (res) {
                        modal.alert("提示", "获取密钥失败");
                    }).always(function () {
                        modal.loading(false);
                    });
                },
                download:download
            }
        });
        function download() {
            var fileName="account-"+new Date().getTime()+".json";
            var content = JSON.stringify(v.res);
            createAndDownloadFile(fileName, content);
        }
        
        function createAndDownloadFile(fileName, content) {
            var aTag = document.createElement('a');
            var blob = new Blob([content]);
            aTag.download = fileName;
            aTag.href = URL.createObjectURL(blob);
            aTag.click();
            URL.revokeObjectURL(blob);
        }

        $(".content-body").show();



        this.unload = function () {
            console.log("unload add");
        }
    }

    pages.push(new page());
})
