$(function () {
    var page = function () {
        var vData = {};
        vData.el = ".content-body";
        vData.data = {
            "companyName": "",
            "companyLicense": "",
            "companyNo": "",
            "chainAddr":"",
            "linkMan": "",
            "linkPhone": "",
            "email": "",
            "joinType": "PAUSE",
            "status": "NORMAL"
        }
        vData.methods = {};
        vData.methods.save = function () {
            var v=this;
            //获取表单对象
            var bootstrapValidator = $(".content-body").data('bootstrapValidator');
            //手动触发验证
            bootstrapValidator.validate();
            if (bootstrapValidator.isValid()) {
                console.log(v.$data);
                modal.loading(true);
                api.addCompany(v.$data).done(function (res) {
                    modal.loading(false);
                    if (res.code == 0) {
                        modal.alert("提示", "保存成功", function () {
                            load("./company/index");
                        });
                    }
                    else {
                        modal.alert("提示", res.msg);
                    }
                }).fail(function (res) {
                    modal.loading(false);
                    modal.alert("错误", "网络超时");
                });
                return false;
            }
        }

        var v = new Vue(vData);
        $(".content-body").show().bootstrapValidator({
            message: 'This value is not valid',
            live: 'enabled',
            //submitButtons: '.btn-save',
            feedbackIcons: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            }
        });

        this.unload = function () {
            console.log("unload add");
        }
    }

    pages.push(new page());
})




/* $(function () {
    var page = function () {


        var v = new Vue({
            el: ".content-body",
            data: {
                "companyName": "",
                "companyLicense": "",
                "companyNo": "",
                "linkMan": "",
                "linkPhone": "",
                "email": "",
                "joinType": "PAUSE",
                "status": "NORMAL"
            }
        });


        $(".content-body").show();



        //验证规则
        var validators = {
            validators: {
                notEmpty: {
                    message: '请输入'
                }
            }
        }
        $('.content-body').bootstrapValidator({
            message: 'This value is not valid',
            live: 'enabled',
            submitButtons: '.btn-save',
            feedbackIcons: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                companyName: validators,
                companyLicense: validators,
                companyNo: validators,
                linkMan: validators,
                linkPhone: validators
            }
        });

        $(".btn-save").click(function () {
            //获取表单对象
            var bootstrapValidator = $(".content-body").data('bootstrapValidator');
            //手动触发验证
            bootstrapValidator.validate();
            if (bootstrapValidator.isValid()) {
                console.log(v.$data);
                modal.loading(true);
                api.addCompany(v.$data).done(function (res) {
                    modal.loading(false);
                    if (res.code == 0) {
                        modal.alert("提示","保存成功",function(){
                            load("./company/index");
                        });
                    }
                    else {
                        modal.alert("提示",res.msg);
                    }
                }).fail(function (res) {
                    modal.loading(false);
                    modal.alert("错误","网络超时");
                });
                return false;
            }
        });


        this.unload = function () {
            console.log("unload add");
        }
    }

    pages.push(new page());
})
 */