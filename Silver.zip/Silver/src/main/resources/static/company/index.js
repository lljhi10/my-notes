

$(function () {
    var page = function () {
        console.log("load company.index");

        var vData = {};
        vData.el = ".content-body";
        vData.data = {
            key: "",
            list: [],
            total: 1,
            index: 1,
            size: 10
        }
        vData.computed = {
            count: function () {
                return Math.ceil(this.total / this.size);
            },
            pagination: pagination
        };

        vData.methods = {};
        vData.methods.edit = function (id) {
            cache.set("company-id", id);
            load("./company/edit");
        }
        vData.methods.find = function (index, e) {
            e && e.preventDefault();

            var v = this;
            v.index = index || 1;
            v.list = [];

            modal.loading();
            api.listCompany(v.index, v.key).done(function (res) {
                console.log(res);
                if (res.code == 0) {
                    if (res.data.list == null) {
                        modal.alert("提示", "权限不足");
                        return;
                    }
                    var list = res.data.list.rows;
                    for (var i = 0; i < list.length; i++) {
                        switch (list[i].status) {
                            case "NORMAL":
                                list[i].status = "正常";
                                break;
                            case "PAUSE":
                                list[i].status = "暂停";
                                break;
                            case "TERMINATION":
                                list[i].status = "终止";
                                break;
                        }
                        v.list.push(list[i]);
                    }

                    v.total = res.data.list.total;
                }
                else {
                    modal.alert("提示", res.msg);
                }
            }).fail(function (res) {
                modal.alert("错误", "网络超时");
            }).always(function () {
                modal.loading(false);
            });
        }

        var v = new Vue(vData);
        v.find(1);
        $(".content-body").show();

        this.unload = function () {
            v = null;
            console.log("unload company.index");
        }
    }

    pages.push(new page());
})



/* $(function () {
    var page = function () {
        console.log("load company");
        var vData = {};
        vData.el = ".content-body";
        vData.data = {
            key: "",
            list: [],
            total: 1,
            index: 1,
            size: 10
        }
        vdata.computed={};
        vdata.computed.count=function () {
            return Math.ceil(this.total / this.size);
        }
        vdata.computed.pagination=pagination;
        vdata.methods.methods={};
        vdata.methods.methods.edit=function (id) {
            cache.set("company-id", id);
            load("./company/edit");
        }
        vdata.methods.find=function(index, e) {
            e && e.preventDefault();

            modal.loading();
            v.list = [];
            api.listCompany(index, v.key).done(function (res) {
                console.log(res);
                if (res.code == 0) {
                    var list = res.data.list.rows;
                    for (var i = 0; i < list.length; i++) {
                        switch (list[i].status) {
                            case "NORMAL":
                                list[i].status = "正常";
                                break;
                            case "PAUSE":
                                list[i].status = "暂停";
                                break;
                            case "TERMINATION":
                                list[i].status = "终止";
                                break;
                        }
                        v.list.push(list[i]);
                    }

                    v.index = index;
                    v.total = res.data.list.total;
                }
                else {
                    modal.alert("提示", res.msg);
                }
            }).fail(function (res) {
                modal.alert("网络超时");
            }).always(function () {
                modal.loading(false);
            });
        }

        var v = new Vue({
            el: ".content-body",
            data: {
                key: "",
                list: [],
                total: 1,
                index: 1,
                size: 10
            },
            computed: {
                count: function () {
                    return Math.ceil(this.total / this.size);
                },
                pagination: pagination
            },
            methods: {
                edit: function (id) {
                    cache.set("company-id", id);
                    load("./company/edit");
                },
                find: find
            }
        });

        v.find(1);
        $(".content-body").show();

        function find(index, e) {
            e && e.preventDefault();

            modal.loading();
            v.list = [];
            api.listCompany(index, v.key).done(function (res) {
                console.log(res);
                if (res.code == 0) {
                    var list = res.data.list.rows;
                    for (var i = 0; i < list.length; i++) {
                        switch (list[i].status) {
                            case "NORMAL":
                                list[i].status = "正常";
                                break;
                            case "PAUSE":
                                list[i].status = "暂停";
                                break;
                            case "TERMINATION":
                                list[i].status = "终止";
                                break;
                        }
                        v.list.push(list[i]);
                    }

                    v.index = index;
                    v.total = res.data.list.total;
                }
                else {
                    modal.alert("提示", res.msg);
                }
            }).fail(function (res) {
                modal.alert("网络超时");
            }).always(function () {
                modal.loading(false);
            });
        }


        $(".btn-search").click(function () {
            v.find(1);
        });

        this.unload = function () {
            v = null;
        }
    }

    pages.push(new page());
})
 */