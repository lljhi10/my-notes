$(function () {
    var page = function () {



        var v = new Vue({
            el: ".content-body",
            data: {
                pkApiTypeInfo:'',
                "apiType": "POINT",
                "apiName": "",
                "targetType": "OPEN",
                "company": [],
                "price": "",
                "amount": "",
                "startDate": util.formatDate(new Date()),
                "endDate": util.formatDate(new Date().add("year", 1)),
                "apiDescription": "",
                "callBackDescription": "",
                // "status": "",
                "createDate": util.formatDateTime(new Date()),
                "createManager": "管理员1",
                "publish": "UNPUBLISH",
                "apiList": [],
                "rate": "0",
                list:'',
                path:"",
                method:"",
                contentType:"",
                paramExplain:"",
                requestMessageFormat:"",
                responseMessageFormat:"",
                errorCodeDefinition:"",
                reportDefinition:"",
                description:''
            },
            methods: {
                Delete: function (index) {
                    var item = this.company.splice(index, 1)[0];
                    var data = vModal.list;
                    for (var i = 0; i < data.length; i++) {
                        if (data[i].pkCompanyInfo == item.id) {
                            data[i].checked = false;
                            break;
                        }
                    }
                }
            }
        });

        $('.form-datetime').datetimepicker({
            showTodayButton: true,
            minDate: new Date(),
            viewMode: "days",
            keepInvalid: true,
            ignoreReadonly: true,
            format: "YYYY-MM-DD"
        }).on("dp.change", function (e) {
            v[this.name] = util.formatDate(e.date._d);
        });

        function getRate() {
            var list = [];
            list.push(userInfo.companyInfo.pkCompanyInfo);
            /* for (var i = 0; i < v.company.length; i++) {
                list.push(v.company[i].id);
            } */
            modal.loading();
            api.selectRate(v.apiType, "SERVICE", list).done(function (res) {
                if (res.code == 0) {
                    v.rate = res.data.costRate
                }
                else {
                    modal.alert("提示", "获取平台手续费失败");
                }
            }).fail(function () {
                modal.alert("提示", "获取平台手续费失败");
            }).always(function () {
                modal.loading(false);
            });
        }
        // getRate();
        function initApiType() {
            //获取服务接口类型列表
            api.findApiType(1, {key:''}).done(function (res) {
                console.log(res);
                if (res.code == 0) {
                    v.list=res.data.list.rows;
                }
                else {
                    console.info(res);
                }
            }).fail(function (res) {
                console.error(res);
            }).always(function () {
                modal.loading(false);
            });
        }
        initApiType();

        $(".content-body").show();
        var vModal = new Vue({
            el: "#modal-smartapp-company",
            data: {
                key: "",
                list: [],
                total: 1,
                index: 1,
                size: 10
            },
            computed: {
                count: function () {
                    return Math.ceil(this.total / this.size);
                },
                pagination: pagination
            },
            methods: {
                find: findCompany,
                confirm: function () {
                    for (var i = 0; i < this.list.length; i++) {
                        if (this.list[i].checked) {
                            var exists = false;
                            for (var j = 0; j < v.company.length; j++) {
                                if (v.company[j].id == this.list[i].pkCompanyInfo) {
                                    exists = true;
                                    break;
                                }
                            }

                            if (!exists) {
                                v.company.push({
                                    id: this.list[i].pkCompanyInfo,
                                    name: this.list[i].companyName
                                });
                            }

                        }
                    }

                    $("#modal-smartapp-company").modal("hide");
                }
            }
        });

        $(".btn-search").click(function () {
            findCompany(1);
        });

        $(".btn-add-company").click(function () {
            $("#modal-smartapp-company").modal("show");
        });

        findCompany(1);
        function findCompany(index, e) {
            e && e.preventDefault();

            modal.loading();
            vModal.list = [];
            api.allCompany(index, vModal.key,null,null).done(function (res) {
                console.log(res);
                if (res.code == 0 && res.data.list) {
                    var data = res.data.list.rows;
                    for (var i = 0; i < data.length; i++) {

                        data[i].checked = false;
                        for (var j = 0; j < v.company.length; j++) {
                            if (v.company[j].id == data[i].pkCompanyInfo) {
                                data[i].checked = true;
                                break;
                            }
                        }
                    }
                    vModal.list = data;
                    vModal.index = index;
                    vModal.total = res.data.list.total;
                    console.log("data", vModal.$data);
                }
                else {
                    console.info(res);
                }
            }).fail(function (res) {
                modal.alert("提示", "网络超时");
            }).always(function () {
                modal.loading(false);
            });

        }



        $('.content-body').bootstrapValidator({
            message: 'This value is not valid',
            live: 'enabled',
            //submitButtons: '.btn-save',
            feedbackIcons: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            }
        });
        var isPublish = false;
        $(".btn-publish").click(function (e) {
            modal.alert("提示", "发布后将无法再次修改,确定要发布吗?", function () {
                isPublish = true;
                $(".btn-save").click();
            });
        });
        $(".btn-save").click(function (e) {
            e.preventDefault();

            if (v.targetType == "TARGET" && v.company.length == 0) {
                modal.alert("提示", "请选择指定商户");
                return;
            }
            if (isPublish) {
                v.publish = "EFFICIENT";
                isPublish = false;
            }
            else {
                v.publish = "UNPUBLISH";
            }

            //获取表单对象
            var bootstrapValidator = $(".content-body").data('bootstrapValidator');
            //手动触发验证
            bootstrapValidator.validate();
            if (bootstrapValidator.isValid()) {
                console.log(v.$data);
                v.$data.targetCompany = [];
                v.startDate = util.formatDateTime(v.startDate);
                v.endDate = util.formatDateTime(v.endDate);
                for (var i = 0; i < v.company.length; i++) {
                    v.$data.targetCompany.push(v.company[i].id);
                }

                modal.loading(true);
                api.addServicesapi(v.$data).done(function (res) {
                    modal.loading(false);
                    if (res.code == 0) {
                        modal.alert("提示", "保存成功", function () {
                            load("./servicesapi/index");
                        });
                    }
                    else {
                        modal.alert("提示", res.msg);
                    }
                }).fail(function (res) {
                    modal.loading(false);
                    modal.alert("错误", "网络超时");
                });
                return false;
            }
        });


        this.unload = function () {
            console.log("unload add");
        }
    }

    pages.push(new page());
})
