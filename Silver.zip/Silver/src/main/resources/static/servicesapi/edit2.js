$(function () {
    var page = function () {
        var v;

        modal.loading();

        api.selectServicesapi(cache.get("servicesapi-id")).done(function (res) {
            if (res.code == 0) {
                var data = res.data.serviceApiInfo;
                data.company = [];
                data.targetType = "OPEN";
                data.startDate=util.formatDate(data.startDate);
                data.endDate=util.formatDate(data.endDate);
                data.list = [];
                if (data.targetCompany && data.targetCompany.length > 0) {
                    var names = (data.targetCompanyName || "").split(",");
                    data.targetType = "TARGET";
                    for (var i = 0; i < data.targetCompany.length; i++) {
                        data.company.push({ id: data.targetCompany[i], name: names[i] });
                    }
                }
                console.log("1");
                init(data);
            }
            else {
                modal.alert("提示", res.msg)
            }
        }).fail(function () {
            modal.alert("提示", "网络超时")
        });

        function init(data) {
            data.apiList = [];
            data.rate = "";
            v = new Vue({
                el: ".content-body",
                data: data,
                methods: {
                    Delete: function (index) {
                        var item = this.company.splice(index, 1)[0];
                        var data = vModal.list;
                        for (var i = 0; i < data.length; i++) {
                            if (data[i].pkCompanyInfo == item.id) {
                                data[i].checked = false;
                                break;
                            }
                        }
                    }
                }
            });
            console.log("2");
            function initApiTypeInfo(){
                console.log("3");
                //获取业务类型列表
                api.findApiType(1, {key:''}).done(function (res) {
                    console.log(res);
                    if (res.code == 0) {
                        v.list=res.data.list.rows;
                    }
                    else {
                        console.info(res);
                    }
                }).fail(function (res) {
                    console.error(res);
                }).always(function () {
                    modal.loading(false);
                });
            }

            initApiTypeInfo();
            $('.form-datetime').datetimepicker({
                showTodayButton: true,
                minDate: new Date(),
                viewMode: "days",
                keepInvalid: true,
                ignoreReadonly: true,
                format: "YYYY-MM-DD"
            }).on("dp.change", function (e) {
                v[this.name] = util.formatDate(e.date._d);
            });

            $(".content-body").show();

            var vModal = new Vue({
                el: "#modal-smartapp-company",
                data: {
                    key: "",
                    list: [],
                    total: 1,
                    index: 1,
                    size: 10
                },
                computed: {
                    count: function () {
                        return Math.ceil(this.total / this.size);
                    },
                    pagination: pagination
                },
                methods: {
                    find: findCompany,
                    confirm: function () {
                        for (var i = 0; i < this.list.length; i++) {
                            if (this.list[i].checked) {
                                var exists = false;
                                for (var j = 0; j < v.company.length; j++) {
                                    if (v.company[j].id == this.list[i].pkCompanyInfo) {
                                        exists = true;
                                        break;
                                    }
                                }

                                if (!exists) {
                                    v.company.push({
                                        id: this.list[i].pkCompanyInfo,
                                        name: this.list[i].companyName
                                    });
                                }

                            }
                        }

                        $("#modal-smartapp-company").modal("hide");
                    }
                }
            });

            $(".btn-search").click(function () {
                findCompany(1);
            });

            $(".btn-add-company").click(function () {
                $("#modal-smartapp-company").modal("show");
            });

            function findCompany(index, e) {
                e && e.preventDefault();

                modal.loading();
                vModal.list = [];
                api.allCompany(index, vModal.key,null,null).done(function (res) {
                    console.log(res);
                    if (res.code == 0 && res.data.list) {
                        var data = res.data.list.rows;
                        for (var i = 0; i < data.length; i++) {

                            data[i].checked = false;
                            for (var j = 0; j < v.company.length; j++) {
                                if (v.company[j].id == data[i].pkCompanyInfo) {
                                    data[i].checked = true;
                                    break;
                                }
                            }
                        }
                        vModal.list = data;
                        vModal.index = index;
                        vModal.total = res.data.list.total;
                        console.log("data", vModal.$data);
                    }
                    else {
                        console.info(res);
                    }
                }).fail(function (res) {
                    modal.alert("提示", "网络超时");
                }).always(function () {
                    modal.loading(false);
                });

            }

            findCompany(1);

            $('.content-body').bootstrapValidator({
                message: 'This value is not valid',
                live: 'enabled',
                //submitButtons: '.btn-save',
                feedbackIcons: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                }
            });
            var isPublish = false;
            $(".btn-publish").click(function (e) {
                modal.alert("提示", "发布后将无法再次修改,确定要发布吗?", function () {
                    isPublish = true;
                    $(".btn-save").click();
                });
            });

            $(".btn-save").click(function (e) {
                e.preventDefault();
                if (v.status!= "NORMAL") {
                    modal.alert("提示", "暂停或终止将导致智能应用失效,确定要保存吗?", function () {
                        saveData();
                    });
                }else {
                    saveData();
                }
            });
            function saveData () {

                //获取表单对象
                var bootstrapValidator = $(".content-body").data('bootstrapValidator');
                //手动触发验证
                bootstrapValidator.validate();
                if (bootstrapValidator.isValid()) {
                    console.log(v.$data);
                    v.$data.targetCompany = [];
                    v.$data.updateDate = new Date().getTime();
                    //v.$data.publishDate = "2018-05-05 00:00:00";
                    v.startDate = util.formatDateTime(v.startDate);
                    v.endDate = util.formatDateTime(v.endDate);

                    for (var i = 0; i < v.company.length; i++) {
                        v.$data.targetCompany.push(v.company[i].id);
                    }

                    modal.loading(true);
                    api.updateServicesapi2(v.$data).done(function (res) {
                        modal.loading(false);
                        if (res.code == 0) {
                            modal.alert("提示", "保存成功", function () {
                                load("./servicesapi/index");
                            });
                        }
                        else {
                            modal.alert("提示", res.msg);
                        }
                    }).fail(function (res) {
                        modal.loading(false);
                        modal.alert("错误", "网络超时");
                    });
                    return false;
                }
            };
        }




        this.unload = function () {
            console.log("unload add");
        }
    }

    pages.push(new page());
})
