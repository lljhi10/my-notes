$(function () {
    var page = function () {
        var v;

        modal.loading();

        api.selectServicesapi(cache.get("servicesapi-id")).done(function (res) {
            if (res.code == 0) {
                var data = res.data.serviceApiInfo;
                data.company = [];
                data.targetType="OPEN";
                if(data.targetCompany&&data.targetCompany.length>0)
                {
                    var names=(data.targetCompanyName||"").split(",");
                    data.targetType="TARGET";
                    for(var i=0;i<data.targetCompany.length;i++)
                    {
                        data.company.push({id:data.targetCompany[i],name:names[i]});
                    }

                    console.log("company",data.company);
                }

                init(data);
            }
            else {
                modal.alert("提示", res.msg)
            }


        }).fail(function () {
            modal.alert("提示", "网络超时")
        }).always(function () {
            modal.loading(false);
        });

        function init(data) {
            v = new Vue({
                el: ".content-body",
                data: data,
                methods: {
                    Delete: function (index) {
                        var item = this.company.splice(index, 1)[0];
                        var data = vModal.list;
                        for (var i = 0; i < data.length; i++) {
                            if (data[i].pkCompanyInfo == item.id) {
                                data[i].checked = false;
                                break;
                            }
                        }
                    }
                }
            });
            $(".content-body").show();
        }



        this.unload = function () {
            console.log("unload add");
        }
    }

    pages.push(new page());
})
