$(function () {
    var page = function () {
        var v;
        api.findByRoleId(cache.get("role-id", true)).done(function (res) {
            if (res.code == 0) {
                v = new Vue({
                    el: ".row",
                    data: {
                        menuList:[
                            {
                                "menuName" : "角色管理",
                                "rightList" : [
                                    {
                                        "rightName" : "VIEW",
                                        "name":"查看",
                                        "isChecked" : "UNCHECKED"
                                    },
                                    {
                                        "rightName" : "EDIT",
                                        "name":"修改",
                                        "isChecked" : "UNCHECKED"
                                    }
                                ]
                            },
                            {
                                "menuName" : "账号管理",
                                "rightList" : [
                                    {
                                        "rightName" : "VIEW",
                                        "name":"查看",
                                        "isChecked" : "UNCHECKED"
                                    },
                                    {
                                        "rightName" : "EDIT",
                                        "name":"修改",
                                        "isChecked" : "UNCHECKED"
                                    }
                                ]
                            },
                            {
                                "menuName" : "商户信息管理",
                                "rightList" : [
                                    {
                                        "rightName" : "VIEW",
                                        "name":"查看",
                                        "isChecked" : "UNCHECKED"
                                    },
                                    {
                                        "rightName" : "EDIT",
                                        "name":"修改",
                                        "isChecked" : "UNCHECKED"
                                    }
                                ]
                            },
                            {
                                "menuName" : "业务账户管理",
                                "rightList" : [
                                    {
                                        "rightName" : "VIEW",
                                        "name":"查看",
                                        "isChecked" : "UNCHECKED"
                                    },
                                    {
                                        "rightName" : "EDIT",
                                        "name":"修改",
                                        "isChecked" : "UNCHECKED"
                                    }
                                ]
                            },
                            {
                                "menuName" : "节点信息管理",
                                "rightList" : [
                                    {
                                        "rightName" : "VIEW",
                                        "name":"查看",
                                        "isChecked" : "UNCHECKED"
                                    },
                                    {
                                        "rightName" : "EDIT",
                                        "name":"修改",
                                        "isChecked" : "UNCHECKED"
                                    }
                                ]
                            },
                            {
                                "menuName" : "支付服务接口",
                                "rightList" : [
                                    {
                                        "rightName" : "VIEW",
                                        "name":"查看",
                                        "isChecked" : "UNCHECKED"
                                    },
                                    {
                                        "rightName" : "EDIT",
                                        "name":"修改",
                                        "isChecked" : "UNCHECKED"
                                    },
                                    {
                                        "rightName" : "PUBLISH",
                                        "name":"发布",
                                        "isChecked" : "UNCHECKED"
                                    }
                                ]
                            },
                            {
                                "menuName" : "发布服务接口",
                                "rightList" : [
                                    {
                                        "rightName" : "VIEW",
                                        "name":"查看",
                                        "isChecked" : "UNCHECKED"
                                    },
                                    {
                                        "rightName" : "EDIT",
                                        "name":"修改",
                                        "isChecked" : "UNCHECKED"
                                    },
                                    {
                                        "rightName" : "PUBLISH",
                                        "name":"发布",
                                        "isChecked" : "UNCHECKED"
                                    }
                                ]
                            },
                            {
                                "menuName" : "查看服务接口",
                                "rightList" : [
                                    {
                                        "rightName" : "VIEW",
                                        "name":"查看",
                                        "isChecked" : "UNCHECKED"
                                    }
                                ]
                            },
                            {
                                "menuName" : "发布智能应用",
                                "rightList" : [
                                    {
                                        "rightName" : "VIEW",
                                        "name":"查看",
                                        "isChecked" : "UNCHECKED"
                                    },
                                    {
                                        "rightName" : "EDIT",
                                        "name":"修改",
                                        "isChecked" : "UNCHECKED"
                                    },
                                    {
                                        "rightName" : "PUBLISH",
                                        "name":"发布",
                                        "isChecked" : "UNCHECKED"
                                    }
                                ]
                            },
                            {
                                "menuName" : "审核智能应用",
                                "rightList" : [
                                    {
                                        "rightName" : "VIEW",
                                        "name":"查看",
                                        "isChecked" : "UNCHECKED"
                                    },
                                    {
                                        "rightName" : "APPROVER",
                                        "name":"审核",
                                        "isChecked" : "UNCHECKED"
                                    }
                                ]
                            },
                            {
                                "menuName" : "交易统计",
                                "rightList" : [
                                    {
                                        "rightName" : "VIEW",
                                        "name":"查看",
                                        "isChecked" : "UNCHECKED"
                                    }
                                ]
                            }
                        ],
                        role:res.data.baseRole,
                    },
                    methods: {
                        CHECK:function (item,e) {
                            item.isChecked=e.target.checked?"CHECKED":"UNCHECKED"
                        },
                        chcekHook:function(){
                            console.log("钩中已有的权限-start")
                            var oldMenuList = v.menuList;
                            var newMenuList = v.role.menuList;
                            for(i in oldMenuList){
                                for(j in newMenuList){
                                    if(oldMenuList[i].menuName === newMenuList[j].menuName){
                                        for (i1 in oldMenuList[i].rightList) {
                                            for (j1 in newMenuList[j].rightList) {
                                                if (oldMenuList[i].rightList[i1].rightName === newMenuList[j].rightList[j1].rightName) {
                                                    oldMenuList[i].rightList[i1].isChecked = newMenuList[j].rightList[j1].isChecked;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            console.log("钩中已有的权限-end")
                        }
                    }
                });
                init();
                v.chcekHook();
            }
            else {
                modal.alert("提示",res.msg);
            }
        }).fail(function () {
            modal.alert("错误", "网络超时", function () {
                load("./role/index");
            });
        });

        function init() {
            $(".content-body").show();

            //验证规则
            var validators = {
                validators: {
                    notEmpty: {
                        message: '请输入'
                    }
                }
            }
            $('.content-body').bootstrapValidator({
                message: 'This value is not valid',
                live: 'enabled',
                //submitButtons: 'button[type="button"]',
                feedbackIcons: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                },
                fields: {
                    roleName: validators,
                    description: validators
                }
            });

            $(".btn-save").click(function () {
                //获取表单对象
                var bootstrapValidator = $(".content-body").data('bootstrapValidator');
                //手动触发验证
                bootstrapValidator.validate();
                if (bootstrapValidator.isValid()) {
                    console.log(v.$data);
                    modal.loading(true);
                    v.$data.role.menuList = v.menuList;
                    api.updateRole(v.$data.role).done(function (res) {
                        modal.loading(false);
                        if (res.code == 0) {
                            modal.alert("提示","修改成功",function(){
                                load("./role/index");
                            });
                        }
                        else {
                            modal.alert("提示",res.msg);
                        }
                    }).fail(function (res) {
                        modal.loading(false);
                        modal.alert("错误","网络超时");
                    });
                    return false;
                }
            });
        }




        this.unload = function () {
            console.log("unload role");
        }

    }

    pages.push(new page());
})
