$(function () {
    var page = function () {

        console.log("load role");
        var v = new Vue({
            el: ".content-body",
            data: {
                key: "",
                list: [],
                total: 1,
                index: 1,
                size: 10
            },
            computed: {
                count: function () {
                    return Math.ceil(this.total / this.size);
                },
                pagination: pagination
            },
            methods: {
                edit: function (id) {
                    cache.set("role-id", id);
                    load("./role/edit");
                },
                del:function(id){

                    modal.alert("删除角色","您是确定删除该角色吗？一旦删除不可找回!",function() {
                        api.deleteRole(id).done(function (res) {
                            console.log("12345678re24354")
                            modal.alert("提示:",res.msg, function () {
                                load("./role/index");
                                $(".modal-backdrop.fade.in").hide();
                            });
                            if (res.code == 0) {
                                console.info(v.list);
                            }
                            else {
                                console.info(res);
                            }
                        }).fail(function (e) {
                            console.error(res);
                        }).always(function(){
                            modal.loading(false);
                        });
                        $(".modal-backdrop.fade.in").hide();
                    });


                },
                find: find

            }
        });

        $(".content-body").show();
        modal.loading();

        v.find(1)
        function find(index, e) {
            e && e.preventDefault();

            modal.loading();
            v.list = [];
            api.fundByRolePage(index,v.key).done(function (res) {
                if (res.code == 0) {
                    v.list = res.data.list.rows;
                    v.index = index;
                    v.total = res.data.list.total;
                }
                else {
                    console.info(res);
                }
            }).fail(function (res) {
                console.error(res);
            }).always(function () {
                modal.loading(false);
            });
        }

        $(".btn-search").click(function () {
            v.find(1);
        });


        this.unload = function () {
            v = null;
        }

    }

    pages.push(new page());
})
