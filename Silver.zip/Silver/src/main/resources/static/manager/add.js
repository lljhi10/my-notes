$(function () {
    var page = function () {


        var v = new Vue({
            el: ".content-body",
            data: {
                "roles":[],
                "managerNumber": "",
                "managerName": "",
                "pkRoles": [],
                "phone": "",
                "email": ""
            },
            updated : function(){
                this.$nextTick(function(){
                    $('#roleList').selectpicker(
                        'refresh'
                    );
                })
            }
        });

        //查询角色
        var data = {
            pageNo : 0,
        }
        api.findRoleAll().done(function(res){
            if(res.code == 0){
                v.roles = res.data.list.rows;
                console.log(v.roles)
            }
        });

        $(".content-body").show();

        var validators = {
            validators: {
                notEmpty: {
                    message: '请输入'
                },
                stringLength: {
                    min: 6,
                    max: 18,
                    message: '必须在6到18位之间'
                }
            }

        }
        var notEmpty = {
            validators: {
                notEmpty: {
                    message: '请输入'
                }
            }

        }

        var ifExistsName = {
            validators: {
                threshold :  20, //有6字符以上才发送ajax请求，（input中输入一个字符，插件会向服务器发送一次，设置限制，6字符以上才开始）
                remote: {//ajax验证。server result:{"valid",true or false} 向服务发送当前input name值，获得一个json数据。例表示正确：{"valid",true}
                    url: 'orguser/v1/findByNumber?test=test',//验证地址
                    message: '账户已存在',//提示消息
                    delay :  2000,//每输入一个字符，就发ajax请求，服务器压力还是太大，设置2秒发送一次ajax（默认输入一个字符，提交一次，服务器压力太大）
                    type: 'POST'//请求方式

                },
            }
        }

        $('.content-body').bootstrapValidator({
            message: 'This value is not valid',
            live: 'enabled',
            //submitButtons: 'button[type="button"]',
            feedbackIcons: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                managerNumber: validators,
                managerNumber: ifExistsName,
                managerName: notEmpty,
                phone:validators,
                email:validators
            }
        });

        //初始化bootstrap select 控件
        $(".btn-save").click(function () {
            //获取表单对象
            var bootstrapValidator = $(".content-body").data('bootstrapValidator');
            //手动触发验证
            bootstrapValidator.validate();
            if (bootstrapValidator.isValid()) {
                console.log(v.$data);
                modal.loading(true);
                if(v.pkRoles.length == 0){
                    modal.alert("警告","用户至少拥有一个角色!");
                    $("button").attr("disabled",false);
                    modal.loading(false);
                    return false;
                }
                api.addManager(v.$data).done(function (res) {
                    modal.loading(false);
                    if (res.code == 0) {
                        modal.alert("提示","保存成功",function(){
                            load("./manager/index");
                        });
                    }
                    else {
                        modal.alert("提示",res.msg);
                    }
                }).fail(function (res) {
                    modal.loading(false);
                    modal.alert("错误","网络超时");
                });
                return false;
            }

        });

        this.unload = function () {
            console.log("unload add");
        }
    }

    pages.push(new page());
})
