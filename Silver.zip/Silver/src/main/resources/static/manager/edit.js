$(function () {
    var page = function () {
        var v;
        api.findByManagerId(cache.get("manager-id", true)).done(function (res) {
            if (res.code == 0) {
                v = new Vue({
                    el: ".content-body",
                    data: {
                       "manager": res.data.managerInfo,
                        "roles":[]
                    },
                    updated : function(){
                        this.$nextTick(function(){
                            $('#roleList').selectpicker(
                                'refresh'
                            );
                        })
                    }
                });

                init();

            }
            else {
                modal.alert("提示",res.msg);
            }
        }).fail(function () {
            modal.alert("错误", "网络超时", function () {
                load("./manager/index");
            });
        });
        api.findRoleAll().done(function(res){
            if(res.code == 0){
                v.roles = res.data.list.rows;
                console.log(v.roles)
            }
        });
        function init() {
            $(".content-body").show();

            var validators = {
                validators: {
                    notEmpty: {
                        message: '请输入'
                    },
                    stringLength: {
                        min: 6,
                        max: 18,
                        message: '必须在6到18位之间'
                    }
                }
            
            }

            var notEmpty = {

                validators: {
                    notEmpty: {
                        message: '请输入'
                    }
                }

            }


            
            $('.content-body').bootstrapValidator({
                message: 'This value is not valid',
                live: 'enabled',
                //submitButtons: 'button[type="button"]',
                feedbackIcons: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                },
                fields: {
                	managerName: notEmpty,
                	phone:validators,
                    email:validators
                }
            });

            $(".btn-save").click(function () {
                //获取表单对象
                var bootstrapValidator = $(".content-body").data('bootstrapValidator');
                //手动触发验证
                bootstrapValidator.validate();
                if (bootstrapValidator.isValid()) {
                    console.log(v.$data);
                    modal.loading(true);
                    if(v.manager.pkRoles.length == 0){
                        modal.alert("警告","用户至少拥有一个角色!");
                        $("button").attr("disabled",false);
                        modal.loading(false);
                        return false;
                    }
                    api.updateManager(v.$data.manager).done(function (res) {
                        modal.loading(false);
                        if (res.code == 0) {
                            modal.alert("提示", "修改成功", function () {
                                load("./manager/index");
                            });
                        }
                        else {
                            modal.alert("提示", res.msg);
                        }
                    }).fail(function (res) {
                        modal.loading(false);
                        modal.alert("错误", "网络超时");
                    });
                    return false;
                }
            });
        }




        this.unload = function () {
            console.log("unload add");
        }
    }

    pages.push(new page());
})
