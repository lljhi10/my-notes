package com.zhongan.horizon.coupon.dao;

import com.zhongan.horizon.coupon.model.authority.BasePage;
import com.zhongan.horizon.coupon.model.authority.BasePageExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BasePageDao {
    long countByExample(BasePageExample example);

    int deleteByExample(BasePageExample example);

    int deleteByPrimaryKey(String pkPage);

    int insert(BasePage record);

    int insertSelective(BasePage record);

    List<BasePage> selectByExample(BasePageExample example);

    BasePage selectByPrimaryKey(String pkPage);

    int updateByExampleSelective(@Param("record") BasePage record, @Param("example") BasePageExample example);

    int updateByExample(@Param("record") BasePage record, @Param("example") BasePageExample example);

    int updateByPrimaryKeySelective(BasePage record);

    int updateByPrimaryKey(BasePage record);
}