package com.zhongan.horizon.coupon.model.authority;

import java.io.Serializable;
import java.util.Date;

public class BaseOper implements Serializable {
    private String pkOper;

    private String pkPage;

    private String operName;

    private String operCode;

    private String url;

    private String path;

    private String description;

    private Integer status;

    private Date createDate;

    private String createManager;

    private Date updateDate;

    private String updateManager;

    private static final long serialVersionUID = 1L;

    public BaseOper(String pkOper, String pkPage, String operName, String operCode, String url, String path, String description, Integer status, Date createDate, String createManager, Date updateDate, String updateManager) {
        this.pkOper = pkOper;
        this.pkPage = pkPage;
        this.operName = operName;
        this.operCode = operCode;
        this.url = url;
        this.path = path;
        this.description = description;
        this.status = status;
        this.createDate = createDate;
        this.createManager = createManager;
        this.updateDate = updateDate;
        this.updateManager = updateManager;
    }

    public BaseOper() {
        super();
    }

    public String getPkOper() {
        return pkOper;
    }

    public void setPkOper(String pkOper) {
        this.pkOper = pkOper == null ? null : pkOper.trim();
    }

    public String getPkPage() {
        return pkPage;
    }

    public void setPkPage(String pkPage) {
        this.pkPage = pkPage == null ? null : pkPage.trim();
    }

    public String getOperName() {
        return operName;
    }

    public void setOperName(String operName) {
        this.operName = operName == null ? null : operName.trim();
    }

    public String getOperCode() {
        return operCode;
    }

    public void setOperCode(String operCode) {
        this.operCode = operCode == null ? null : operCode.trim();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path == null ? null : path.trim();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateManager() {
        return createManager;
    }

    public void setCreateManager(String createManager) {
        this.createManager = createManager == null ? null : createManager.trim();
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateManager() {
        return updateManager;
    }

    public void setUpdateManager(String updateManager) {
        this.updateManager = updateManager == null ? null : updateManager.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", pkOper=").append(pkOper);
        sb.append(", pkPage=").append(pkPage);
        sb.append(", operName=").append(operName);
        sb.append(", operCode=").append(operCode);
        sb.append(", url=").append(url);
        sb.append(", path=").append(path);
        sb.append(", description=").append(description);
        sb.append(", status=").append(status);
        sb.append(", createDate=").append(createDate);
        sb.append(", createManager=").append(createManager);
        sb.append(", updateDate=").append(updateDate);
        sb.append(", updateManager=").append(updateManager);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}