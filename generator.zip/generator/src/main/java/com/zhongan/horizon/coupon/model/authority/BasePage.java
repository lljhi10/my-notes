package com.zhongan.horizon.coupon.model.authority;

import java.io.Serializable;
import java.util.Date;

public class BasePage implements Serializable {
    private String pkPage;

    private String parentId;

    private String pageName;

    private String pageCode;

    private String url;

    private String path;

    private String description;

    private Integer status;

    private Date createDate;

    private String createManager;

    private Date updateDate;

    private String updateManager;

    private static final long serialVersionUID = 1L;

    public BasePage(String pkPage, String parentId, String pageName, String pageCode, String url, String path, String description, Integer status, Date createDate, String createManager, Date updateDate, String updateManager) {
        this.pkPage = pkPage;
        this.parentId = parentId;
        this.pageName = pageName;
        this.pageCode = pageCode;
        this.url = url;
        this.path = path;
        this.description = description;
        this.status = status;
        this.createDate = createDate;
        this.createManager = createManager;
        this.updateDate = updateDate;
        this.updateManager = updateManager;
    }

    public BasePage() {
        super();
    }

    public String getPkPage() {
        return pkPage;
    }

    public void setPkPage(String pkPage) {
        this.pkPage = pkPage == null ? null : pkPage.trim();
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId == null ? null : parentId.trim();
    }

    public String getPageName() {
        return pageName;
    }

    public void setPageName(String pageName) {
        this.pageName = pageName == null ? null : pageName.trim();
    }

    public String getPageCode() {
        return pageCode;
    }

    public void setPageCode(String pageCode) {
        this.pageCode = pageCode == null ? null : pageCode.trim();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path == null ? null : path.trim();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateManager() {
        return createManager;
    }

    public void setCreateManager(String createManager) {
        this.createManager = createManager == null ? null : createManager.trim();
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateManager() {
        return updateManager;
    }

    public void setUpdateManager(String updateManager) {
        this.updateManager = updateManager == null ? null : updateManager.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", pkPage=").append(pkPage);
        sb.append(", parentId=").append(parentId);
        sb.append(", pageName=").append(pageName);
        sb.append(", pageCode=").append(pageCode);
        sb.append(", url=").append(url);
        sb.append(", path=").append(path);
        sb.append(", description=").append(description);
        sb.append(", status=").append(status);
        sb.append(", createDate=").append(createDate);
        sb.append(", createManager=").append(createManager);
        sb.append(", updateDate=").append(updateDate);
        sb.append(", updateManager=").append(updateManager);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}