package com.zhongan.horizon.coupon.dao;

import com.zhongan.horizon.coupon.model.authority.BaseOper;
import com.zhongan.horizon.coupon.model.authority.BaseOperExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BaseOperDao {
    long countByExample(BaseOperExample example);

    int deleteByExample(BaseOperExample example);

    int deleteByPrimaryKey(String pkOper);

    int insert(BaseOper record);

    int insertSelective(BaseOper record);

    List<BaseOper> selectByExample(BaseOperExample example);

    BaseOper selectByPrimaryKey(String pkOper);

    int updateByExampleSelective(@Param("record") BaseOper record, @Param("example") BaseOperExample example);

    int updateByExample(@Param("record") BaseOper record, @Param("example") BaseOperExample example);

    int updateByPrimaryKeySelective(BaseOper record);

    int updateByPrimaryKey(BaseOper record);
}