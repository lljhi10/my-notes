package com.zhongan.horizon.coupon.dao;

import com.zhongan.horizon.coupon.model.authority.BaseMenu;
import com.zhongan.horizon.coupon.model.authority.BaseMenuExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BaseMenuDao {
    long countByExample(BaseMenuExample example);

    int deleteByExample(BaseMenuExample example);

    int deleteByPrimaryKey(String pkMenu);

    int insert(BaseMenu record);

    int insertSelective(BaseMenu record);

    List<BaseMenu> selectByExample(BaseMenuExample example);

    BaseMenu selectByPrimaryKey(String pkMenu);

    int updateByExampleSelective(@Param("record") BaseMenu record, @Param("example") BaseMenuExample example);

    int updateByExample(@Param("record") BaseMenu record, @Param("example") BaseMenuExample example);

    int updateByPrimaryKeySelective(BaseMenu record);

    int updateByPrimaryKey(BaseMenu record);
}